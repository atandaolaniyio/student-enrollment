<?php
require_once 'db.php';

$search = isset($_GET['search']) ? $_GET['search'] : '';
$date_from = isset($_GET['date_from']) ? $_GET['date_from'] : '';
$date_to = isset($_GET['date_to']) ? $_GET['date_to'] : '';

// Build query
$query = "SELECT * FROM students WHERE 1=1";
$params = [];

if (!empty($search)) {
    $query .= " AND (name LIKE ? OR email LIKE ? OR major LIKE ? OR student_id LIKE ?)";
    $like = "%$search%";
    $params = array_merge($params, [$like, $like, $like, $like]);
}

if (!empty($date_from)) {
    $query .= " AND enrollment_date >= ?";
    $params[] = $date_from;
}

if (!empty($date_to)) {
    $query .= " AND enrollment_date <= ?";
    $params[] = $date_to;
}

$query .= " ORDER BY enrollment_date DESC";
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$students = $stmt->fetchAll();

// Get student with calendar view
$selected_student = null;
if (isset($_GET['view_id'])) {
    $stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->execute([$_GET['view_id']]);
    $selected_student = $stmt->fetch();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Record Bank</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fb; }
        .header { background: #2c3e50; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header a { color: white; text-decoration: none; margin-left: 15px; padding: 8px 15px; border-radius: 5px; }
        .header a:hover { background: #4a86e8; }
        .container { max-width: 1400px; margin: 0 auto; padding: 20px; }
        .search-box { background: white; padding: 20px; border-radius: 10px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .search-box input, .search-box select { padding: 10px; margin: 5px; border: 1px solid #ddd; border-radius: 5px; }
        .search-box button { background: #4a86e8; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        table { width: 100%; background: white; border-collapse: collapse; border-radius: 10px; overflow: hidden; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #4a86e8; color: white; }
        tr:hover { background: #f5f5f5; }
        .btn-view { background: #4a86e8; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; }
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; }
        .modal-content { background: white; margin: 5% auto; padding: 30px; width: 70%; max-width: 900px; border-radius: 10px; max-height: 85vh; overflow-y: auto; }
        .close { float: right; font-size: 28px; cursor: pointer; color: #999; }
        .close:hover { color: #333; }
        .calendar { margin-top: 20px; border: 1px solid #ddd; border-radius: 8px; overflow: hidden; }
        .calendar-header { background: #4a86e8; color: white; display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; padding: 10px; }
        .calendar-days { display: grid; grid-template-columns: repeat(7, 1fr); text-align: center; }
        .calendar-day { padding: 15px; border: 1px solid #ddd; min-height: 80px; vertical-align: top; }
        .calendar-day.today { background: #d4edda; }
        .event { background: #4a86e8; color: white; padding: 2px 5px; border-radius: 3px; font-size: 11px; margin-top: 5px; }
        .record-details { margin-top: 20px; background: #f8f9fa; padding: 15px; border-radius: 8px; }
        .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px; }
        .stat-card { background: white; padding: 15px; border-radius: 10px; text-align: center; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; background: #d4edda; color: #155724; }
        @media (max-width: 768px) { .modal-content { width: 95%; } .calendar-day { padding: 5px; font-size: 12px; } }
    </style>
</head>
<body>
<div class="header">
    <h1>📚 Student Record Bank</h1>
    <div><a href="index.php">🏠 Dashboard</a> <a href="admin_dashboard.php?table=students">⚙️ Manage Students</a> <a href="upload_students.php">📤 Bulk Upload</a></div>
</div>

<div class="container">
    <div class="search-box">
        <h3>🔍 Search Student Records</h3>
        <form method="GET">
            <input type="text" name="search" placeholder="Search by name, email, major, or ID..." value="<?php echo htmlspecialchars($search); ?>" style="width: 100%; margin-bottom: 10px;">
            <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                <input type="date" name="date_from" placeholder="Date From" value="<?php echo $date_from; ?>">
                <input type="date" name="date_to" placeholder="Date To" value="<?php echo $date_to; ?>">
                <button type="submit">🔍 Search Records</button>
                <a href="record_bank.php" style="padding: 10px 15px; background: #6c757d; color: white; text-decoration: none; border-radius: 5px;">Reset</a>
            </div>
        </form>
    </div>

    <div class="stats">
        <div class="stat-card"><strong>Total Students:</strong><br><span style="font-size: 24px; color:#4a86e8;"><?php echo count($students); ?></span></div>
        <div class="stat-card"><strong>Active Enrollments:</strong><br><span style="font-size: 24px; color:#27ae60;"><?php echo $pdo->query("SELECT COUNT(*) FROM enrollments WHERE status='Active'")->fetchColumn(); ?></span></div>
        <div class="stat-card"><strong>This Month:</strong><br><span style="font-size: 24px; color:#e74c3c;"><?php echo $pdo->query("SELECT COUNT(*) FROM students WHERE MONTH(created_at)=MONTH(CURDATE())")->fetchColumn(); ?></span></div>
    </div>

    <h3>📋 Student Records (<?php echo count($students); ?> found)</h3>
    <div style="overflow-x: auto;">
        <table>
            <thead>
                <tr><th>ID</th><th>Student ID</th><th>Name</th><th>Email</th><th>Major</th><th>Status</th><th>Enrollment Date</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php if (count($students) == 0): ?>
                    <tr><td colspan="8" style="text-align: center;">No records found</td></tr>
                <?php else: ?>
                    <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?php echo $student['id']; ?></td>
                        <td><?php echo htmlspecialchars($student['student_id'] ?? 'N/A'); ?></td>
                        <td><strong><?php echo htmlspecialchars($student['name']); ?></strong></td>
                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                        <td><?php echo htmlspecialchars($student['major'] ?? 'N/A'); ?></td>
                        <td><span class="status-badge"><?php echo htmlspecialchars($student['status'] ?? 'Active'); ?></span></td>
                        <td><?php echo $student['enrollment_date'] ? date('M d, Y', strtotime($student['enrollment_date'])) : date('M d, Y', strtotime($student['created_at'])); ?></td>
                        <td><a href="?view_id=<?php echo $student['id']; ?>" class="btn-view">📅 View Profile & Calendar</a></td>
                    </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <?php if ($selected_student): ?>
    <div id="studentModal" style="display: block;">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h2>👨‍🎓 Student Profile: <?php echo htmlspecialchars($selected_student['name']); ?></h2>
            
            <div class="record-details">
                <div style="display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px;">
                    <p><strong>Student ID:</strong> <?php echo htmlspecialchars($selected_student['student_id'] ?? 'N/A'); ?></p>
                    <p><strong>Email:</strong> <?php echo htmlspecialchars($selected_student['email']); ?></p>
                    <p><strong>Phone:</strong> <?php echo htmlspecialchars($selected_student['phone'] ?? 'N/A'); ?></p>
                    <p><strong>Major:</strong> <?php echo htmlspecialchars($selected_student['major'] ?? 'N/A'); ?></p>
                    <p><strong>Status:</strong> <?php echo htmlspecialchars($selected_student['status'] ?? 'Active'); ?></p>
                    <p><strong>Enrollment Date:</strong> <?php echo date('F d, Y', strtotime($selected_student['enrollment_date'] ?? $selected_student['created_at'])); ?></p>
                    <p><strong>Registered On:</strong> <?php echo date('F d, Y g:i A', strtotime($selected_student['created_at'])); ?></p>
                </div>
            </div>

            <h3>📅 Academic Calendar - <?php echo date('F Y'); ?></h3>
            <div class="calendar">
                <div class="calendar-header">
                    <div>Sun</div><div>Mon</div><div>Tue</div><div>Wed</div><div>Thu</div><div>Fri</div><div>Sat</div>
                </div>
                <div class="calendar-days">
                    <?php
                    $first_day = date('Y-m-01');
                    $last_day = date('Y-m-t');
                    $start_weekday = date('w', strtotime($first_day));
                    $total_days = date('t');
                    $current_day = 1;
                    
                    for ($i = 0; $i < 42; $i++) {
                        if ($i < $start_weekday || $current_day > $total_days) {
                            echo '<div class="calendar-day"></div>';
                        } else {
                            $is_today = ($current_day == date('j'));
                            $class = $is_today ? 'calendar-day today' : 'calendar-day';
                            echo '<div class="' . $class . '">';
                            echo '<strong>' . $current_day . '</strong>';
                            
                            // Sample events
                            if ($current_day == 15) {
                                echo '<div class="event">📖 Midterm Exam</div>';
                            }
                            if ($current_day == 22) {
                                echo '<div class="event">📝 Assignment Due</div>';
                            }
                            if ($current_day == 30) {
                                echo '<div class="event">🎓 Registration Deadline</div>';
                            }
                            echo '</div>';
                            $current_day++;
                        }
                    }
                    ?>
                </div>
            </div>
            
            <h3 style="margin-top: 20px;">📋 Enrollment History</h3>
            <?php
            $enrollments = $pdo->prepare("SELECT e.*, c.course_name FROM enrollments e LEFT JOIN courses c ON e.course_id = c.id WHERE e.student_id = ?");
            $enrollments->execute([$selected_student['id']]);
            $student_enrollments = $enrollments->fetchAll();
            ?>
            <?php if (count($student_enrollments) > 0): ?>
                <table style="margin-top: 10px; width: 100%;">
                    <thead><tr><th>Course</th><th>Enrollment Date</th><th>Status</th><th>Grade</th></tr></thead>
                    <tbody>
                        <?php foreach ($student_enrollments as $enroll): ?>
                        <tr><td><?php echo htmlspecialchars($enroll['course_name']); ?></td><td><?php echo date('M d, Y', strtotime($enroll['enrollment_date'])); ?></td><td><?php echo $enroll['status']; ?></td><td><?php echo $enroll['grade'] ?? 'N/A'; ?></td></tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No enrollments found for this student.</p>
            <?php endif; ?>
        </div>
    </div>
    <style>.modal { display: block; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.5); z-index: 1000; overflow-y: auto; }</style>
    <?php endif; ?>
</div>

<script>
function closeModal() {
    document.getElementById('studentModal').style.display = 'none';
    window.location.href = 'record_bank.php';
}
flatpickr(".date-input", { dateFormat: "Y-m-d" });
</script>
</body>
</html>
