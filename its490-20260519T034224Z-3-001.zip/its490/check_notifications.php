<?php
require_once 'config.php';

$current_user_id = 1; // Get from session in real app

$sql = "SELECT COUNT(*) as count FROM notifications 
        WHERE (user_id = ? OR user_id IS NULL) 
        AND is_read = FALSE";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $current_user_id);
$stmt->execute();
$result = $stmt->get_result();
$count = $result->fetch_assoc()['count'];

echo json_encode(['count' => $count]);
?>
