<?php
// Marks notifications as read for the logged-in user.
// Accepts POST with optional JSON: { ids: [1,2,3] } or marks all unread if ids not provided.

header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(["error" => "Not logged in"]);
    exit;
}

require_once __DIR__ . '/db_connect.php';
$conn = db_connect();

$username = $_SESSION['username'];
$raw = file_get_contents('php://input');
$data = json_decode($raw, true);

if (is_array($data) && isset($data['ids']) && is_array($data['ids']) && count($data['ids']) > 0) {
    // Build dynamic placeholders
    $ids = array_values(array_filter($data['ids'], fn($v) => is_numeric($v)));
    if (count($ids) === 0) {
        echo json_encode(["ok" => true, "updated" => 0]);
        exit;
    }

    $placeholders = implode(',', array_fill(0, count($ids), '?'));
    $types = str_repeat('i', count($ids)) . 's';

    $sql = "UPDATE notifications SET is_read = 1 WHERE id IN ($placeholders) AND username = ?";
    $stmt = $conn->prepare($sql);

    $params = array_merge($ids, [$username]);
    $bind_names[] = $types;
    for ($i=0; $i<count($params); $i++) {
        $bind_names[] = &$params[$i];
    }
    call_user_func_array([$stmt, 'bind_param'], $bind_names);

    $stmt->execute();
    $updated = $stmt->affected_rows;
    $stmt->close();
    $conn->close();

    echo json_encode(["ok" => true, "updated" => (int)$updated]);
    exit;
}

// Mark all unread as read
$stmt = $conn->prepare('UPDATE notifications SET is_read = 1 WHERE username = ? AND is_read = 0');
$stmt->bind_param('s', $username);
$stmt->execute();
$updated = $stmt->affected_rows;
$stmt->close();
$conn->close();

echo json_encode(["ok" => true, "updated" => (int)$updated]);
?>
