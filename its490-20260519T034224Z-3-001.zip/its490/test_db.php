<?php
require __DIR__ . "/db_connect.php";

$result = $conn->query("SELECT DATABASE() AS db");
$row = $result ? $result->fetch_assoc() : null;

echo "✅ Connected! Current DB = " . ($row["db"] ?? "unknown") . "<br>";

$tables = $conn->query("SHOW TABLES");
echo "Tables:<br>";
while ($t = $tables->fetch_row()) {
  echo "- " . $t[0] . "<br>";
}
?>
