<?php
require_once '../includes/Database.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'] ?? '';
    $content = $_POST['content'] ?? '';
    $author = $_POST['author'] ?? 'Admin';
    
    if ($title && $content) {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            $stmt = $conn->prepare("INSERT INTO news (title, content, author, status) VALUES (?, ?, ?, 'published')");
            if ($stmt->execute([$title, $content, $author])) {
                header('Location: ../index.php?added=1');
                exit();
            }
        } catch (PDOException $e) {
            $error = '<div class="error">Error: ' . $e->getMessage() . '</div>';
        }
    } else {
        $error = '<div class="error">Title and content are required!</div>';
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Add News - Admin Panel</title>
    <style>
        body { font-family: Arial; padding: 20px; background: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #555; }
        input[type="text"], textarea { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
        textarea { height: 200px; }
        button { background: #007bff; color: white; border: none; padding: 12px 30px; border-radius: 4px; font-size: 16px; cursor: pointer; }
        button:hover { background: #0056b3; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 4px; margin-bottom: 20px; }
        .back-link { display: inline-block; margin-top: 20px; color: #007bff; text-decoration: none; }
        .back-link:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Add News / Update</h1>
        
        <?php echo $message; ?>
        <?php echo $error; ?>
        
        <form method="POST">
            <div class="form-group">
                <label for="title">Title:</label>
                <input type="text" id="title" name="title" required placeholder="Enter news title">
            </div>
            
            <div class="form-group">
                <label for="author">Author:</label>
                <input type="text" id="author" name="author" value="Admin" placeholder="Author name">
            </div>
            
            <div class="form-group">
                <label for="content">Content:</label>
                <textarea id="content" name="content" required placeholder="Write your news content here..."></textarea>
            </div>
            
            <button type="submit">Publish News</button>
        </form>
        
        <a href="../index.php" class="back-link">← Back to Homepage</a>
    </div>
</body>
</html>
