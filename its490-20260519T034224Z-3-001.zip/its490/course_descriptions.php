<?php require_once 'db.php'; $courses = $pdo->query("SELECT id, course_code, title FROM course_descriptions ORDER BY course_code")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>Course Descriptions</title><style>body{font-family:Arial;margin:30px} table{border-collapse:collapse;width:100%} th,td{border:1px solid #ccc;padding:10px} th{background:#4a86e8;color:white}</style></head>
<body><h2>📖 Course Descriptions</h2><a href="index.php">← Back</a><br><br>
<table><tr><th>Course Code</th><th>Title</th><th>Action</th></tr>
<?php foreach($courses as $c): ?>
<tr><td><?= htmlspecialchars($c['course_code']) ?></td><td><?= htmlspecialchars($c['title']) ?></td><td><a href="course_description.php?id=<?= $c['id'] ?>">View Description</a></td></tr>
<?php endforeach; ?>
</table></body></html>
