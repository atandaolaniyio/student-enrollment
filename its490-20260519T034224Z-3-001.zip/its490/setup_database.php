<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$host = 'localhost';
$dbname = 'Concurrent_Enrollment_Database';
$username = 'admin';
$password = 'Henry123456';

try {
    // First connect without database selected
    $pdo = new PDO("mysql:host=$host;charset=utf8mb4", $username, $password, [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
    ]);
    
    echo "Connected to MySQL server<br>\n";
    
    // Create database if not exists
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `$dbname`");
    echo "✅ Database '$dbname' created or already exists<br>\n";
    
    // Select the database
    $pdo->exec("USE `$dbname`");
    echo "✅ Using database '$dbname'<br>\n";
    
    // Create students table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS students (
            id INT AUTO_INCREMENT PRIMARY KEY,
            first_name VARCHAR(50) NOT NULL,
            last_name VARCHAR(50) NOT NULL,
            email VARCHAR(100) UNIQUE,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");
    echo "✅ Students table created<br>\n";
    
    // Create courses table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS courses (
            id INT AUTO_INCREMENT PRIMARY KEY,
            course_name VARCHAR(100) NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ");
    echo "✅ Courses table created<br>\n";
    
    // Create enrollments table
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS enrollments (
            id INT AUTO_INCREMENT PRIMARY KEY,
            student_id INT NOT NULL,
            course_id INT NOT NULL,
            enrollment_date DATE NOT NULL,
            status VARCHAR(20) DEFAULT 'Active',
            grade VARCHAR(2),
            FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
            FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
            UNIQUE KEY unique_enrollment (student_id, course_id)
        )
    ");
    echo "✅ Enrollments table created<br>\n";
    
    // Insert sample data
    $stmt = $pdo->prepare("INSERT IGNORE INTO students (first_name, last_name, email) VALUES 
        ('John', 'Doe', 'john.doe@example.com'),
        ('Jane', 'Smith', 'jane.smith@example.com'),
        ('Michael', 'Johnson', 'michael.johnson@example.com'),
        ('Emily', 'Davis', 'emily.davis@example.com'),
        ('David', 'Wilson', 'david.wilson@example.com')");
    $stmt->execute();
    echo "✅ Sample students inserted<br>\n";
    
    $stmt = $pdo->prepare("INSERT IGNORE INTO courses (course_name) VALUES 
        ('Mathematics 101'),
        ('Physics 101'),
        ('Chemistry 101'),
        ('Biology 101'),
        ('Computer Science 101')");
    $stmt->execute();
    echo "✅ Sample courses inserted<br>\n";
    
    // Show tables
    $tables = $pdo->query("SHOW TABLES")->fetchAll();
    echo "<br><strong>Tables in database:</strong><br>\n";
    foreach($tables as $table) {
        echo "- " . implode('', $table) . "<br>\n";
    }
    
    // Show counts
    $studentCount = $pdo->query("SELECT COUNT(*) as count FROM students")->fetch();
    $courseCount = $pdo->query("SELECT COUNT(*) as count FROM courses")->fetch();
    echo "<br><strong>Summary:</strong><br>\n";
    echo "Students: " . $studentCount['count'] . "<br>\n";
    echo "Courses: " . $courseCount['count'] . "<br>\n";
    
    echo "<br><strong>✅ Database setup complete!</strong><br>\n";
    echo "<a href='students.php'>Go to Students Page</a> | ";
    echo "<a href='enrollments.php'>Go to Enrollments Page</a><br>\n";
    
} catch (PDOException $e) {
    echo "<strong style='color:red'>Error:</strong> " . htmlspecialchars($e->getMessage()) . "<br>\n";
}
?>
