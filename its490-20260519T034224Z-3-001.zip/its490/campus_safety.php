<?php require_once 'db.php'; $safety = $pdo->query("SELECT * FROM campus_safety ORDER BY id")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>Campus Safety</title><style>body{font-family:Arial;margin:30px} .card{border:1px solid #ddd;padding:15px;margin-bottom:20px;border-radius:8px}</style></head>
<body><h2>🚔 Campus Safety & Security</h2><a href="index.php">← Back</a><br><br>
<?php foreach($safety as $s): ?>
<div class="card"><h3><?= htmlspecialchars($s['name']) ?></h3><div><?= nl2br(htmlspecialchars($s['information'])) ?></div></div>
<?php endforeach; ?>
</body></html>
