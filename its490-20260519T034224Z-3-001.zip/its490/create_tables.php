<?php
require_once 'db.php';

try {
    // Students table
    $pdo->exec("CREATE TABLE IF NOT EXISTS students (
        id INT AUTO_INCREMENT PRIMARY KEY,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        email VARCHAR(255),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Courses table
    $pdo->exec("CREATE TABLE IF NOT EXISTS courses (
        id INT AUTO_INCREMENT PRIMARY KEY,
        course_name VARCHAR(255) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");

    // Enrollments table
    $pdo->exec("CREATE TABLE IF NOT EXISTS enrollments (
        id INT AUTO_INCREMENT PRIMARY KEY,
        student_id INT NOT NULL,
        course_id INT NOT NULL,
        enrollment_date DATE NOT NULL,
        status ENUM('Active', 'Inactive') DEFAULT 'Active',
        grade VARCHAR(10) DEFAULT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE
    )");

    echo "✅ Tables created successfully: students, courses, enrollments<br>";

    // Show row counts
    echo "Students: " . $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn() . "<br>";
    echo "Courses: " . $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn() . "<br>";
    echo "Enrollments: " . $pdo->query("SELECT COUNT(*) FROM enrollments")->fetchColumn() . "<br>";

} catch (PDOException $e) {
    echo "❌ Error: " . $e->getMessage();
}
?>
