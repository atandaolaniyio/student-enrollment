<?php
include 'config.php';
echo "Connected successfully to database!";
echo "<br>Database: " . DB_NAME;
echo "<br>Tables in database: <br>";

$result = $conn->query("SHOW TABLES");
while ($row = $result->fetch_array()) {
    echo "✓ " . $row[0] . "<br>";
}
?>
