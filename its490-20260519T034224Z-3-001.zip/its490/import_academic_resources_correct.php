<?php
require_once 'db.php';

echo "<h2>Importing Academic Resources Data</h2>";
echo "<p>Your table structure: id, name, information</p>";

// Academic resources data from CSV (only name and information)
$resources = [
    [
        'name' => 'Academic Colleges',
        'information' => 'College of Business
L. Hamer, Dean
Hammond Campus: Anderson Building 356, (219)989-2595
Westville Campus: Technology Building 186, (219)785-5263

College of Humanities, Education, and Social Sciences
E. Carey, Dean
Hammond Campus: Classroom Office Building 152, (219)989-2401
Westville Campus: Technology Building 341, (219)785-5647

College of Engineering and Science
N. Latif, Interim Dean
Hammond Campus: Gyte Building 181, (219)989-2468
Westville Campus: Schwarz Building 160, (219)785-5736

College of Nursing
L. Hopp, Dean
Hammond Campus: Classroom Office Building 313, (219)989-2814
Westville Campus: Technology Building 357, (219)785-5454

College of Technology
N. Latif, Dean
Hammond Campus: Anderson Building 202, (219)989-8324
Westville Campus: Technology Building 269, (219)785-5619

Honors College
J. Swarts, Dean
Hammond Campus: Student Union Library 320, (219)989-3160
Westville Campus: Library Student Faculty 069, (219)785-5366'
    ],
    [
        'name' => 'Academic Calendar',
        'information' => 'See PNWs Academic Schedule: https://www.pnw.edu/registrar/academic-schedule/'
    ],
    [
        'name' => 'Degrees',
        'information' => 'Please check the online listing of current degrees offered. https://www.pnw.edu/program-finder/'
    ],
    [
        'name' => 'Academic Advising',
        'information' => 'The responsibility for all academic decisions belongs to the student.

https://www.pnw.edu/advising/
https://www.pnw.edu/advising/exploratory-advising/

Purdue University Northwest recognizes academic advising as a critical component of the educational experience of students. Upon admission to the university, all students are assigned to an academic advisor.

Academic advisors at Purdue University Northwest are committed to providing students accurate and timely academic advisement delivered through academic departments and colleges, as well as through Exploratory Advising.

Through collaborative relationships with assigned academic advisors, students learn to define and implement strategic and efficient educational plans that are consistent with their personal values, goals, abilities and career plans.'
    ],
    [
        'name' => 'Student Academic Support',
        'information' => 'Location:
Hammond Campus: Gyte Building, room 102
Westville Campus: Library-Student-Faculty (LSF) Building, room 202

Phone:
Hammond: (219)989-3227
Westville: (219)785-5628

Website: pnw.edu/sas
Email: sas@pnw.edu

Student Academic Support (SAS) provides Supplemental Instruction (SI), Walk-in and online tutoring to PNW students on both the Hammond and Westville campuses.

Supplemental Instruction is offered to all students enrolled in specific undergraduate courses. SI sessions are interactive review sessions and are facilitated by an SI Leader (a student that has already successfully completed the class and sits in on it again with you) usually twice per week.

Walk-in tutoring is a drop-in tutoring service conducted in small groups by peer tutors. No appointment is needed.

Peer tutors also offer Individual, online tutoring, by-appointment through Zoom.

SAS is also a major employer for academically successful students seeking on-campus employment as tutors and/or SI leaders.'
    ]
];

$inserted = 0;
$skipped = 0;

echo "<h3>Processing Records:</h3>";
echo "<ul>";

foreach ($resources as $resource) {
    // Check if record already exists
    $check = $pdo->prepare("SELECT id FROM academic_resources WHERE name = ?");
    $check->execute([$resource['name']]);
    
    if (!$check->fetch()) {
        // Insert new record
        $insert = $pdo->prepare("INSERT INTO academic_resources (name, information) VALUES (?, ?)");
        $insert->execute([$resource['name'], $resource['information']]);
        echo "<li style='color:green'>✅ Added: " . htmlspecialchars($resource['name']) . "</li>";
        $inserted++;
    } else {
        echo "<li style='color:orange'>⏭️ Skipped (already exists): " . htmlspecialchars($resource['name']) . "</li>";
        $skipped++;
    }
}
echo "</ul>";

echo "<hr>";
echo "<strong>Summary:</strong><br>";
echo "✅ New records added: $inserted<br>";
echo "⏭️ Already existed (skipped): $skipped<br>";

// Show all current records
echo "<h3>All Academic Resources in Database (Total Records):</h3>";
$all = $pdo->query("SELECT id, name FROM academic_resources ORDER BY id");
$total = 0;
echo "<table border='1' cellpadding='8' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background:#4a86e8;color:white'><th>ID</th><th>Name</th></tr>";
while ($row = $all->fetch()) {
    $total++;
    $highlight = ($row['name'] == 'Tutoring Center' || $row['name'] == 'Writing Lab') ? 'style="background:#d4edda;"' : '';
    echo "<tr $highlight>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "<p><span style='background:#d4edda;padding:2px 8px;'>Green highlighted</span> = Your original records (Tutoring Center, Writing Lab) - PRESERVED</p>";
echo "<p><strong>Total records in table: $total</strong></p>";

echo '<br><a href="admin_dashboard.php?table=academic_resources" style="background:#4a86e8;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">📊 View in Admin Panel</a>';
echo ' <a href="index.php" style="background:#2c3e50;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">🏠 Back to Dashboard</a>';
?>
