-- =====================================================
-- Concurrent Enrollment Database - Complete Schema
-- =====================================================

-- 1. STUDENTS TABLE
DROP TABLE IF EXISTS students;
CREATE TABLE students (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(50) UNIQUE,
    name VARCHAR(200) NOT NULL,
    email VARCHAR(255) UNIQUE,
    phone VARCHAR(20),
    major VARCHAR(100),
    enrollment_date DATE,
    status ENUM('Active', 'Inactive', 'Graduated', 'Suspended') DEFAULT 'Active',
    profile_picture VARCHAR(500),
    date_of_birth DATE,
    address TEXT,
    emergency_contact VARCHAR(100),
    emergency_phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_student_id (student_id),
    INDEX idx_name (name),
    INDEX idx_email (email),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. COURSES TABLE
DROP TABLE IF EXISTS courses;
CREATE TABLE courses (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) UNIQUE NOT NULL,
    course_name VARCHAR(255) NOT NULL,
    title TEXT,
    credits INT DEFAULT 3,
    instructor VARCHAR(200),
    department VARCHAR(100),
    semester VARCHAR(20),
    year INT,
    capacity INT DEFAULT 30,
    enrolled INT DEFAULT 0,
    monday TEXT,
    tuesday TEXT,
    wednesday TEXT,
    thursday TEXT,
    friday TEXT,
    room VARCHAR(100),
    prerequisites TEXT,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_course_code (course_code),
    INDEX idx_course_name (course_name),
    INDEX idx_department (department),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. ENROLLMENTS TABLE
DROP TABLE IF EXISTS enrollments;
CREATE TABLE enrollments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    course_id INT NOT NULL,
    enrollment_date DATE NOT NULL,
    status ENUM('Active', 'Completed', 'Dropped', 'Withdrawn', 'Failed') DEFAULT 'Active',
    grade ENUM('A', 'B', 'C', 'D', 'F', 'W', 'I', 'IP') DEFAULT NULL,
    grade_points DECIMAL(3,2),
    attendance_percentage DECIMAL(5,2) DEFAULT 0,
    payment_status ENUM('Paid', 'Pending', 'Overdue', 'Waived') DEFAULT 'Pending',
    dropped_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(id) ON DELETE CASCADE,
    UNIQUE KEY unique_enrollment (student_id, course_id),
    INDEX idx_student (student_id),
    INDEX idx_course (course_id),
    INDEX idx_status (status),
    INDEX idx_enrollment_date (enrollment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. POLICIES TABLE
DROP TABLE IF EXISTS policies;
CREATE TABLE policies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    information TEXT NOT NULL,
    version VARCHAR(20),
    effective_date DATE,
    created_by VARCHAR(100),
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_category (category),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. FAQ TABLE
DROP TABLE IF EXISTS faq;
CREATE TABLE faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    category VARCHAR(100),
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    author VARCHAR(100),
    views INT DEFAULT 0,
    helpful_yes INT DEFAULT 0,
    helpful_no INT DEFAULT 0,
    is_published BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_category (category),
    INDEX idx_is_published (is_published),
    FULLTEXT INDEX idx_search (question, answer)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. CAMPUS_SAFETY TABLE
DROP TABLE IF EXISTS campus_safety;
CREATE TABLE campus_safety (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    information TEXT NOT NULL,
    emergency_phone VARCHAR(20),
    non_emergency_phone VARCHAR(20),
    location VARCHAR(255),
    campus ENUM('Hammond', 'Westville', 'Both') DEFAULT 'Both',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_campus (campus)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. BUILDING_HOURS TABLE
DROP TABLE IF EXISTS building_hours;
CREATE TABLE building_hours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    code VARCHAR(20),
    campus ENUM('Hammond', 'Westville') NOT NULL,
    address TEXT,
    monday VARCHAR(100),
    tuesday VARCHAR(100),
    wednesday VARCHAR(100),
    thursday VARCHAR(100),
    friday VARCHAR(100),
    saturday VARCHAR(100),
    sunday VARCHAR(100),
    special_hours TEXT,
    phone VARCHAR(20),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_campus (campus)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. ACADEMIC_RESOURCES TABLE
DROP TABLE IF EXISTS academic_resources;
CREATE TABLE academic_resources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    information TEXT NOT NULL,
    location VARCHAR(255),
    phone VARCHAR(20),
    email VARCHAR(255),
    website VARCHAR(500),
    hours TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_category (category)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. CEP_INFO TABLE
DROP TABLE IF EXISTS cep_info;
CREATE TABLE cep_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    category VARCHAR(100),
    information TEXT NOT NULL,
    display_order INT DEFAULT 0,
    is_featured BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_category (category),
    INDEX idx_display_order (display_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. COURSE_DESCRIPTIONS TABLE
DROP TABLE IF EXISTS course_descriptions;
CREATE TABLE course_descriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL,
    credits INT DEFAULT 3,
    prerequisites TEXT,
    corequisites TEXT,
    learning_outcomes TEXT,
    department VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY unique_course_code (course_code),
    INDEX idx_course_code (course_code),
    INDEX idx_title (title),
    FULLTEXT INDEX idx_description (description)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 11. DEVICE_TOKENS TABLE
DROP TABLE IF EXISTS device_tokens;
CREATE TABLE device_tokens (
    id INT AUTO_INCREMENT PRIMARY KEY,
    device_token VARCHAR(255) NOT NULL UNIQUE,
    platform ENUM('android', 'ios', 'web') DEFAULT 'android',
    sns_endpoint_arn VARCHAR(500),
    user_id VARCHAR(100),
    user_name VARCHAR(200),
    last_active TIMESTAMP NULL,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_device_token (device_token),
    INDEX idx_user_id (user_id),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 12. PUSH_NOTIFICATIONS TABLE
DROP TABLE IF EXISTS push_notifications;
CREATE TABLE push_notifications (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    target_type VARCHAR(50),
    target_ids TEXT,
    sent_to_count INT DEFAULT 0,
    delivered_count INT DEFAULT 0,
    opened_count INT DEFAULT 0,
    status ENUM('pending', 'sent', 'failed', 'partial') DEFAULT 'pending',
    scheduled_for TIMESTAMP NULL,
    sent_at TIMESTAMP NULL,
    created_by VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_scheduled_for (scheduled_for),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 13. NOTIFICATION_LOGS TABLE
DROP TABLE IF EXISTS notification_logs;
CREATE TABLE notification_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    notification_id INT NOT NULL,
    device_token VARCHAR(255),
    user_id VARCHAR(100),
    status ENUM('sent', 'delivered', 'opened', 'failed') DEFAULT 'sent',
    error_message TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    opened_at TIMESTAMP NULL,
    FOREIGN KEY (notification_id) REFERENCES push_notifications(id) ON DELETE CASCADE,
    INDEX idx_notification (notification_id),
    INDEX idx_device_token (device_token),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 14. AUDIT_LOGS TABLE
DROP TABLE IF EXISTS audit_logs;
CREATE TABLE audit_logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id VARCHAR(100),
    user_ip VARCHAR(45),
    action VARCHAR(100),
    table_name VARCHAR(100),
    record_id INT,
    old_data JSON,
    new_data JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_table_name (table_name),
    INDEX idx_action (action),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 15. STUDENT_ACADEMIC_RECORDS TABLE
DROP TABLE IF EXISTS student_academic_records;
CREATE TABLE student_academic_records (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,
    semester VARCHAR(20),
    year INT,
    gpa DECIMAL(3,2),
    credits_attempted INT DEFAULT 0,
    credits_earned INT DEFAULT 0,
    cumulative_gpa DECIMAL(3,2),
    academic_standing ENUM('Good Standing', 'Probation', 'Suspended', 'Dismissed') DEFAULT 'Good Standing',
    dean_list BOOLEAN DEFAULT FALSE,
    honors_list BOOLEAN DEFAULT FALSE,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    UNIQUE KEY unique_semester (student_id, semester, year),
    INDEX idx_student (student_id),
    INDEX idx_semester (semester, year)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 16. PAYMENTS TABLE
DROP TABLE IF EXISTS payments;
CREATE TABLE payments (
    id INT AUTO_INCREMENT PRIMARY KEY,
    enrollment_id INT NOT NULL,
    amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method ENUM('Credit Card', 'Debit Card', 'Bank Transfer', 'Cash', 'Check', 'Scholarship') DEFAULT 'Credit Card',
    transaction_id VARCHAR(255),
    status ENUM('Pending', 'Completed', 'Failed', 'Refunded') DEFAULT 'Pending',
    receipt_url VARCHAR(500),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (enrollment_id) REFERENCES enrollments(id) ON DELETE CASCADE,
    INDEX idx_enrollment (enrollment_id),
    INDEX idx_status (status),
    INDEX idx_payment_date (payment_date)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================
-- Insert sample data
-- =====================================================

-- Sample Students
INSERT INTO students (student_id, name, email, phone, major, enrollment_date, status) VALUES
('S1001', 'John Doe', 'john.doe@example.com', '555-0101', 'Computer Science', '2026-01-15', 'Active'),
('S1002', 'Jane Smith', 'jane.smith@example.com', '555-0102', 'Engineering', '2026-01-15', 'Active'),
('S1003', 'Mike Johnson', 'mike.johnson@example.com', '555-0103', 'Business', '2026-01-15', 'Active'),
('S1004', 'Emily Davis', 'emily.davis@example.com', '555-0104', 'Nursing', '2026-01-15', 'Active'),
('S1005', 'David Wilson', 'david.wilson@example.com', '555-0105', 'Mathematics', '2026-01-15', 'Active');

-- Sample Courses
INSERT INTO courses (course_code, course_name, title, credits, department, semester, year) VALUES
('CS101', 'Introduction to Programming', 'Learn programming fundamentals with Java', 3, 'Computer Science', 'Spring', 2026),
('MATH150', 'Calculus I', 'Limits, derivatives, and integrals', 4, 'Mathematics', 'Spring', 2026),
('ENG101', 'English Composition', 'Academic writing and research', 3, 'English', 'Spring', 2026),
('PHYS101', 'Physics I', 'Mechanics and thermodynamics', 4, 'Physics', 'Spring', 2026),
('BUS101', 'Introduction to Business', 'Business fundamentals', 3, 'Business', 'Spring', 2026);

-- Sample Enrollments
INSERT INTO enrollments (student_id, course_id, enrollment_date, status) 
SELECT s.id, c.id, '2026-01-20', 'Active' 
FROM students s, courses c 
WHERE s.id <= 3 AND c.id <= 3 LIMIT 5;

-- Sample Policies
INSERT INTO policies (name, category, information, is_active) VALUES
('Academic Integrity', 'Academic', 'All students must maintain academic honesty. Plagiarism and cheating will result in disciplinary action.', 1),
('Attendance Policy', 'Academic', 'Regular attendance is required. Students missing more than 20% of classes may be withdrawn.', 1),
('Grade Appeal', 'Academic', 'Students may appeal grades within 30 days of grade posting.', 1);

-- Sample FAQ
INSERT INTO faq (category, question, answer) VALUES
('Registration', 'How do I register for classes?', 'You can register through your myPNW portal or contact the registrar office.'),
('Payment', 'When is tuition due?', 'Tuition is due on the first day of classes each semester.'),
('Transfer', 'Do credits transfer to other universities?', 'Yes, PNW credits are transferable to most accredited institutions.');

