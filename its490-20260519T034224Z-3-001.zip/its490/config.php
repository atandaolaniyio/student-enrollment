<?php
session_start();

function h($string) {
    return htmlspecialchars($string, ENT_QUOTES, 'UTF-8');
}

function redirect($url, $message = '', $type = 'success') {
    if ($message) {
        $_SESSION['flash_message'] = $message;
        $_SESSION['flash_type'] = $type;
    }
    header("Location: $url");
    exit;
}

function display_flash() {
    if (isset($_SESSION['flash_message'])) {
        $type = $_SESSION['flash_type'] ?? 'success';
        $class = $type === 'success' ? 'success' : 'error';
        echo "<div class='$class'>{$_SESSION['flash_message']}</div>";
        unset($_SESSION['flash_message']);
        unset($_SESSION['flash_type']);
    }
}

function getAll($table, $orderBy = 'id DESC') {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM $table ORDER BY $orderBy");
    return $stmt->fetchAll();
}

function getById($table, $id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = ?");
    $stmt->execute([$id]);
    return $stmt->fetch();
}

function deleteById($table, $id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
    return $stmt->execute([$id]);
}

function updateTable($table, $data, $id) {
    global $pdo;
    $sets = [];
    foreach ($data as $key => $value) {
        $sets[] = "$key = ?";
    }
    $sql = "UPDATE $table SET " . implode(', ', $sets) . " WHERE id = ?";
    $stmt = $pdo->prepare($sql);
    $values = array_values($data);
    $values[] = $id;
    return $stmt->execute($values);
}

function insertInto($table, $data) {
    global $pdo;
    $columns = implode(', ', array_keys($data));
    $placeholders = ':' . implode(', :', array_keys($data));
    $sql = "INSERT INTO $table ($columns) VALUES ($placeholders)";
    $stmt = $pdo->prepare($sql);
    return $stmt->execute($data);
}
?>
