<?php
require_once 'db.php';

try {
    // Add sample students
    $pdo->exec("INSERT IGNORE INTO students (first_name, last_name, email) VALUES 
        ('John', 'Doe', 'john@example.com'),
        ('Jane', 'Smith', 'jane@example.com'),
        ('Michael', 'Johnson', 'michael@example.com'),
        ('Emily', 'Davis', 'emily@example.com'),
        ('David', 'Wilson', 'david@example.com')");

    // Add sample courses (if not already there)
    $pdo->exec("INSERT IGNORE INTO courses (course_name) VALUES 
        ('ACC 20000 - Introductory Accounting'),
        ('BIO 11000 - Fundamentals of Biology I'),
        ('BUSM 10100 - Introduction to Business'),
        ('CHM 11500 - General Chemistry'),
        ('COM 11400 - Fundamentals of Speech Communication')");

    echo "✅ Sample data added successfully!<br>";
    echo "Students: " . $pdo->query("SELECT COUNT(*) FROM students")->fetchColumn() . "<br>";
    echo "Courses: " . $pdo->query("SELECT COUNT(*) FROM courses")->fetchColumn() . "<br>";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
?>
