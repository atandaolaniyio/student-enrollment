﻿<?php
require_once 'db.php';
// Check what columns exist
$columns = $pdo->query("DESCRIBE students")->fetchAll();
$columnNames = array_column($columns, 'Field');
// Determine the name column
if (in_array('name', $columnNames)) {
    $orderBy = "name";
    $nameField = 'name';
} elseif (in_array('first_name', $columnNames) && in_array('last_name', $columnNames)) {
    $orderBy = "last_name, first_name";
    $nameField = "CONCAT(first_name, ' ', last_name)";
} else {
    $orderBy = "id";
    $nameField = $columnNames[1] ?? 'id';
}
$query = "SELECT * FROM students ORDER BY $orderBy";
$students = $pdo->query($query)->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Students</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; }
        table { border-collapse: collapse; width: 100%; }
        th, td { border: 1px solid #ccc; padding: 10px; }
        th { background: #4a86e8; color: white; }
        a { color: #4a86e8; text-decoration: none; }
        a:hover { text-decoration: underline; }
    </style>
</head>
<body>
    <h2>Students</h2>
    <a href="index.php">← Back to Dashboard</a><br><br>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Major</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($students)): ?>
                <tr><td colspan="6">No students found</td></tr>
            <?php else: ?>
                <?php foreach($students as $s): ?>
                <tr>
                    <td><?= htmlspecialchars($s['id']) ?></td>
                    <td>
                        <?php 
                        if (isset($s['name'])) {
                            echo htmlspecialchars($s['name']);
                        } elseif (isset($s['first_name'])) {
                            echo htmlspecialchars($s['first_name'] . ' ' . ($s['last_name'] ?? ''));
                        } else {
                            echo 'N/A';
                        }
                        ?>
                    </td>
                    <td><?= htmlspecialchars($s['email'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($s['major'] ?? 'N/A') ?></td>
                    <td><?= htmlspecialchars($s['status'] ?? 'Active') ?></td>
                    <td>
                        <a href="student_record.php?id=<?= $s['id'] ?>">View Record</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
     </table>
</body>
</html>
