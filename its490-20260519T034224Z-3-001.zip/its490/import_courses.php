<?php
require_once 'db.php';

// Data from the CSV (ID, Course, Title, Monday, Tuesday, Wednesday, Thursday, Friday)
$courses = [
    [1,"ACC 20000/20100","Introductory Accounting/Management Accounting I","9:00am-10:30am\n12:30pm-3:00pm","12:30pm-3:00pm","1:30pm-3:00pm","1:30pm-3:00pm","N/A"],
    [2,"ASL 10200","American Sign Language II","6:00pm-9:00pm","6:30pm-9:00pm","5:00pm-6:00pm","6:30pm-9:00pm","5:00pm-9:00pm"],
    [3,"BIOL 10100/10200","Introductory Biology","9:30am-12:30pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm"],
    [4,"BIOL 21300","Human Anatomy & Physiology I","9:30am-12:30pm","1:30pm-9:00pm","3:00pm-9:00pm","N/A","10:00am-1:00pm\n5:00pm-9:00pm"],
    [5,"BIOL 21400","Human Anatomy & Physiology II","9:30am-12:30pm","1:30pm-9:00pm","3:00pm-9:00pm","N/A","10:00am-1:00pm\n5:00pm-9:00pm"],
    [6,"BIOL 22100","Introductory Microbiology","9:30am-12:30pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm"],
    [7,"BIZA 22500","Fundamental Managerial Statistics","N/A","1:30pm-3:00pm","1:30pm-3:00pm","1:30pm-3:00pm","N/A"],
    [8,"CE 11500/11600/27101","Engineering Drawing I/Engineering Drawing II/Basic Mechanics I","5:00pm-6:00pm","3:00pm-7:00pm","N/A","4:00pm-7:00pm","N/A"],
    [9,"CGT 14100","Internet Foundations Technologies & Development","8:00am-1:30pm\n2:00pm-6:00pm","8:00am-1:30pm\n2:00pm-6:00pm","8:00am-10:30am\n7:30pm-9:00pm","8:00am-1:30pm\n2:00pm-6:00pm","N/A"],
    [10,"CHM 11500","General Chemistry","9:00am-10:30am\n12:30pm-1:30pm\n5:00pm-6:00pm","12:30pm-7:00pm","N/A","4:00pm-7:00pm","N/A"],
    [11,"CHM 11600","General Chemistry","9:30am-12:30pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm"],
    [12,"CHM 11900","General Chemistry","9:30am-12:30pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm"],
    [13,"CS 12300","Programming I Java","7:00am-7:00pm","7:00am-7:00pm","7:00am-7:00pm","7:00am-7:00pm","8:00am-2:00pm\n4:00pm-7:00pm"],
    [14,"CS 12400","C++","8:00am-7:00pm","8:00am-7:00pm","8:00am-7:00pm","8:00am-2:00pm\n4:00pm-7:00pm","8:00am-4:00pm"],
    [15,"ECE 15200","Programming for Engineers","8:00am-4:00pm","8:00am-4:00pm","8:00am-4:00pm","8:00am-2:00pm","8:00am-2:00pm"],
    [16,"ECE 20100","Linear Circuits Analysis I","7:00am-11:30am\n12:30pm-5:00pm","7:00am-7:00pm","7:00am-11:30am\n12:30pm-5:00pm","7:00am-7:00pm","7:00am-7:00pm"],
    [17,"ECE 20200","Linear Circuits Analysis II","9:00am-10:30am\n12:30pm-4:30pm","12:30pm-2:30pm\n5:30pm-7:00pm","12:30pm-4:30pm","5:30pm-7:00pm","12:30pm-2:00pm"],
    [18,"ENGR 15100","Software Tools for Engineers","7:00am-6:00pm","7:00am-7:00pm","7:00am-5:00pm","7:00am-7:00pm","8:00am-2:00pm"],
    [19,"ENGR 19000","Elementary Engineering Design","9:00am-10:30am\n12:30pm-1:30pm\n5:00pm-6:00pm","12:30pm-7:00pm","N/A","4:00pm-7:00pm","N/A"],
    [20,"FR 10100/10200","French I/II","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","N/A"],
    [21,"HIST 10400/10500","Intro to the Modern World/Survey of Global History","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","N/A"],
    [22,"MA 11500","Intermediate Algebra","12:30pm-2:30pm","2:00pm-5:00pm","N/A","2:00pm-5:30pm","3:00pm-6:00pm"],
    [23,"MA 14700/14800","Algebra & Trigonometry for Technology I/II","8:00am-4:30pm","8:00am-4:00pm","8:00am-4:30pm","8:00am-2:00pm","8:00am-2:00pm"],
    [24,"MA 15300","College Algebra","7:00am-9:00pm","7:00am-9:00pm","7:00am-9:00pm","7:00am-9:00pm","7:00am-9:00pm"],
    [25,"MA 15400","Algebra & Trigonometry II","7:00am-7:00pm","7:00am-7:00pm","7:00am-7:00pm","7:00am-7:00pm","8:00am-4:00pm"],
    [26,"MA 15910","Introductory Calculus","7:00am-5:00pm","7:00am-5:00pm","7:00am-5:00pm","7:00am-5:00pm","8:00am-4:00pm"],
    [27,"MA 16019","Applied Calculus I for Technology","8:00am-4:30pm","8:00am-4:00pm","8:00am-4:30pm","8:00am-3:00pm","8:00am-4:00pm"],
    [28,"MA 16021","Applied Calculus II & Differential Equations","8:00am-10:30am\n1:30pm-4:30pm","1:30-3:00pm","8:00am-10:30am\n1:30pm-4:30pm","1:30-3:00pm","N/A"],
    [29,"MA 16031","Calculus I for Life Sciences","8:00am-6:00pm","8:00am-9:00pm","8:00am-9:00pm","8:00am-2:00pm\n4:00pm-7:00pm","8:00am-2:00pm\n5:00pm-9:00pm"],
    [30,"MA 16032","Calculus II for Life Sciences","12:30pm-6:00pm","3:00pm-9:00pm","12:30pm-9:00pm","12:30pm-9:00pm","12:30pm-2:00pm\n5:00pm-9:00pm"],
    [31,"MA 16300","Integrated Calculus Analytic Geometry I","8:00am-7:00pm","8:00am-7:00pm","8:00am-7:00pm","8:00am-7:00pm","8:00am-4:00pm"],
    [32,"MA 16400","Integrated Calculus Analytic Geometry II","8:00am-7:00pm","8:00am-10:30am\n12:30pm-7:00pm","8:00am-7:00pm","8:00am-10:30am\n12:30pm-8:00pm","8:00am-4:00pm"],
    [33,"MA 26100","Multivariate Calculus","9:00am-6:00pm","12:30pm-7:00pm","11:00am-4:30pm","1:30pm-3:00pm\n4:00pm-7:00pm","10:00am-4:00pm"],
    [34,"MA 26400","Differential Equations","9:00am-4:00pm\n5:00pm-6:00pm","12:30pm-7:00pm","10:00am-1:00pm\n2:00pm-4:00pm","4:00pm-7:00pm","10:00am-12:00pm\n2:00pm-4:00pm"],
    [35,"MA 26500","Linear Algebra","9:00am-4:00pm\n5:00pm-6:00pm","12:30pm-7:00pm","10:00am-1:00pm\n2:00pm-4:00pm","4:00pm-7:00pm","10:00am-12:00pm\n2:00pm-4:00pm"],
    [36,"ME 11500","Engineering Drawing","9:00am-10:30am\n12:30pm-1:30pm","12:30pm-2:30pm","N/A","N/A","N/A"],
    [37,"ME 27100","Basic Mechanics I","12:30pm-4:30pm","5:30pm-7:00pm","12:30pm-4:30pm","5:30pm-7:00pm","12:30pm-2:00pm"],
    [38,"ME 10101","Introduction to Parametric Modeling","8:00am-10:30am\n2:00pm-4:30pm","N/A","8:00am-10:30am\n1:00pm-4:30pm","N/A","N/A"],
    [39,"MET 10200/11800/14100","Production Design & Specifications/Applied Mechanics: Statics/Materials I","8:00am-10:30am\n2:00pm-4:30pm","N/A","8:00am-10:30am\n1:00pm-4:30pm","N/A","N/A"],
    [40,"MET 21101","","8:00am-10:30am\n2:00pm-4:30pm","N/A","8:00am-10:30am\n1:00pm-4:30pm","N/A","N/A"],
    [41,"MET 21300/24200","Dynamics/Manual Processes II","8:00am-10:30am\n2:00pm-4:30pm","N/A","8:00am-10:30am\n1:00pm-4:30pm","N/A","N/A"],
    [42,"NUR 18800","Foundations of Physical Assessment","9:00am-12:30pm\n2:00pm-4:00pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm\n3:00pm-5:00pm"],
    [43,"NUR 19202","Foundations of Nursing","9:00am-12:30pm\n2:00pm-4:00pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm\n3:00pm-5:00pm"],
    [44,"NUR 19600","Foundations of Psychosocial Nursing","9:30am-12:30pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-4:00pm"],
    [45,"NUR 27400","Essential Pharmacokinetics for Nursing","8:00am-7:00pm","8:00am-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm\n3:00pm-5:00pm"],
    [46,"NUR 27500","Alternative Therapies for Nursing Practice","9:00am-11:00am\n2:00pm-4:00pm","N/A","N/A","N/A","3:00pm-5:00pm"],
    [47,"NUR 28201","Adult Health I","9:30am-12:30pm","N/A","3:00pm-4:30pm","N/A","10:00am-1:00pm"],
    [48,"NUR 28600","Mental Health Nursing","9:00am-12:30pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm"],
    [49,"NUR 29400","Essential Pharmacotherapeutics for Nursing","9:00am-12:30pm\n2:00pm-4:00pm","1:30pm-7:00pm","3:00pm-4:30pm","N/A","10:00am-1:00pm\n3:00pm-5:00pm"],
    [50,"NUR 31702","Nursing Care of Women Through the Lifespan","11:00am-11:00am","9:00am-11:00am","N/A","N/A","9:00am-1:00pm\n3:00pm-5:00pm"],
    [51,"NUR 41500","Pathophysiology","8:00am-7:00pm","8:00am-7:00pm","3:00pm-4:30pm","N/A","9:00am-5:00pm"],
    [52,"PHIL 11000/11100","Introductory Philosophy/Ethics","N/A","8:00am-12:00pm","6:00pm-9:00pm","8:00am-12:00pm","8:00am-9:00am\n12:00pm-4:00pm"],
    [53,"PHYS 15200","Mechanics","8:00am-7:00pm","12:30pm-7:00pm","8:00am-7:00pm","4:00pm-7:00pm","12:30pm-4:00pm"],
    [54,"PHYS 22000","General Physics","8:00am-7:00pm","4:00pm-7:00pm","8:00am-7:00pm","4:00pm-7:00pm","1:00pm-4:00pm"],
    [55,"PHYS 22100","General Physics","8:00am-1:30pm\n3:30pm-7:00pm","4:00pm-7:00pm","8:00am-1:30pm\n4:30pm-7:00pm","4:00pm-7:00pm","1:00pm-4:00pm"],
    [56,"PHYS 25100/26100","Heat, Electricity, & Optics","8:00am-7:00pm","12:30pm-7:00pm","8:00am-7:00pm","4:00pm-7:00pm","12:30pm-4:00pm"],
    [57,"PSY 12000","Elementary Psychology","12:30pm-2:30pm\n4:00pm-6:00pm","2:00pm-6:00pm","4:00pm-6:00pm","2:00pm-6:00pm","3:00pm-6:00pm"],
    [58,"SCI 10500/11400","Invitation to Human Biology/Introduction to Life Sciences","9:30am-12:30pm","12:00pm-9:00pm","3:00pm-9:00pm","12:00pm-3:00pm","10:00am-1:00pm\n5:00pm-9:00pm"],
    [59,"SCI 11200","Introduction to the Physical Sciences I","9:00am-10:30am\n12:30pm-1:30pm\n5:00pm-6:00pm","12:30pm-7:00pm","N/A","4:00pm-7:00pm","N/A"],
    [60,"SOC 10000","Introductory Sociology","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","N/A"],
    [61,"SOC 38200","Introduction to Statistics in Sociology","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","4:00pm-6:00pm","N/A"],
    [62,"SPAN 10100/10200/20100/20200","Spanish I/II/III/IV","8:00am-7:00pm","8:00am-7:00pm","10:00am-12:00pm","8:00am-12:00pm","8:00am-9:00am\n12:00pm-4:00pm"],
    [63,"STAT 13000","Statistics & Contemporary Life","12:00pm-4:30pm\n6:30pm-9:00pm","7:00am-12:00pm\n1:00pm-9:00pm","12:00-4:30pm\n6:30pm-9:00pm","7:00am-2:00pm","7:00am-12:00pm\n1:00pm-9:00pm"],
    [64,"STAT 30100","Elementary Statistical Methods","8:00am-4:30pm\n6:30pm-9:00pm","7:00am-12:00pm\n1:00pm-9:00pm","8:00am-4:30pm\n6:30pm-9:00pm","7:00am-2:00pm","7:00am-12:00pm\n1:00pm-9:00pm"],
    [65,"STAT 34500","Statistics","10:00am-12:00pm\n2:00pm-4:00pm\n5:00pm-6:00pm","3:00pm-7:00pm","10:00am-1:00pm\n2:00pm-4:00pm","4:00pm-7:00pm","10:00am-12:00pm\n2:00pm-4:00pm"]
];

try {
    // Clear existing courses (optional – comment if you want to keep old ones)
    // $pdo->exec("DELETE FROM courses");
    
    $stmt = $pdo->prepare("INSERT INTO courses (course_name, title, monday, tuesday, wednesday, thursday, friday) 
                           VALUES (:course_name, :title, :monday, :tuesday, :wednesday, :thursday, :friday)
                           ON DUPLICATE KEY UPDATE 
                           title = VALUES(title), monday = VALUES(monday), tuesday = VALUES(tuesday),
                           wednesday = VALUES(wednesday), thursday = VALUES(thursday), friday = VALUES(friday)");
    
    $count = 0;
    foreach ($courses as $c) {
        $stmt->execute([
            ':course_name' => $c[1],
            ':title' => $c[2],
            ':monday' => $c[3],
            ':tuesday' => $c[4],
            ':wednesday' => $c[5],
            ':thursday' => $c[6],
            ':friday' => $c[7]
        ]);
        $count++;
    }
    echo "✅ Imported/updated $count courses.<br>\n";
    
    // Show sample
    $sample = $pdo->query("SELECT course_name, title FROM courses LIMIT 5")->fetchAll();
    echo "<br>Sample courses:<br>";
    foreach ($sample as $s) {
        echo "- {$s['course_name']}: {$s['title']}<br>";
    }
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>\n";
}
?>
