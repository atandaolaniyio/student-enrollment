<?php
require_once 'db.php';

echo "<h2>Importing Building Hours Data (Library Hours)</h2>";

// Library hours data from CSV
$libraries = [
    [
        'name' => 'Library - Hammond',
        'campus' => 1,
        'monday' => '7:00 AM - 10:30 PM',
        'tuesday' => '7:00 AM - 10:30 PM',
        'wednesday' => '7:00 AM - 10:30 PM',
        'thursday' => '7:00 AM - 10:30 PM',
        'friday' => '7:00 AM - 7:00 PM',
        'saturday' => '9:00 AM - 5:00 PM',
        'sunday' => '1:00 PM - 9:00 PM'
    ],
    [
        'name' => 'Library - Westville',
        'campus' => 2,
        'monday' => '7:00 AM - 9:00 PM',
        'tuesday' => '7:00 AM - 9:00 PM',
        'wednesday' => '7:00 AM - 9:00 PM',
        'thursday' => '7:00 AM - 9:00 PM',
        'friday' => '7:00 AM - 5:00 PM',
        'saturday' => '10:00 AM - 4:00 PM',
        'sunday' => 'CLOSED'
    ]
];

// First, check what columns exist
$columns = $pdo->query("DESCRIBE building_hours")->fetchAll();
$column_names = array_column($columns, 'Field');
echo "<p>Available columns: " . implode(', ', $column_names) . "</p>";

$inserted = 0;
$updated = 0;

echo "<h3>Processing Library Records:</h3>";
echo "<ul>";

foreach ($libraries as $library) {
    // Check if record exists
    $check = $pdo->prepare("SELECT id FROM building_hours WHERE name = ?");
    $check->execute([$library['name']]);
    $existing = $check->fetch();
    
    if ($existing) {
        // Update existing record
        $update = $pdo->prepare("UPDATE building_hours SET 
            campus = ?, 
            monday = ?, 
            tuesday = ?, 
            wednesday = ?, 
            thursday = ?, 
            friday = ?, 
            saturday = ?, 
            sunday = ? 
            WHERE name = ?");
        $update->execute([
            $library['campus'],
            $library['monday'],
            $library['tuesday'],
            $library['wednesday'],
            $library['thursday'],
            $library['friday'],
            $library['saturday'],
            $library['sunday'],
            $library['name']
        ]);
        echo "<li style='color:blue'>🔄 Updated: " . htmlspecialchars($library['name']) . "</li>";
        $updated++;
    } else {
        // Insert new record
        $insert = $pdo->prepare("INSERT INTO building_hours (name, campus, monday, tuesday, wednesday, thursday, friday, saturday, sunday) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insert->execute([
            $library['name'],
            $library['campus'],
            $library['monday'],
            $library['tuesday'],
            $library['wednesday'],
            $library['thursday'],
            $library['friday'],
            $library['saturday'],
            $library['sunday']
        ]);
        echo "<li style='color:green'>✅ Added: " . htmlspecialchars($library['name']) . "</li>";
        $inserted++;
    }
}
echo "</ul>";

echo "<hr>";
echo "<strong>Summary:</strong><br>";
echo "✅ New records added: $inserted<br>";
echo "🔄 Records updated: $updated<br>";

// Show all building hours
echo "<h3>All Building Hours Records:</h3>";
$all = $pdo->query("SELECT id, name, campus, monday, friday FROM building_hours ORDER BY id");
echo "<table border='1' cellpadding='8' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background:#4a86e8;color:white'>";
echo "<th>ID</th><th>Name</th><th>Campus</th><th>Monday Hours</th><th>Friday Hours</th>";
echo "</tr>";
while ($row = $all->fetch()) {
    $campus_name = ($row['campus'] == 1) ? 'Hammond' : (($row['campus'] == 2) ? 'Westville' : 'N/A');
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . $campus_name . "</td>";
    echo "<td>" . htmlspecialchars($row['monday'] ?? 'Not set') . "</td>";
    echo "<td>" . htmlspecialchars($row['friday'] ?? 'Not set') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo '<br><a href="admin_dashboard.php?table=building_hours" style="background:#4a86e8;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">📊 View in Admin Panel</a>';
echo ' <a href="index.php" style="background:#2c3e50;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">🏠 Back to Dashboard</a>';
?>
