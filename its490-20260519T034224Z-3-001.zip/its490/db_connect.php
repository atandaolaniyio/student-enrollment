<?php
$host = "its490db.cfcucs4a2nij.us-east-2.rds.amazonaws.com";
$user = "admin";
$pass = "hakdeldra";
$db   = "StudentList";
$port = 3306;

$conn = new mysqli($host, $user, $pass, $db, $port);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
