<?php
// Returns the most recent unread notifications for the logged-in user.
// Output: JSON { count: int, items: [{id, message, created_at}] }

header('Content-Type: application/json; charset=utf-8');

session_start();
if (!isset($_SESSION['username'])) {
    http_response_code(401);
    echo json_encode(["error" => "Not logged in"]);
    exit;
}

require_once __DIR__ . '/db_connect.php';
$conn = db_connect();

$username = $_SESSION['username'];

// Count unread
$stmt = $conn->prepare('SELECT COUNT(*) FROM notifications WHERE username = ? AND is_read = 0');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->bind_result($count);
$stmt->fetch();
$stmt->close();

// Fetch latest unread (limit 10)
$stmt = $conn->prepare('SELECT id, message, created_at FROM notifications WHERE username = ? AND is_read = 0 ORDER BY created_at DESC LIMIT 10');
$stmt->bind_param('s', $username);
$stmt->execute();
$res = $stmt->get_result();
$items = [];
while ($row = $res->fetch_assoc()) {
    $items[] = $row;
}
$stmt->close();
$conn->close();

echo json_encode(["count" => (int)$count, "items" => $items]);
?>
