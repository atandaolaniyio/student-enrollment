<?php
require_once 'db.php';

$message = '';
$error = '';
$success_count = 0;
$error_count = 0;

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_FILES['csv_file'])) {
    $file = $_FILES['csv_file'];
    
    if ($file['error'] == UPLOAD_ERR_OK) {
        $file_extension = pathinfo($file['name'], PATHINFO_EXTENSION);
        if (strtolower($file_extension) == 'csv') {
            $handle = fopen($file['tmp_name'], 'r');
            if ($handle !== false) {
                // Read header row
                $headers = fgetcsv($handle);
                
                while (($data = fgetcsv($handle)) !== false) {
                    // Map CSV columns to database columns
                    // Expected format: id,student_id,name,email,phone,major,enrollment_date,status,created_at
                    $student_id = isset($data[1]) ? trim($data[1]) : null;
                    $name = isset($data[2]) ? trim($data[2]) : '';
                    $email = isset($data[3]) ? trim($data[3]) : '';
                    $phone = isset($data[4]) ? trim($data[4]) : '';
                    $major = isset($data[5]) ? trim($data[5]) : '';
                    $enrollment_date = isset($data[6]) && !empty($data[6]) ? trim($data[6]) : date('Y-m-d');
                    $status = isset($data[7]) ? trim($data[7]) : 'Active';
                    
                    if (!empty($name)) {
                        try {
                            $stmt = $pdo->prepare("INSERT INTO students (student_id, name, email, phone, major, enrollment_date, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, NOW())");
                            $stmt->execute([$student_id, $name, $email, $phone, $major, $enrollment_date, $status]);
                            $success_count++;
                        } catch (PDOException $e) {
                            $error_count++;
                            $error .= "Error with student $name: " . $e->getMessage() . "<br>";
                        }
                    } else {
                        $error_count++;
                    }
                }
                fclose($handle);
                
                if ($success_count > 0) {
                    $message = "✅ Successfully uploaded $success_count students!";
                    if ($error_count > 0) {
                        $message .= " ($error_count failed)";
                    }
                } else {
                    $error = "No students were uploaded. Please check your CSV format.";
                }
            } else {
                $error = "Failed to open the uploaded file.";
            }
        } else {
            $error = "Please upload a valid CSV file.";
        }
    } else {
        $error = "File upload error. Please try again.";
    }
}

// Get recent students
$students = $pdo->query("SELECT * FROM students ORDER BY id DESC LIMIT 10")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Bulk Upload Students - CSV</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fb; }
        .header { background: #2c3e50; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header a { color: white; text-decoration: none; margin-left: 15px; padding: 8px 15px; border-radius: 5px; }
        .header a:hover { background: #4a86e8; }
        .container { max-width: 1200px; margin: 0 auto; padding: 30px; }
        .card { background: white; border-radius: 10px; padding: 25px; margin-bottom: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; margin-bottom: 20px; }
        .upload-area { border: 2px dashed #4a86e8; border-radius: 10px; padding: 30px; text-align: center; background: #f8f9fa; }
        input[type="file"] { margin: 15px 0; }
        button { background: #4a86e8; color: white; padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; }
        button:hover { background: #3a6ec8; }
        .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 5px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 5px; margin-bottom: 15px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #4a86e8; color: white; }
        .sample-csv { background: #f0f0f0; padding: 15px; border-radius: 5px; margin-top: 15px; }
        .sample-csv pre { background: white; padding: 10px; overflow-x: auto; }
    </style>
</head>
<body>
<div class="header">
    <h1>📤 Bulk Upload Students - CSV Import</h1>
    <div><a href="index.php">🏠 Home</a> <a href="admin_dashboard.php?table=students">👨‍🎓 Students</a> <a href="record_bank.php">📚 Record Bank</a></div>
</div>

<div class="container">
    <?php if ($message): ?>
        <div class="success"><?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card">
        <h2>📁 Upload CSV File</h2>
        <div class="upload-area">
            <form method="POST" enctype="multipart/form-data">
                <input type="file" name="csv_file" accept=".csv" required style="margin: 15px 0;">
                <br>
                <button type="submit">Upload & Import Students</button>
            </form>
        </div>
        
        <div class="sample-csv">
            <h3>📋 CSV Format Example</h3>
            <p>Your CSV should have the following columns (in this order):</p>
            <pre>id,student_id,name,email,phone,major,enrollment_date,status,created_at
,1001,John Doe,john@example.com,555-0101,Computer Science,2026-04-14,Active,
,1002,Jane Smith,jane@example.com,555-0102,Engineering,2026-04-14,Active,
,1003,Mike Johnson,mike@example.com,555-0103,Business,2026-04-14,Active,</pre>
            <p><strong>Note:</strong> The "id" column can be left empty (auto-generated). Date format: YYYY-MM-DD</p>
        </div>
    </div>

    <div class="card">
        <h2>📊 Recent Uploaded Students</h2>
        <?php if (count($students) > 0): ?>
            <table>
                <thead>
                    <tr><th>ID</th><th>Student ID</th><th>Name</th><th>Email</th><th>Major</th><th>Enrollment Date</th><th>Status</th></tr>
                </thead>
                <tbody>
                    <?php foreach ($students as $student): ?>
                    <tr>
                        <td><?php echo $student['id']; ?></td>
                        <td><?php echo htmlspecialchars($student['student_id'] ?? 'N/A'); ?></td>
                        <td><?php echo htmlspecialchars($student['name']); ?></td>
                        <td><?php echo htmlspecialchars($student['email']); ?></td>
                        <td><?php echo htmlspecialchars($student['major'] ?? 'N/A'); ?></td>
                        <td><?php echo $student['enrollment_date'] ? date('M d, Y', strtotime($student['enrollment_date'])) : date('M d, Y', strtotime($student['created_at'])); ?></td>
                        <td><span class="status-badge" style="background:#d4edda;color:#155724;padding:4px 8px;border-radius:4px;"><?php echo htmlspecialchars($student['status'] ?? 'Active'); ?></span></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p>No students uploaded yet. Use the form above to import students.</p>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
