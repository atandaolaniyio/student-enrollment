<?php
require_once 'db.php';

echo "<h2>Importing Complete Building Hours Data</h2>";
echo "<p>This will import/update all 22 campus buildings with their operating hours.</p>";

// Complete building hours data from CSV
$buildings = [
    [1, "E. D. Anderson Building (ANDR)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "7:00 AM - 5:00 PM", "CLOSED"],
    [2, "Classroom/Office Building (CLO)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "CLOSED", "CLOSED"],
    [3, "Millard E. Gyte Science Building (GYTE)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "CLOSED", "CLOSED"],
    [4, "Hospitality & Tourism Management Building (HTMB)", 1, "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 5:00 PM", "CLOSED", "CLOSED"],
    [5, "Nils K. Nelson Bioscience Innovation Building (NILS)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "7:00 AM - 5:00 PM", "CLOSED"],
    [6, "Gene Stratton Porter Hall (PORT)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "CLOSED", "CLOSED"],
    [7, "Andrew A. Potter Laboratories Building (POTT)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "CLOSED", "CLOSED"],
    [8, "Donald S. Powers Computer Education Building (PWRS)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 7:00 PM", "CLOSED", "CLOSED"],
    [9, "Student Union and Library Building (SULB)", 1, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 5:00 PM", "9:00 AM - 3:00 PM", "CLOSED"],
    [10, "David Roberts Center for Innovation & Design (IDET)", 1, "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "CLOSED", "CLOSED"],
    [11, "Commercialization & Manufacturing Excellence Center (CMEC)", 1, "5:00 PM - 8:00 PM", "CLOSED", "5:00 PM - 8:00 PM", "5:00 PM - 8:00 PM", "CLOSED", "CLOSED", "CLOSED"],
    [12, "Indianapolis Boulevard Counseling Center (IBCC)", 1, "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "CLOSED", "CLOSED"],
    [13, "Hammond Fitness & Recreation Center (FNRC)", 1, "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "9:00 AM - 12:00 PM", "12:00 PM - 3:00 PM"],
    [14, "C. H. Lawshe Hall (LAWS)", 1, "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "CLOSED", "CLOSED"],
    [15, "Charlotte R. Riley Center (RILY)", 1, "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "CLOSED", "CLOSED"],
    [16, "Schneider Avenue Building (SAB)", 1, "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "CLOSED", "CLOSED"],
    [17, "University Services Building (UNSV)", 1, "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "8:00 AM - 4:30 PM", "CLOSED", "CLOSED"],
    [18, "Library Student Faculty Building (LSF)", 2, "7:00 AM - 9:00 PM", "7:00 AM - 9:00 PM", "7:00 AM - 9:00 PM", "7:00 AM - 9:00 PM", "7:00 AM - 5:00 PM", "9:00 AM - 3:00 PM", "CLOSED"],
    [19, "Robert F. Schwarz Hall (SWRZ)", 2, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 5:00 PM", "CLOSED", "CLOSED"],
    [20, "Technology Building (TECH)", 2, "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 10:30 PM", "7:00 AM - 5:00 PM", "CLOSED", "CLOSED"],
    [21, "Physical Facilities/Campus Police (PFCP)", 2, "8:00 AM - 4:00 PM", "8:00 AM - 4:00 PM", "8:00 AM - 4:00 PM", "8:00 AM - 4:00 PM", "8:00 AM - 4:00 PM", "CLOSED", "CLOSED"],
    [22, "James B. Dworkin Student Services & Athletic Complex (DSAC)", 2, "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "7:00 AM - 7:00 PM", "CLOSED", "CLOSED"]
];

$inserted = 0;
$updated = 0;

echo "<h3>Processing Building Records:</h3>";
echo "<table border='1' cellpadding='5' style='border-collapse: collapse;'>";
echo "<tr style='background:#4a86e8;color:white'><th>ID</th><th>Building Name</th><th>Campus</th><th>Status</th></tr>";

foreach ($buildings as $building) {
    list($id, $name, $campus, $mon, $tue, $wed, $thu, $fri, $sat, $sun) = $building;
    
    // Check if record exists
    $check = $pdo->prepare("SELECT id FROM building_hours WHERE name = ?");
    $check->execute([$name]);
    $existing = $check->fetch();
    
    $campus_name = ($campus == 1) ? 'Hammond' : 'Westville';
    
    if ($existing) {
        // Update existing record
        $update = $pdo->prepare("UPDATE building_hours SET 
            campus = ?, 
            monday = ?, 
            tuesday = ?, 
            wednesday = ?, 
            thursday = ?, 
            friday = ?, 
            saturday = ?, 
            sunday = ? 
            WHERE name = ?");
        $update->execute([$campus, $mon, $tue, $wed, $thu, $fri, $sat, $sun, $name]);
        echo "<tr style='background:#fff3cd'><td>$id</td><td>" . htmlspecialchars($name) . "</td><td>$campus_name</td><td>🔄 Updated</td></tr>";
        $updated++;
    } else {
        // Insert new record
        $insert = $pdo->prepare("INSERT INTO building_hours (id, name, campus, monday, tuesday, wednesday, thursday, friday, saturday, sunday) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $insert->execute([$id, $name, $campus, $mon, $tue, $wed, $thu, $fri, $sat, $sun]);
        echo "<tr style='background:#d4edda'><td>$id</td><td>" . htmlspecialchars($name) . "</td><td>$campus_name</td><td>✅ Added</td></tr>";
        $inserted++;
    }
}
echo "</table>";

echo "<hr>";
echo "<strong>Summary:</strong><br>";
echo "✅ New buildings added: $inserted<br>";
echo "🔄 Existing buildings updated: $updated<br>";
echo "📊 Total buildings processed: " . ($inserted + $updated) . "<br>";

// Show all buildings by campus
echo "<h3>Building Hours by Campus:</h3>";

// Hammond Campus Buildings
$hammond = $pdo->query("SELECT id, name, monday, friday FROM building_hours WHERE campus = 1 ORDER BY name");
echo "<h4>🏛️ Hammond Campus Buildings (" . $hammond->rowCount() . ")</h4>";
echo "<table border='1' cellpadding='6' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background:#4a86e8;color:white'><th>ID</th><th>Building Name</th><th>Monday Hours</th><th>Friday Hours</th></tr>";
while ($row = $hammond->fetch()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['monday'] ?? 'N/A') . "</td>";
    echo "<td>" . htmlspecialchars($row['friday'] ?? 'N/A') . "</td>";
    echo "</tr>";
}
echo "</table>";

// Westville Campus Buildings
$westville = $pdo->query("SELECT id, name, monday, friday FROM building_hours WHERE campus = 2 ORDER BY name");
echo "<h4>🏛️ Westville Campus Buildings (" . $westville->rowCount() . ")</h4>";
echo "<table border='1' cellpadding='6' style='border-collapse: collapse; width: 100%;'>";
echo "<tr style='background:#4a86e8;color:white'><th>ID</th><th>Building Name</th><th>Monday Hours</th><th>Friday Hours</th></tr>";
while ($row = $westville->fetch()) {
    echo "<tr>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['monday'] ?? 'N/A') . "</td>";
    echo "<td>" . htmlspecialchars($row['friday'] ?? 'N/A') . "</td>";
    echo "</tr>";
}
echo "</table>";

echo '<br><a href="admin_dashboard.php?table=building_hours" style="background:#4a86e8;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">📊 View All Building Hours in Admin Panel</a>';
echo ' <a href="building_hours.php" style="background:#6c757d;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">🏢 View Building Hours Page</a>';
echo ' <a href="index.php" style="background:#2c3e50;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">🏠 Back to Dashboard</a>';
?>
