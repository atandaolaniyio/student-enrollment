<?php
require_once 'config.php';

if(isset($_POST['id'])) {
    $id = intval($_POST['id']);
    
    // Mark as read
    $sql = "UPDATE notifications SET is_read = TRUE WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $success = $stmt->execute();
    
    // Get updated count
    $current_user_id = 1; // Get from session in real app
    $count_sql = "SELECT COUNT(*) as count FROM notifications 
                  WHERE (user_id = ? OR user_id IS NULL) 
                  AND is_read = FALSE";
    $stmt = $conn->prepare($count_sql);
    $stmt->bind_param("i", $current_user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $count = $result->fetch_assoc()['count'];
    
    echo json_encode([
        'success' => $success,
        'new_count' => $count
    ]);
}
?>
