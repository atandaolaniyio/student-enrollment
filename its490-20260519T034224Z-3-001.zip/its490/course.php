<?php
require_once 'db.php';
$id = $_GET['id'] ?? 0;
$course = $pdo->prepare("SELECT * FROM courses WHERE id = ?");
$course->execute([$id]);
$c = $course->fetch();
if (!$c) {
    die("Course not found.");
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?= htmlspecialchars($c['course_name']) ?> - Schedule</title>
    <style>
        body {font-family: Arial, sans-serif; margin: 30px;}
        .schedule-table {border-collapse: collapse; width: 100%; margin-top: 20px;}
        .schedule-table th, .schedule-table td {border: 1px solid #ccc; padding: 12px; vertical-align: top;}
        .schedule-table th {background: #4a86e8; color: white; width: 14%;}
        .day {background: #f0f0f0; font-weight: bold;}
        .time-slot {white-space: pre-wrap; line-height: 1.4;}
        a {color: #4a86e8; text-decoration: none;}
        a:hover {text-decoration: underline;}
        .back-link {margin-bottom: 20px; display: inline-block;}
    </style>
</head>
<body>
    <a href="courses.php" class="back-link">← Back to all courses</a>
    <h2><?= htmlspecialchars($c['course_name']) ?></h2>
    <h3><?= htmlspecialchars($c['title']) ?></h3>

    <table class="schedule-table">
        <tr>
            <th>Monday</th>
            <th>Tuesday</th>
            <th>Wednesday</th>
            <th>Thursday</th>
            <th>Friday</th>
        </tr>
        <tr>
            <td class="time-slot"><?= nl2br(htmlspecialchars($c['monday'] ?? 'N/A')) ?></td>
            <td class="time-slot"><?= nl2br(htmlspecialchars($c['tuesday'] ?? 'N/A')) ?></td>
            <td class="time-slot"><?= nl2br(htmlspecialchars($c['wednesday'] ?? 'N/A')) ?></td>
            <td class="time-slot"><?= nl2br(htmlspecialchars($c['thursday'] ?? 'N/A')) ?></td>
            <td class="time-slot"><?= nl2br(htmlspecialchars($c['friday'] ?? 'N/A')) ?></td>
        </tr>
    </table>

    <br>
    <a href="add_enrollment.php?course_id=<?= $c['id'] ?>">➕ Enroll in this course</a>
</body>
</html>
