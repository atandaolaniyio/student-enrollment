<?php
require_once '../includes/Database.php';

$db = new Database();
$conn = $db->getConnection();

$id = $_GET['id'] ?? 0;

// Get student details
$stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) {
    header('Location: students.php');
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Details</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .details-card {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .details-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin: 20px 0;
        }
        .detail-item {
            border-bottom: 1px solid #eee;
            padding: 10px 0;
        }
        .detail-label {
            font-weight: bold;
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <div class="container">
        <header>
            <h1><i class="fas fa-user"></i> Student Details</h1>
            <p><a href="students.php">← Back to Students List</a></p>
        </header>

        <main>
            <div class="details-card">
                <h2><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></h2>
                
                <div class="details-grid">
                    <div class="detail-item"><span class="detail-label">Student ID:</span> <?php echo htmlspecialchars($student['student_id']); ?></div>
                    <div class="detail-item"><span class="detail-label">Email:</span> <?php echo htmlspecialchars($student['email']); ?></div>
                    <div class="detail-item"><span class="detail-label">Age:</span> <?php echo $student['age'] ?: 'N/A'; ?></div>
                    <div class="detail-item"><span class="detail-label">Date of Birth:</span> <?php echo $student['date_of_birth'] ?: 'N/A'; ?></div>
                    <div class="detail-item"><span class="detail-label">Gender:</span> <?php echo $student['gender'] ?: 'N/A'; ?></div>
                    <div class="detail-item"><span class="detail-label">Phone:</span> <?php echo htmlspecialchars($student['phone'] ?: 'N/A'); ?></div>
                    <div class="detail-item"><span class="detail-label">Address:</span> <?php echo htmlspecialchars($student['address'] ?: 'N/A'); ?></div>
                    <div class="detail-item"><span class="detail-label">City/State:</span> <?php echo htmlspecialchars($student['city'] ? $student['city'] . ', ' . $student['state'] : 'N/A'); ?></div>
                    <div class="detail-item"><span class="detail-label">Zip Code:</span> <?php echo htmlspecialchars($student['zip_code'] ?: 'N/A'); ?></div>
                    <div class="detail-item"><span class="detail-label">Country:</span> <?php echo htmlspecialchars($student['country']); ?></div>
                    <div class="detail-item"><span class="detail-label">Enrollment Date:</span> <?php echo date('F j, Y', strtotime($student['enrollment_date'])); ?></div>
                </div>
            </div>

            <!-- Social Media Links -->
            <div style="text-align: center; margin: 40px 0;">
                <h3 style="color: var(--primary-color);">Connect With Us</h3>
                <a href="https://facebook.com/yourpage" target="_blank" style="margin: 0 10px; color: #1877f2; font-size: 24px;"><i class="fab fa-facebook"></i></a>
                <a href="https://twitter.com/yourpage" target="_blank" style="margin: 0 10px; color: #1da1f2; font-size: 24px;"><i class="fab fa-twitter"></i></a>
                <a href="https://wa.me/1234567890" target="_blank" style="margin: 0 10px; color: #25d366; font-size: 24px;"><i class="fab fa-whatsapp"></i></a>
            </div>
        </main>
    </div>
</body>
</html>
