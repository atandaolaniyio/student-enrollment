<?php
require_once '../includes/Database.php';
$db = new Database();
$conn = $db->getConnection();

// Get all courses
$courses = $conn->query("SELECT * FROM courses ORDER BY course_code")->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PNW Dual Credit Courses</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .nav-bar {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .nav-link {
            padding: 8px 15px;
            background: var(--light-color);
            border-radius: 5px;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s;
        }
        .nav-link:hover, .nav-link.active {
            background: #4b6cb7;
            color: white;
        }
        table {
            width: 100%;
            background: white;
            border-collapse: collapse;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            border-radius: 8px;
            overflow: hidden;
        }
        th {
            background: #4b6cb7;
            color: white;
            padding: 15px;
            text-align: left;
        }
        td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }
        tr:hover {
            background: #f5f5f5;
        }
        .course-code {
            font-weight: bold;
            color: #4b6cb7;
        }
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: inline-block;
        }
        .purdue-header {
            background: #4b6cb7;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .dual-credit-badge {
            background: #ffc107;
            color: #333;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 14px;
            font-weight: bold;
            display: inline-block;
        }
        .course-card {
            background: #e8f5e8;
            border-left: 4px solid #2e7d32;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Purdue Header -->
        <div class="purdue-header">
            <h1><i class="fas fa-book"></i> Purdue Northwest - Dual Credit Courses</h1>
            <p>College courses available to high school students through dual credit</p>
        </div>

        <!-- Navigation Bar -->
        <div class="nav-bar">
            <a href="../index.php" class="nav-link"><i class="fas fa-home"></i> PNW Home</a>
            <a href="../dashboard.php" class="nav-link"><i class="fas fa-compass"></i> Dashboard</a>
            <a href="students.php" class="nav-link"><i class="fas fa-users"></i> Dual Credit Students</a>
            <a href="register-student.php" class="nav-link"><i class="fas fa-user-plus"></i> Register for PNW</a>
            <a href="enroll-course.php" class="nav-link"><i class="fas fa-book"></i> Enroll in Dual Credit</a>
            <a href="courses.php" class="nav-link active"><i class="fas fa-graduation-cap"></i> PNW Courses</a>
        </div>

        <!-- Dual Credit Course Info -->
        <div class="course-card">
            <h3 style="color: #2e7d32; margin-bottom: 10px;"><i class="fas fa-star"></i> Earn College Credit Now!</h3>
            <p>These courses are approved for dual credit at Purdue University Northwest. Successful completion grants you credit at both your high school and Purdue Northwest.</p>
            <div style="margin-top: 10px;">
                <span class="dual-credit-badge"><i class="fas fa-check"></i> All courses are dual credit eligible</span>
            </div>
        </div>

        <main>
            <!-- Statistics -->
            <div class="stats-card">
                <h3><i class="fas fa-book"></i> Total Dual Credit Courses: <?php echo count($courses); ?></h3>
            </div>

            <?php if (empty($courses)): ?>
                <div class="empty-state">
                    <i class="fas fa-info-circle" style="font-size: 3em; color: #ccc;"></i>
                    <p>No dual credit courses available at this time.</p>
                </div>
            <?php else: ?>
                <table>
                    <thead>
                        <tr>
                            <th>Course Code</th>
                            <th>Course Name</th>
                            <th>Credits</th>
                            <th>Instructor</th>
                            <th>Description</th>
                            <th>Dual Credit</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($courses as $course): ?>
                        <tr>
                            <td class="course-code"><?php echo htmlspecialchars($course['course_code']); ?></td>
                            <td><strong><?php echo htmlspecialchars($course['course_name']); ?></strong></td>
                            <td><?php echo $course['credits']; ?></td>
                            <td><?php echo htmlspecialchars($course['instructor']); ?></td>
                            <td><?php echo htmlspecialchars(substr($course['description'], 0, 100)); ?>...</td>
                            <td><span style="background: #2e7d32; color: white; padding: 3px 8px; border-radius: 3px; font-size: 12px;">✓ Eligible</span></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>

            <!-- Quick Links -->
            <div style="text-align: center; margin: 30px 0;">
                <a href="enroll-course.php" class="btn" style="background: #4b6cb7; margin-right: 10px;">
                    <i class="fas fa-graduation-cap"></i> Enroll in Dual Credit Courses
                </a>
                <a href="register-student.php" class="btn" style="background: #2e7d32;">
                    <i class="fas fa-user-plus"></i> Register as Dual Credit Student
                </a>
            </div>

            <!-- Social Media Links -->
            <div style="text-align: center; margin: 40px 0 20px;">
                <h3 style="color: #4b6cb7; margin-bottom: 15px;">
                    <i class="fas fa-share-alt"></i> Connect with Purdue Northwest
                </h3>
                <div>
                    <a href="https://facebook.com/PurdueNorthwest" target="_blank" style="background: #1877f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-facebook"></i> Facebook
                    </a>
                    <a href="https://twitter.com/PurdueNW" target="_blank" style="background: #1da1f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <a href="https://www.pnw.edu/admissions/dual-credit/" target="_blank" style="background: #25d366; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fas fa-graduation-cap"></i> Dual Credit Info
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> Purdue University Northwest - Dual Credit Program. All rights reserved.</p>
            <p style="font-size: 12px; margin-top: 10px;">2200 169th Street, Hammond, Indiana 46323 | (219) 989-2400</p>
        </footer>
    </div>
</body>
</html>
