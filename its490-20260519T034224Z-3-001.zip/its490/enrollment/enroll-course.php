<?php
require_once '../includes/Database.php';

$db = new Database();
$conn = $db->getConnection();

// Get all students and courses
$students = $conn->query("SELECT id, student_id, first_name, last_name, high_school FROM students ORDER BY last_name")->fetchAll();
$courses = $conn->query("SELECT id, course_code, course_name, credits, instructor FROM courses ORDER BY course_code")->fetchAll();

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'] ?? 0;
    $course_id = $_POST['course_id'] ?? 0;
    
    if ($student_id && $course_id) {
        try {
            $stmt = $conn->prepare("INSERT INTO enrollments (student_id, course_id) VALUES (?, ?)");
            if ($stmt->execute([$student_id, $course_id])) {
                $message = '<div class="success-message">Dual credit enrollment successful! Student enrolled in course.</div>';
            }
        } catch (PDOException $e) {
            if ($e->errorInfo[1] == 1062) {
                $error = '<div class="error">Student already enrolled in this dual credit course!</div>';
            } else {
                $error = '<div class="error">Error: ' . $e->getMessage() . '</div>';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>PNW Dual Credit Enrollment</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .nav-bar {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .nav-link {
            padding: 8px 15px;
            background: var(--light-color);
            border-radius: 5px;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s;
        }
        .nav-link:hover, .nav-link.active {
            background: #4b6cb7;
            color: white;
        }
        .enrollment-form {
            max-width: 600px;
            margin: 0 auto;
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        select {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            margin-top: 5px;
        }
        .form-group {
            margin-bottom: 25px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .btn-enroll {
            background: #4b6cb7;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
        }
        .btn-enroll:hover {
            background: #182848;
        }
        .purdue-header {
            background: #4b6cb7;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .dual-credit-badge {
            background: #ffc107;
            color: #333;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            margin-left: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Purdue Header -->
        <div class="purdue-header">
            <h1><i class="fas fa-graduation-cap"></i> Purdue Northwest</h1>
            <h2>Dual Credit Course Enrollment</h2>
            <p>Enroll high school students in college courses</p>
        </div>

        <!-- Navigation Bar -->
        <div class="nav-bar">
            <a href="../index.php" class="nav-link"><i class="fas fa-home"></i> PNW Home</a>
            <a href="../dashboard.php" class="nav-link"><i class="fas fa-compass"></i> Dashboard</a>
            <a href="students.php" class="nav-link"><i class="fas fa-users"></i> Dual Credit Students</a>
            <a href="register-student.php" class="nav-link"><i class="fas fa-user-plus"></i> Register for PNW</a>
            <a href="enroll-course.php" class="nav-link active"><i class="fas fa-book"></i> Enroll in Dual Credit</a>
            <a href="courses.php" class="nav-link"><i class="fas fa-graduation-cap"></i> PNW Courses</a>
        </div>

        <main>
            <div class="enrollment-form">
                <h3 style="color: #4b6cb7; margin-bottom: 20px; text-align: center;">
                    <i class="fas fa-pen"></i> Dual Credit Course Registration
                </h3>
                
                <?php echo $message; ?>
                <?php echo $error; ?>
                
                <form method="POST">
                    <div class="form-group">
                        <label><i class="fas fa-user-graduate"></i> Select Dual Credit Student:</label>
                        <select name="student_id" required>
                            <option value="">-- Choose a student --</option>
                            <?php foreach ($students as $student): ?>
                                <option value="<?php echo $student['id']; ?>">
                                    <?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?> 
                                    (<?php echo htmlspecialchars($student['student_id']); ?>)
                                    <?php if (!empty($student['high_school'])): ?>
                                        - <?php echo htmlspecialchars($student['high_school']); ?>
                                    <?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label><i class="fas fa-book"></i> Select Dual Credit Course:</label>
                        <select name="course_id" required>
                            <option value="">-- Choose a course --</option>
                            <?php foreach ($courses as $course): ?>
                                <option value="<?php echo $course['id']; ?>">
                                    <?php echo htmlspecialchars($course['course_code'] . ' - ' . $course['course_name']); ?> 
                                    (<?php echo $course['credits']; ?> credits) - <?php echo htmlspecialchars($course['instructor']); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    
                    <div style="background: #e8f5e8; padding: 15px; border-radius: 4px; margin: 20px 0;">
                        <p style="margin: 0; color: #2e7d32;">
                            <i class="fas fa-info-circle"></i> 
                            By enrolling, this student will earn both high school and Purdue Northwest college credit upon successful completion.
                        </p>
                    </div>
                    
                    <button type="submit" class="btn-enroll">
                        <i class="fas fa-check-circle"></i> Confirm Dual Credit Enrollment
                    </button>
                </form>
            </div>

            <!-- Social Media Links -->
            <div style="text-align: center; margin: 40px 0 20px;">
                <h3 style="color: #4b6cb7; margin-bottom: 15px;">
                    <i class="fas fa-share-alt"></i> Connect with Purdue Northwest
                </h3>
                <div>
                    <a href="https://facebook.com/PurdueNorthwest" target="_blank" style="background: #1877f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-facebook"></i> Facebook
                    </a>
                    <a href="https://twitter.com/PurdueNW" target="_blank" style="background: #1da1f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <a href="https://www.pnw.edu/admissions/dual-credit/" target="_blank" style="background: #25d366; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fas fa-graduation-cap"></i> Dual Credit Info
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> Purdue University Northwest - Dual Credit Program. All rights reserved.</p>
            <p style="font-size: 12px; margin-top: 10px;">2200 169th Street, Hammond, Indiana 46323 | (219) 989-2400</p>
        </footer>
    </div>
</body>
</html>
