<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once '../includes/Database.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $student_id = $_POST['student_id'] ?? '';
    $first_name = $_POST['first_name'] ?? '';
    $last_name = $_POST['last_name'] ?? '';
    $age = $_POST['age'] ?? null;
    $date_of_birth = $_POST['date_of_birth'] ?? null;
    $gender = $_POST['gender'] ?? '';
    $email = $_POST['email'] ?? '';
    $phone = $_POST['phone'] ?? '';
    $address = $_POST['address'] ?? '';
    $city = $_POST['city'] ?? '';
    $state = $_POST['state'] ?? '';
    $zip_code = $_POST['zip_code'] ?? '';
    $country = $_POST['country'] ?? 'USA';
    $high_school = $_POST['high_school'] ?? '';
    $graduation_year = $_POST['graduation_year'] ?? '';
    
    if ($student_id && $first_name && $last_name && $email) {
        try {
            $db = new Database();
            $conn = $db->getConnection();
            
            // Add high_school and graduation_year columns if they don't exist
            $conn->exec("ALTER TABLE students ADD COLUMN IF NOT EXISTS high_school VARCHAR(100)");
            $conn->exec("ALTER TABLE students ADD COLUMN IF NOT EXISTS graduation_year INT");
            
            $stmt = $conn->prepare("INSERT INTO students 
                (student_id, first_name, last_name, age, date_of_birth, gender, email, phone, address, city, state, zip_code, country, high_school, graduation_year) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            
            if ($stmt->execute([$student_id, $first_name, $last_name, $age, $date_of_birth, $gender, $email, $phone, $address, $city, $state, $zip_code, $country, $high_school, $graduation_year])) {
                header('Location: students.php?added=1');
                exit();
            }
        } catch (PDOException $e) {
            if ($e->errorInfo[1] == 1062) {
                $error = '<div class="error">Student ID or Email already exists!</div>';
            } else {
                $error = '<div class="error">Error: ' . $e->getMessage() . '</div>';
            }
        }
    } else {
        $error = '<div class="error">Student ID, Name, and Email are required!</div>';
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PNW Dual Credit Registration</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .registration-form {
            background: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            max-width: 800px;
            margin: 0 auto;
        }
        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
            margin-bottom: 15px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #333;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .form-group textarea {
            height: 100px;
        }
        .btn-submit {
            background: #4b6cb7;
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            width: 100%;
            margin-top: 20px;
        }
        .btn-submit:hover {
            background: #182848;
        }
        .required::after {
            content: " *";
            color: red;
        }
        .nav-bar {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .nav-link {
            padding: 8px 15px;
            background: var(--light-color);
            border-radius: 5px;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s;
        }
        .nav-link:hover {
            background: #4b6cb7;
            color: white;
        }
        .purdue-header {
            background: #4b6cb7;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .dual-credit-info {
            background: #e8f5e8;
            border-left: 4px solid #2e7d32;
            padding: 20px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Purdue Header -->
        <div class="purdue-header">
            <h1><i class="fas fa-user-graduate"></i> Purdue University Northwest</h1>
            <h2>Dual Credit Student Registration</h2>
        </div>

        <!-- Navigation Bar -->
        <div class="nav-bar">
            <a href="../index.php" class="nav-link"><i class="fas fa-home"></i> PNW Home</a>
            <a href="../dashboard.php" class="nav-link"><i class="fas fa-compass"></i> Dashboard</a>
            <a href="students.php" class="nav-link"><i class="fas fa-users"></i> Dual Credit Students</a>
            <a href="register-student.php" class="nav-link" style="background: #4b6cb7; color: white;"><i class="fas fa-user-plus"></i> Register for PNW</a>
            <a href="enroll-course.php" class="nav-link"><i class="fas fa-book"></i> Enroll in Dual Credit</a>
            <a href="courses.php" class="nav-link"><i class="fas fa-graduation-cap"></i> PNW Courses</a>
        </div>

        <!-- Dual Credit Info Box -->
        <div class="dual-credit-info">
            <h3 style="color: #2e7d32; margin-bottom: 10px;"><i class="fas fa-star"></i> Dual Credit Program Information</h3>
            <p>As a dual credit student at Purdue University Northwest, you'll earn both high school and college credit simultaneously. Complete this registration to begin your journey.</p>
            <ul style="margin-top: 10px; margin-left: 20px; color: #333;">
                <li>Earn college credits while in high school</li>
                <li>Save on future tuition costs</li>
                <li>Smooth transition to Purdue Northwest after graduation</li>
                <li>Access to university resources and support</li>
                <li>Courses taught by qualified PNW instructors</li>
            </ul>
        </div>

        <main>
            <?php echo $error; ?>
            
            <div class="registration-form">
                <h3 style="color: #4b6cb7; margin-bottom: 20px;"><i class="fas fa-edit"></i> Dual Credit Student Application</h3>
                <form method="POST">
                    <div class="form-row">
                        <div class="form-group">
                            <label class="required">PNW Student ID / High School ID:</label>
                            <input type="text" name="student_id" required placeholder="e.g., DC2024001">
                        </div>
                        <div class="form-group">
                            <label class="required">Email:</label>
                            <input type="email" name="email" required placeholder="student@example.com">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label class="required">First Name:</label>
                            <input type="text" name="first_name" required>
                        </div>
                        <div class="form-group">
                            <label class="required">Last Name:</label>
                            <input type="text" name="last_name" required>
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Age:</label>
                            <input type="number" name="age" min="14" max="100">
                        </div>
                        <div class="form-group">
                            <label>Date of Birth:</label>
                            <input type="date" name="date_of_birth">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Gender:</label>
                            <select name="gender">
                                <option value="">Select Gender</option>
                                <option value="Male">Male</option>
                                <option value="Female">Female</option>
                                <option value="Other">Other</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Phone:</label>
                            <input type="tel" name="phone" placeholder="(555) 123-4567">
                        </div>
                    </div>

                    <!-- New Dual Credit Specific Fields -->
                    <div class="form-row">
                        <div class="form-group">
                            <label>High School:</label>
                            <input type="text" name="high_school" placeholder="Name of your high school">
                        </div>
                        <div class="form-group">
                            <label>Graduation Year:</label>
                            <select name="graduation_year">
                                <option value="">Select Year</option>
                                <option value="2024">2024</option>
                                <option value="2025">2025</option>
                                <option value="2026">2026</option>
                                <option value="2027">2027</option>
                                <option value="2028">2028</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Address:</label>
                        <textarea name="address" placeholder="Street address"></textarea>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>City:</label>
                            <input type="text" name="city">
                        </div>
                        <div class="form-group">
                            <label>State:</label>
                            <input type="text" name="state" value="IN">
                        </div>
                    </div>

                    <div class="form-row">
                        <div class="form-group">
                            <label>Zip Code:</label>
                            <input type="text" name="zip_code">
                        </div>
                        <div class="form-group">
                            <label>Country:</label>
                            <input type="text" name="country" value="USA">
                        </div>
                    </div>

                    <p style="color: #666; font-size: 14px; margin: 20px 0;"><i class="fas fa-info-circle"></i> By registering, you agree to participate in the Purdue Northwest Dual Credit Program.</p>

                    <button type="submit" class="btn-submit">
                        <i class="fas fa-save"></i> Register for Dual Credit Program
                    </button>
                </form>
            </div>

            <!-- Social Media Links -->
            <div style="text-align: center; margin: 40px 0 20px;">
                <h3 style="color: #4b6cb7; margin-bottom: 15px;">
                    <i class="fas fa-share-alt"></i> Connect with Purdue Northwest
                </h3>
                <div>
                    <a href="https://facebook.com/PurdueNorthwest" target="_blank" style="background: #1877f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-facebook"></i> Facebook
                    </a>
                    <a href="https://twitter.com/PurdueNW" target="_blank" style="background: #1da1f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <a href="https://www.pnw.edu/admissions/dual-credit/" target="_blank" style="background: #25d366; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fas fa-graduation-cap"></i> Dual Credit Info
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> Purdue University Northwest - Dual Credit Program. All rights reserved.</p>
            <p style="font-size: 12px;">2200 169th Street, Hammond, Indiana 46323 | (219) 989-2400</p>
        </footer>
    </div>
</body>
</html>
