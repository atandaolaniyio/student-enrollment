<?php
require_once '../includes/Database.php';

$db = new Database();
$conn = $db->getConnection();

// Get search parameter
$search = $_GET['search'] ?? '';

// Get all students with search
if ($search) {
    $stmt = $conn->prepare("SELECT * FROM students WHERE 
        student_id LIKE ? OR 
        first_name LIKE ? OR 
        last_name LIKE ? OR 
        email LIKE ? OR
        high_school LIKE ?
        ORDER BY enrollment_date DESC");
    $searchTerm = "%$search%";
    $stmt->execute([$searchTerm, $searchTerm, $searchTerm, $searchTerm, $searchTerm]);
    $students = $stmt->fetchAll();
} else {
    $stmt = $conn->query("SELECT * FROM students ORDER BY enrollment_date DESC");
    $students = $stmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PNW Dual Credit Students</title>
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        .search-box {
            margin: 20px 0;
            display: flex;
            gap: 10px;
        }
        .search-box input {
            flex: 1;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .search-box button {
            padding: 10px 20px;
            background: #4b6cb7;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background: white;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        th {
            background: #4b6cb7;
            color: white;
            padding: 12px;
            text-align: left;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background: #f5f5f5;
        }
        .action-btn {
            padding: 5px 10px;
            margin: 0 2px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
            color: white;
            text-decoration: none;
            display: inline-block;
        }
        .view-btn { background: #4b6cb7; }
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            display: inline-block;
            margin-right: 20px;
        }
        .nav-bar {
            background: white;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
        }
        .nav-link {
            padding: 8px 15px;
            background: var(--light-color);
            border-radius: 5px;
            text-decoration: none;
            color: var(--text-color);
            transition: all 0.3s;
        }
        .nav-link:hover, .nav-link.active {
            background: #4b6cb7;
            color: white;
        }
        .purdue-header {
            background: #4b6cb7;
            color: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            text-align: center;
        }
        .dual-credit-badge {
            background: #ffc107;
            color: #333;
            padding: 3px 8px;
            border-radius: 3px;
            font-size: 12px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Purdue Header -->
        <div class="purdue-header">
            <h1><i class="fas fa-users"></i> Purdue Northwest - Dual Credit Students</h1>
            <p>High school students enrolled in dual credit programs</p>
        </div>

        <!-- Navigation Bar -->
        <div class="nav-bar">
            <a href="../index.php" class="nav-link"><i class="fas fa-home"></i> PNW Home</a>
            <a href="../dashboard.php" class="nav-link"><i class="fas fa-compass"></i> Dashboard</a>
            <a href="students.php" class="nav-link active"><i class="fas fa-users"></i> Dual Credit Students</a>
            <a href="register-student.php" class="nav-link"><i class="fas fa-user-plus"></i> Register for PNW</a>
            <a href="enroll-course.php" class="nav-link"><i class="fas fa-book"></i> Enroll in Dual Credit</a>
            <a href="courses.php" class="nav-link"><i class="fas fa-graduation-cap"></i> PNW Courses</a>
        </div>

        <main>
            <?php if (isset($_GET['added'])): ?>
                <div class="success-message">
                    <i class="fas fa-check-circle"></i> Dual Credit student registered successfully!
                </div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="stats-card">
                <h3><i class="fas fa-users"></i> Total Dual Credit Students: <?php echo count($students); ?></h3>
            </div>

            <!-- Search Box -->
            <form method="GET" class="search-box">
                <input type="text" name="search" placeholder="Search by ID, name, email, or high school..." value="<?php echo htmlspecialchars($search); ?>">
                <button type="submit"><i class="fas fa-search"></i> Search</button>
                <?php if ($search): ?>
                    <a href="students.php" class="btn" style="background: #6c757d;">Clear</a>
                <?php endif; ?>
            </form>

            <?php if (empty($students)): ?>
                <div class="empty-state">
                    <i class="fas fa-info-circle" style="font-size: 3em; color: #ccc; margin-bottom: 15px;"></i>
                    <p>No dual credit students registered yet.</p>
                    <a href="register-student.php" class="btn" style="background: #4b6cb7;">
                        <i class="fas fa-user-plus"></i> Register First Dual Credit Student
                    </a>
                </div>
            <?php else: ?>
                <div style="overflow-x: auto;">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Student ID</th>
                                <th>Name</th>
                                <th>Age</th>
                                <th>High School</th>
                                <th>Grad Year</th>
                                <th>Email</th>
                                <th>Phone</th>
                                <th>City, State</th>
                                <th>Enrolled</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($students as $student): ?>
                                <tr>
                                    <td><?php echo $student['id']; ?></td>
                                    <td><strong><?php echo htmlspecialchars($student['student_id']); ?></strong></td>
                                    <td><?php echo htmlspecialchars($student['first_name'] . ' ' . $student['last_name']); ?></td>
                                    <td><?php echo $student['age'] ? $student['age'] : '-'; ?></td>
                                    <td>
                                        <?php echo htmlspecialchars($student['high_school'] ?: '-'); ?>
                                        <?php if ($student['high_school']): ?>
                                            <span class="dual-credit-badge">Dual Credit</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo $student['graduation_year'] ?: '-'; ?></td>
                                    <td><?php echo htmlspecialchars($student['email']); ?></td>
                                    <td><?php echo htmlspecialchars($student['phone'] ?: '-'); ?></td>
                                    <td><?php echo htmlspecialchars($student['city'] ? $student['city'] . ', ' . $student['state'] : '-'); ?></td>
                                    <td><?php echo date('M d, Y', strtotime($student['enrollment_date'])); ?></td>
                                    <td>
                                        <a href="student-details.php?id=<?php echo $student['id']; ?>" class="action-btn view-btn" title="View Details"><i class="fas fa-eye"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>

            <!-- Quick Stats by High School -->
            <?php if (!empty($students)): 
                $schools = [];
                foreach ($students as $student) {
                    if (!empty($student['high_school'])) {
                        $schools[$student['high_school']] = ($schools[$student['high_school']] ?? 0) + 1;
                    }
                }
                if (!empty($schools)):
            ?>
            <div style="background: white; padding: 20px; border-radius: 8px; margin-top: 30px;">
                <h3 style="color: #4b6cb7;"><i class="fas fa-school"></i> Participating High Schools</h3>
                <div style="display: flex; flex-wrap: wrap; gap: 15px; margin-top: 15px;">
                    <?php foreach ($schools as $school => $count): ?>
                        <div style="background: #e8f5e8; padding: 10px 15px; border-radius: 20px;">
                            <strong><?php echo htmlspecialchars($school); ?></strong>: <?php echo $count; ?> student<?php echo $count > 1 ? 's' : ''; ?>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endif; endif; ?>

            <!-- Social Media Links -->
            <div style="text-align: center; margin: 40px 0 20px;">
                <h3 style="color: #4b6cb7; margin-bottom: 15px;">
                    <i class="fas fa-share-alt"></i> Connect with Purdue Northwest
                </h3>
                <div>
                    <a href="https://facebook.com/PurdueNorthwest" target="_blank" style="background: #1877f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-facebook"></i> Facebook
                    </a>
                    <a href="https://twitter.com/PurdueNW" target="_blank" style="background: #1da1f2; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <a href="https://instagram.com/purduenw" target="_blank" style="background: #e4405f; color: white; padding: 10px 20px; border-radius: 5px; margin: 0 5px; display: inline-block; text-decoration: none;">
                        <i class="fab fa-instagram"></i> Instagram
                    </a>
                </div>
            </div>
        </main>

        <footer>
            <p>&copy; <?php echo date('Y'); ?> Purdue University Northwest - Dual Credit Program. All rights reserved.</p>
            <p style="font-size: 12px; margin-top: 10px;">2200 169th Street, Hammond, Indiana 46323 | (219) 989-2400</p>
        </footer>
    </div>
</body>
</html>
