<?php require_once 'db.php'; $id = $_GET['id'] ?? 0; $stmt = $pdo->prepare("SELECT * FROM course_descriptions WHERE id=?"); $stmt->execute([$id]); $c = $stmt->fetch(); if(!$c) die("Course not found."); ?>
<!DOCTYPE html>
<html><head><title><?= htmlspecialchars($c['course_code']) ?> Description</title><style>body{font-family:Arial;margin:30px} .desc{background:#f9f9f9;padding:20px;border-radius:5px}</style></head>
<body><a href="course_descriptions.php">← Back to Course List</a><h2><?= htmlspecialchars($c['course_code']) ?> – <?= htmlspecialchars($c['title']) ?></h2><div class="desc"><?= nl2br(htmlspecialchars($c['description'])) ?></div></body></html>
