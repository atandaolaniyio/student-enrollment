<?php
require_once 'db.php';
try {
    $columns = ['phone', 'major', 'enrollment_date', 'status'];
    foreach ($columns as $col) {
        try {
            $pdo->exec("ALTER TABLE students ADD COLUMN $col VARCHAR(255)");
            echo "Added column: $col<br>\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column') !== false) {
                echo "Column $col already exists.<br>\n";
            } else {
                throw $e;
            }
        }
    }
    echo "✅ Students table updated.<br>\n";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>\n";
}
?>
