<?php
require_once 'db.php';

$enrollments = $pdo->query("
    SELECT e.*, s.name as student_name, c.course_name 
    FROM enrollments e 
    LEFT JOIN students s ON e.student_id = s.id 
    LEFT JOIN courses c ON e.course_id = c.id 
    ORDER BY e.enrollment_date DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Enrollments List</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fb; }
        .header { background: #2c3e50; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .header a { color: white; text-decoration: none; margin-left: 15px; padding: 8px 15px; border-radius: 5px; }
        .header a:hover { background: #4a86e8; }
        .container { max-width: 1400px; margin: 0 auto; padding: 30px; }
        .card { background: white; border-radius: 10px; padding: 25px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; margin-bottom: 20px; }
        .btn-add { background: #27ae60; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #4a86e8; color: white; }
        tr:hover { background: #f5f5f5; }
        .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .status-active { background: #d4edda; color: #155724; }
        .status-completed { background: #cce5ff; color: #004085; }
        .status-dropped { background: #f8d7da; color: #721c24; }
        .btn-edit { background: #4a86e8; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; }
    </style>
</head>
<body>
<div class="header">
    <h1>📋 Enrollments Management</h1>
    <div><a href="index.php">🏠 Home</a> <a href="admin_dashboard.php?table=enrollments">⚙️ Admin Panel</a> <a href="add_enrollment.php">➕ Add Enrollment</a></div>
</div>

<div class="container">
    <div class="card">
        <h2>All Enrollments</h2>
        <a href="add_enrollment.php" class="btn-add">➕ Add New Enrollment</a>
        
        <?php if (count($enrollments) == 0): ?>
            <p>No enrollments found. Click "Add New Enrollment" to create one.</p>
        <?php else: ?>
            <div style="overflow-x: auto;">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Student</th>
                            <th>Course</th>
                            <th>Enrollment Date</th>
                            <th>Status</th>
                            <th>Grade</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($enrollments as $e): ?>
                        <tr>
                            <td><?php echo $e['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($e['student_name'] ?? 'N/A'); ?></strong></td>
                            <td><?php echo htmlspecialchars($e['course_name'] ?? 'N/A'); ?></td>
                            <td><?php echo date('M d, Y', strtotime($e['enrollment_date'])); ?></td>
                            <td>
                                <span class="status-badge status-<?php echo strtolower($e['status']); ?>">
                                    <?php echo $e['status']; ?>
                                </span>
                            </td>
                            <td><?php echo $e['grade'] ? "<strong>" . $e['grade'] . "</strong>" : 'N/A'; ?></td>
                            <td><a href="admin_dashboard.php?table=enrollments&action=edit&id=<?php echo $e['id']; ?>" class="btn-edit">✏️ Edit</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>
</body>
</html>
