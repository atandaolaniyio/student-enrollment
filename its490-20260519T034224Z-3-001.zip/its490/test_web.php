<?php
require_once 'db.php';
echo "<h2>Web Database Test</h2>";
echo "<p>Connection successful!</p>";

$students = $pdo->query("SELECT COUNT(*) as total FROM students")->fetch();
echo "<p>Total students: " . $students['total'] . "</p>";

$courses = $pdo->query("SELECT COUNT(*) as total FROM courses")->fetch();
echo "<p>Total courses: " . $courses['total'] . "</p>";
?>
