<?php
require_once 'db.php';

$table = $_GET['table'] ?? 'enrollments';

if (!preg_match('/^[a-zA-Z0-9_]+$/', $table)) {
    die("Invalid table name.");
}

try {
    $rows = $pdo->query("SELECT * FROM `$table` LIMIT 300")->fetchAll(PDO::FETCH_ASSOC);
    $columns = $pdo->query("SHOW COLUMNS FROM `$table`")->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error loading table '<b>" . htmlspecialchars($table) . "</b><br>" . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Table: <?= htmlspecialchars($table) ?></title>
    <style>
        body {font-family: Arial, sans-serif; margin: 30px; background: #f8f9fa;}
        h2 {color: #2c3e50;}
        table {border-collapse: collapse; width: 100%; background: white; margin-top: 20px;}
        th, td {border: 1px solid #ddd; padding: 12px; text-align: left;}
        th {background: #3498db; color: white;}
        tr:nth-child(even) {background-color: #f2f2f2;}
    </style>
</head>
<body>
    <a href="index.php">← Back to Dashboard</a><br><br>
    <h2>Table: <?= htmlspecialchars(strtoupper($table)) ?></h2>

    <table>
        <tr>
            <?php foreach($columns as $col): ?>
                <th><?= htmlspecialchars($col['Field']) ?></th>
            <?php endforeach; ?>
        </tr>
        <?php if (empty($rows)): ?>
            <tr><td colspan="50" style="padding:40px; text-align:center; color:#666;">No records found in this table.</td></tr>
        <?php else: foreach($rows as $row): ?>
            <tr>
                <?php foreach($row as $value): ?>
                    <td><?= htmlspecialchars($value ?? '') ?></td>
                <?php endforeach; ?>
            </tr>
        <?php endforeach; endif; ?>
    </table>

    <p><strong>Records shown:</strong> <?= count($rows) ?> (maximum 300)</p>
</body>
</html>
