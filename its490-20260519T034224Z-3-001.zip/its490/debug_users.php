<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

echo "<h1>Debug - User Management</h1>";

// Connect to its490_project for users
$host = 'database1.cfcucs4a2nij.us-east-2.rds.amazonaws.com';
$username = 'admin';
$password = 'F2mC4?datA';
$database = 'its490_project';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
echo "<p>✅ Connected to database: $database</p>";

// Check if users table exists
$result = $conn->query("SHOW TABLES LIKE 'users'");
if ($result->num_rows > 0) {
    echo "<p>✅ Users table exists</p>";
    
    // Show users
    $users = $conn->query("SELECT * FROM users LIMIT 5");
    echo "<h3>Users in database:</h3>";
    echo "<table border='1' cellpadding='8'>";
    while($user = $users->fetch_assoc()) {
        echo "<tr>";
        foreach($user as $key => $value) {
            echo "<td><strong>$key:</strong> $value</td>";
        }
        echo "</tr>";
    }
    echo "</table>";
} else {
    echo "<p>❌ Users table does not exist!</p>";
    echo "<p>Let's create it:</p>";
    
    // Create users table
    $sql = "CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) UNIQUE NOT NULL,
        email VARCHAR(100) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) DEFAULT 'user',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )";
    
    if ($conn->query($sql)) {
        echo "<p>✅ Users table created!</p>";
        
        // Insert default admin
        $default_pass = password_hash('admin123', PASSWORD_DEFAULT);
        $conn->query("INSERT IGNORE INTO users (username, email, password, role) VALUES ('admin', 'admin@example.com', '$default_pass', 'admin')");
        echo "<p>✅ Default admin user created (username: admin, password: admin123)</p>";
    } else {
        echo "<p>❌ Error creating table: " . $conn->error . "</p>";
    }
}

$conn->close();
?>
