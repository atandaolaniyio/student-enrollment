<?php
require_once 'db.php';

// Create tables
$pdo->exec("
CREATE TABLE IF NOT EXISTS policies (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    information TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");
echo "✅ Policies table created<br>";

$pdo->exec("
CREATE TABLE IF NOT EXISTS faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    question TEXT NOT NULL,
    answer TEXT NOT NULL
)");
echo "✅ FAQ table created<br>";

$pdo->exec("
CREATE TABLE IF NOT EXISTS campus_safety (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    information TEXT NOT NULL
)");
echo "✅ Campus Safety table created<br>";

$pdo->exec("
CREATE TABLE IF NOT EXISTS building_hours (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    campus INT COMMENT '1=Hammond, 2=Westville',
    monday VARCHAR(100),
    tuesday VARCHAR(100),
    wednesday VARCHAR(100),
    thursday VARCHAR(100),
    friday VARCHAR(100),
    saturday VARCHAR(100),
    sunday VARCHAR(100)
)");
echo "✅ Building Hours table created<br>";

$pdo->exec("
CREATE TABLE IF NOT EXISTS academic_resources (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    information TEXT NOT NULL
)");
echo "✅ Academic Resources table created<br>";

$pdo->exec("
CREATE TABLE IF NOT EXISTS cep_info (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    information TEXT NOT NULL
)");
echo "✅ CEP Info table created<br>";

$pdo->exec("
CREATE TABLE IF NOT EXISTS course_descriptions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    course_code VARCHAR(20) NOT NULL,
    title VARCHAR(255) NOT NULL,
    description TEXT NOT NULL
)");
echo "✅ Course Descriptions table created<br>";

// ---------- Insert Policies (from working.csv2.csv3... first policy block) ----------
$policies = [
    [1,"Academic Honors","Deans List\nThe Dean’s List is Purdue University Northwest’s way of recognizing undergraduate students for outstanding scholastic achievement... (full text)"],
    [2,"Academic Integrity Policy","The Academic Integrity process is one component of an overall system... www.pnw.edu/dean-of-students/policies/academic-integrity-policy/"],
    [3,"Alcohol & Drug Policy","Purdue University Northwest follows the Purdue University system Alcohol and Other Drug Policy... Medical Amnesty for Student Intoxication..."],
    [4,"Amorous Relationships Policy","Purdue University prohibits Amorous Relationships between a student and any University employee..."],
    [5,"Anti-Harassment Policy","Purdue University is committed to maintaining an educational and work climate free from Harassment..."],
    [6,"Attendance","Students are expected to attend every meeting of the classes in which they are enrolled..."],
    [7,"Bill of Student Rights","The Bill of Student Rights can be found on the West Lafayette webpage..."],
    [8,"Classroom Disruption Policy","Purdue University Northwest supports the principles of freedom of expression..."],
    [9,"Complaints","Students have the opportunity to submit complaints to the Office of Dean of Students..."],
    [10,"Copyrights & Patents","Purdue University Northwest follows the Purdue University system policy for Copyrights and Patents..."],
    [11,"Discrimination & Harassment","Any employee, student, campus visitor... should report to Office of Equity, Diversity, and Inclusion..."],
    [12,"Equal Opportunity, Equal Access, & Affirmative Action","Purdue University is committed to maintaining an inclusive community..."],
    [13,"Final Exams","Each class is scheduled for a two-hour meeting during the final exam period..."],
    [14,"Grades","Please refer to the University’s Academic Catalog for the most current information on Grades."],
    [15,"Grade Appeal Policy","Purdue University Northwest’s complete Grade Appeals Policy can be found at www.pnw.edu/dean-of-students/policies/grade-appeal-policy/"],
    [16,"Grief Absence Policy","Purdue University recognizes that a time of bereavement is very difficult for a student..."],
    [17,"Honor Code","The University Honor Code can be found on the West Lafayette webpage..."],
    [18,"Information Technology Policies","All Purdue Information Technology Policies are maintained in West Lafayette..."],
    [19,"Nepotism in the Classroom","Purdue University has an Anti-Nepotism Policy... strongly discouraged to teach relatives."],
    [20,"Nondiscrimination Policy","Purdue University prohibits discrimination against any member of the University community..."],
    [21,"Parking Regulations","For more information on Parking Regulations, please visit the University Police website."],
    [22,"Personal Injury, Accident, or Illness","Guidelines to follow in case of personal injury, accident or serious illness..."],
    [23,"Posting Policy","Designated posting locations for both campuses can be found at www.pnw.edu/facilities/public-posting-policy-and-locations/"],
    [24,"Schedule Revisions","Students may add courses during the first four weeks of the semester..."],
    [25,"Scholastic Deficiency","Academic Probation and Deficiency = 2.0 Good to Go..."],
    [26,"Student Conduct, Discipline, & Appeals","Purdue University Northwest’s policies on Student Conduct... www.pnw.edu/dean-of-students/policies/code-of-conduct/"]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO policies (id, name, information) VALUES (?, ?, ?)");
foreach ($policies as $p) {
    $stmt->execute($p);
}
echo "✅ Policies inserted (" . count($policies) . ")<br>";

// ---------- Insert FAQ (from working.csv2.csv3... FAQ block) ----------
$faqs = [
    [1,"What happens if I do not pay by the deadline?","If full payment is not received by the deadline, you will be dropped from the college credit portion of the class. This could affect your Academic Honors Diploma. Once dropped, a student cannot be re-registered (even if payment is made after the deadline). No exceptions."],
    [2,"How will I be billed?","You will be billed twice each academic year, through both the mail and online - once in the fall, and again in the spring."],
    [3,"How do I get my transcript?","Contact Tracey Radtke in the Office of the Registrar to request either electronic instructions for requesting via your myPNW account or a paper form. Transcripts are free of charge. Transcripts will not be send without you ordering them first."],
    [4,"Where can I find which classes transfer where?","Either by calling us, checking online at www.transferIN.net, or by calling the out-of-state/private college you are interested in."],
    [5,"Is grading similar to that of advanced placement (AP)?","PNW Concurrent Enrollment courses are graded using a PNW letter grade (A-F), similar to your high school grading scale. The final grade is submitted to PNW by your high school instructor."],
    [6,"Do I need to apply after high school graduation?","You may have earned multiple college credits in high school through PNW; however, all graduating seniors must still apply as a first time college student."]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO faq (id, question, answer) VALUES (?, ?, ?)");
foreach ($faqs as $f) {
    $stmt->execute($f);
}
echo "✅ FAQ inserted (" . count($faqs) . ")<br>";

// ---------- Insert Campus Safety (PNW Police, Emergency Telephones, etc.) ----------
$safety = [
    [1,"PNW Police Department","The University Police Department operates 24/7... (full text from file)"],
    [2,"Emergency Telephone Locations","Hammond Campus: Emergency Phones 'Blue Light Phones' located near building entrances... Westville Campus: various locations."],
    [3,"House Telephone Locations","House telephones are University phones located across campus... (list of locations)"],
    [4,"Campus Maps","https://www.pnw.edu/getting-to-pnw/hammond-campus-map/  |  https://www.pnw.edu/getting-to-pnw/westville-campus-map/"]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO campus_safety (id, name, information) VALUES (?, ?, ?)");
foreach ($safety as $s) {
    $stmt->execute($s);
}
echo "✅ Campus Safety inserted<br>";

// ---------- Insert Building Hours (from working.csv2) ----------
$buildings = [
    [1,"E. D. Anderson Building (ANDR)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","7:00 AM - 5:00 PM","CLOSED"],
    [2,"Classroom/Office Building (CLO)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","CLOSED","CLOSED"],
    [3,"Millard E. Gyte Science Building (GYTE)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","CLOSED","CLOSED"],
    [4,"Hospitality & Tourism Management Building (HTMB)",1,"7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 5:00 PM","CLOSED","CLOSED"],
    [5,"Nils K. Nelson Bioscience Innovation Building (NILS)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","7:00 AM - 5:00 PM","CLOSED"],
    [6,"Gene Stratton Porter Hall (PORT)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","CLOSED","CLOSED"],
    [7,"Andrew A. Potter Laboratories Building (POTT)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","CLOSED","CLOSED"],
    [8,"Donald S. Powers Computer Education Building (PWRS)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 7:00 PM","CLOSED","CLOSED"],
    [9,"Student Union and Library Building (SULB)",1,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 5:00 PM","9:00 AM - 3:00 PM","CLOSED"],
    [10,"David Roberts Center for Innovation & Design (IDET)",1,"8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","CLOSED","CLOSED"],
    [11,"Commercialization & Manufacturing Excellence Center (CMEC)",1,"5:00 PM - 8:00 PM","CLOSED","5:00 PM - 8:00 PM","5:00 PM - 8:00 PM","CLOSED","CLOSED","CLOSED"],
    [12,"Indianapolis Boulevard Counseling Center (IBCC)",1,"8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","CLOSED","CLOSED"],
    [13,"Hammond Fitness & Recreation Center (FNRC)",1,"7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","9:00 AM - 12:00 PM","12:00 PM - 3:00 PM"],
    [14,"C. H. Lawshe Hall (LAWS)",1,"8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","CLOSED","CLOSED"],
    [15,"Charlotte R. Riley Center (RILY)",1,"8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","CLOSED","CLOSED"],
    [16,"Schneider Avenue Building (SAB)",1,"8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","CLOSED","CLOSED"],
    [17,"University Services Building (UNSV)",1,"8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","8:00 AM - 4:30 PM","CLOSED","CLOSED"],
    [18,"Library Student Faculty Building (LSF)",2,"7:00 AM - 9:00 PM","7:00 AM - 9:00 PM","7:00 AM - 9:00 PM","7:00 AM - 9:00 PM","7:00 AM - 5:00 PM","9:00 AM - 3:00 PM","CLOSED"],
    [19,"Robert F. Schwarz Hall (SWRZ)",2,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 5:00 PM","CLOSED","CLOSED"],
    [20,"Technology Building (TECH)",2,"7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 10:30 PM","7:00 AM - 5:00 PM","CLOSED","CLOSED"],
    [21,"Physical Facilities/Campus Police (PFCP)",2,"8:00 AM - 4:00 PM","8:00 AM - 4:00 PM","8:00 AM - 4:00 PM","8:00 AM - 4:00 PM","8:00 AM - 4:00 PM","CLOSED","CLOSED"],
    [22,"James B. Dworkin Student Services & Athletic Complex (DSAC)",2,"7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","7:00 AM - 7:00 PM","CLOSED","CLOSED"]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO building_hours (id, name, campus, monday, tuesday, wednesday, thursday, friday, saturday, sunday) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
foreach ($buildings as $b) {
    $stmt->execute($b);
}
echo "✅ Building Hours inserted (" . count($buildings) . ")<br>";

// ---------- Insert Academic Resources (Colleges, Advising, Support) ----------
$academic = [
    [1,"Academic Colleges","College of Business... College of Humanities... College of Engineering and Science... College of Nursing... College of Technology... Honors College... (full details from working.csv)"],
    [2,"Academic Calendar","See PNWs Academic Schedule: https://www.pnw.edu/registrar/academic-schedule/"],
    [3,"Degrees","Please check the online listing of current degrees offered: https://www.pnw.edu/program-finder/"],
    [4,"Academic Advising","The responsibility for all academic decisions belongs to the student. https://www.pnw.edu/advising/ ..."],
    [5,"Student Academic Support","Location: Hammond: Gyte 102, Westville: LSF 202. Phone: (219)989-3227 / (219)785-5628. Website: pnw.edu/sas"]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO academic_resources (id, name, information) VALUES (?, ?, ?)");
foreach ($academic as $a) {
    $stmt->execute($a);
}
echo "✅ Academic Resources inserted<br>";

// ---------- Insert CEP Info (Mission, Staff, Benefits, Deadlines, etc.) ----------
$cep = [
    [1,"Office of Concurrent Enrollment Staff","Dr. Anne Gregory (Director)... Rachel Clark... Katie Bowers... Tracey Radtke... Vicki Jankowski... Peter Bailey"],
    [2,"Mission Statement","The Purdue University Northwest’s Concurrent Enrollment Program works in partnership with school districts to ensure that exceptional high school students receive a high quality educational experience."],
    [3,"Student Benefits & Academic Resources","PNW Library, Writing Center, Tutoring, Academic Advising."],
    [4,"Purdue Probation Policy","All students shall be placed on academic probation if GPA < 2.0..."],
    [5,"Academic Misconduct","Students are expected to abide by laws and university rules. Examples: dishonesty, cheating, plagiarism..."],
    [6,"Boilerkey Two Factor Authentication","https://www.pnw.edu/information-services/services/boilerkey/"],
    [7,"Activating myPNW Account","Go to password.pnw.edu, select Activate Account, use career account and PUID. Keep password confidential."],
    [8,"Important Information","Memorize PUID and Username; Get to know myPNW; How to pay tuition; Consequences if not paid; Know prerequisites."],
    [9,"Drop & Withdrawal Policy","Students may drop by deadline for removal from transcript; withdrawal gives W grade and no refund."],
    [10,"Important Dates & Deadlines","July 29 Placement Exams open; Aug 16 Registration due; Sep 27 Tuition due; etc."],
    [11,"How Does Concurrent Enrollment Help Me?","Jump-start college, transferable credits, competitive edge, flexibility, college-level skills, reduce cost."],
    [12,"Applying to PNW After High School Graduation","Apply as first-time college student. Scholarships available: $1000 CEP Student Scholarship."]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO cep_info (id, name, information) VALUES (?, ?, ?)");
foreach ($cep as $c) {
    $stmt->execute($c);
}
echo "✅ CEP Info inserted<br>";

// ---------- Insert Course Descriptions (from working.csv2.csv3... course list) ----------
$descriptions = [
    ["ACC 20000","Introductory Accounting","An examination of the system by which accounting data is gathered from economic events. Construction and uses of financial statements."],
    ["AD11300","Basic Drawing","An introduction to drawing and sketching as a means of communication of ideas."],
    ["AD 25500","Art Appreciation","Understanding and appreciation of the problems overcome by mankind in the origins and growth of art."],
    ["BIO 11000","Fundamentals of Biology I","Principles of biology, focusing on diversity, ecology, evolution, and the development, structure, and function of organisms."],
    ["BIO 11100","Fundamentals of Biology II","Continuation of BIOL 11000. Principles of biology, focusing on cell structure and function, molecular biology, and genetics."],
    ["BUSM 10100","Introduction to Business","An introduction to the internal operations and external environment of contemporary business."],
    ["CHM 11500","General Chemistry","Stoichiometry; atomic structure; periodic properties; ionic and covalent bonding; molecular geometry; gases, liquids, and solids; thermochemistry."],
    ["CHM 11600","General Chemistry","A continuation of CHM 11500. Solutions; quantitative equilibria; thermodynamics; electrochemistry; kinetics; nuclear chemistry."],
    ["COM 11400","Fundamentals of Speech Communication","A study of communication theories as applied to speech; practical communicative experiences."],
    ["COM 26100","Introduction to Digital Video Production","Basic production principles and practices. Emphasis on preplanning and conceptualizing skills."],
    ["EAS 11300","Introduction to Environmental Science","Issues such as climate change, energy resources, air and water pollution, toxic waste disposal, soil erosion, natural hazards, and environmental planning."],
    ["ECON 21000","Principles of Economics","Behavior of individual consumer and firm; macroeconomy; inflation, unemployment, interest rates; international economy."],
    ["ECON 25100","Microeconomics","Analysis of forces affecting national income, employment, interest rates, and inflation. Role of government fiscal and monetary policy."],
    ["ECON 25200","Macroeconomics","Introduction to macroeconomic theory. Focus on fiscal and monetary policy for economic growth and stable prices."],
    ["EDCI 27600","Child, Family, School, & Community Partnerships","Examines the life of the young child within family, community and cultural systems. Diversity and positive relationships."],
    ["EDST 27000","Early Childhood Education","Introduction to early childhood care and education including career options, history, philosophy, current trends."],
    ["ENG 10400","English Composition I","Emphasis on organization of expository theme. Writings based on personal experience and ideas."],
    ["ENG 23100","Introduction to Literature","Reading and discussion of English, U.S. and international literature. Writing about literature."],
    ["FR 10100","French Level I","Beginning French with emphasis on communicative skills and culture."],
    ["FR 10200","French Level II","Continuation of FR 10100."],
    ["FR 20100","French Level III","Lower intermediate French course."],
    ["FR 20200","French Level IV","Continuation of FR 20100."],
    ["GER 10100","German Level I","Beginning German for students with less than two years of high school German."],
    ["GER 10200","German Level II","Continuation of GER 10100."],
    ["GER 20100","German Level III","Readings from nineteenth-century and contemporary German writers; practice in speaking and writing."],
    ["GER 20200","German Level IV","Continuation of GER 20100."],
    ["HDFS 21600","Introduction to Early Childhood Education","Survey of early education programs; history & theory; program routines; professional relationships."],
    ["HIST 10400","Introduction to the Modern World","Traces expansion of European society into Americas, Africa, Asia; political revolutions, nationalism."],
    ["HIST 10500","Survey of Global History","Interaction between civilizations of Asia, Africa, Europe, and Americas since 1500."],
    ["HIST 15100","American History to 1877","Development of American political, economic, and social institutions from colonial times through Reconstruction."],
    ["HIST 15200","United States Since 1877","Growth of the United States from 1877 to present: industrialism, depression, New Deal, world wars, Cold War."],
    ["MA 15300","College Algebra","Algebra and trigonometry for students with inadequate preparation for calculus."],
    ["MA 15400","Trigonometry","Continuation of MA 15300."],
    ["MA 16300","Integrated Calculus Analysis Geometry I","Topics from plane analytic geometry. Introduction to differentiation and integration."],
    ["MA 16400","Integrated Calculus Analysis Geometry II","Completion of introductory study of plane analytic geometry and calculus of one variable, infinite series."],
    ["MUS 25000","Music Appreciation","Traditions, forms, and styles of classical music. Other types may be examined."],
    ["POL 10100","American Government and Politics","Nature of democratic government, U.S. Constitution, federalism, civil rights, political dynamics, presidency, Congress, judiciary."],
    ["PHYS 22000","General Physics","Algebra-based. Mechanics, heat, and sound for non-physics/engineering majors."],
    ["PHYS 22100","General Physics","Algebra-based. Electricity & magnetism, light, and modern physics."],
    ["SPAN 10100","Spanish Level I","Beginning Spanish with emphasis on communicative skills and culture."],
    ["SPAN 10200","Spanish Level II","Continuation of SPAN 10100."],
    ["SPAN 20100","Spanish Level III","Intermediate Spanish course."],
    ["SPAN 20200","Spanish Level IV","Continuation of SPAN 20100."],
    ["STAT 30100","Elementary Statistical Methods","Frequency distributions, descriptive statistics, probability, normal distribution, estimation, hypothesis testing, linear regression."]
];
$stmt = $pdo->prepare("INSERT IGNORE INTO course_descriptions (course_code, title, description) VALUES (?, ?, ?)");
foreach ($descriptions as $d) {
    $stmt->execute($d);
}
echo "✅ Course Descriptions inserted (" . count($descriptions) . ")<br>";

echo "<hr><strong>All data imported successfully!</strong>";
?>
