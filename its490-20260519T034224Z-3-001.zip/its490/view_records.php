<?php
require_once 'config.php';
$table = $_GET['table'] ?? '';
if (!$table) die("No table selected");

$result = $conn->query("SELECT * FROM `$table`");
$columns = [];
$fields = $conn->query("SHOW COLUMNS FROM `$table`");
while($col = $fields->fetch_assoc()) {
    $columns[] = $col['Field'];
}
?>
<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($table); ?> - Records</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { max-width: 95%; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        h1 { color: #667eea; margin-bottom: 20px; }
        .btn-back { display: inline-block; padding: 10px 15px; background: #6c757d; color: white; text-decoration: none; border-radius: 5px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background: #667eea; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        tr:hover { background: #f5f5f5; }
        .record-count { margin-top: 20px; color: #666; }
    </style>
</head>
<body>
<div class="container">
    <h1>📋 Table: <?php echo htmlspecialchars($table); ?></h1>
    <a href="index.php" class="btn-back">← Back to Dashboard</a>
    
    <div style="overflow-x: auto;">
        <table border="1" cellpadding="8" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <?php foreach($columns as $col): ?>
                        <th><?php echo htmlspecialchars($col); ?></th>
                    <?php endforeach; ?>
                </tr>
            </thead>
            <tbody>
                <?php 
                $row_count = 0;
                while($row = $result->fetch_assoc()): 
                    $row_count++;
                ?>
                    <tr>
                        <?php foreach($columns as $col): ?>
                            <td><?php echo htmlspecialchars(substr($row[$col], 0, 100)); ?></td>
                        <?php endforeach; ?>
                    </tr>
                <?php endwhile; ?>
                <?php if($row_count == 0): ?>
                    <tr>
                        <td colspan="<?php echo count($columns); ?>" style="text-align: center;">No records found</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="record-count">Total records: <?php echo $row_count; ?></div>
</div>
</body>
</html>
