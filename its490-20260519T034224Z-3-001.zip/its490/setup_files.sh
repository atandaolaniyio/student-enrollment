#!/bin/bash

# Create fetch_users.php
cat > fetch_users.php << 'EOF'
<?php
require_once 'config.php';

$search = $_GET['search'] ?? '';
$where = '';
if ($search) {
    $search = $conn->real_escape_string($search);
    $where = "WHERE username LIKE '%$search%' OR email LIKE '%$search%'";
}

$sql = "SELECT id, username, email, role FROM users $where ORDER BY id";
$result = $conn->query($sql);
?>
<table border="1" cellpadding="8" cellspacing="0" style="width:100%; border-collapse: collapse;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while($user = $result->fetch_assoc()): ?>
            <tr id="user-row-<?php echo $user['id']; ?>">
                <td><?php echo $user['id']; ?></td>
                <td class="editable-cell" data-field="username"><?php echo htmlspecialchars($user['username']); ?></td>
                <td class="editable-cell" data-field="email"><?php echo htmlspecialchars($user['email']); ?></td>
                <td class="editable-cell" data-field="role"><?php echo htmlspecialchars($user['role']); ?></td>
                <td class="actions">
                    <button class="btn-edit" onclick="editUser(<?php echo $user['id']; ?>)">Edit</button>
                    <button class="btn-delete" onclick="deleteUser(<?php echo $user['id']; ?>)">Delete</button>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>
EOF

# Create save_user.php
cat > save_user.php << 'EOF'
<?php
require_once 'config.php';

$username = $_POST['username'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$role = $_POST['role'];

$stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
$stmt->bind_param("ssss", $username, $email, $password, $role);

$response = ['success' => false];
if ($stmt->execute()) {
    $response['success'] = true;
} else {
    $response['error'] = $stmt->error;
}

echo json_encode($response);
?>
EOF

# Create update_user.php
cat > update_user.php << 'EOF'
<?php
require_once 'config.php';

$data = json_decode(file_get_contents('php://input'), true);

$stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
$stmt->bind_param("sssi", $data['username'], $data['email'], $data['role'], $data['id']);

$response = ['success' => $stmt->execute()];
echo json_encode($response);
?>
EOF

# Create delete_user.php
cat > delete_user.php << 'EOF'
<?php
require_once 'config.php';

$data = json_decode(file_get_contents('php://input'), true);

$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $data['id']);

$response = ['success' => $stmt->execute()];
echo json_encode($response);
?>
EOF

echo "All files created successfully!"
