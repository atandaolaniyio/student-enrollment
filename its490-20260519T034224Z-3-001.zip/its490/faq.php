<?php require_once 'db.php'; $faqs = $pdo->query("SELECT * FROM faq ORDER BY id")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>FAQ</title><style>body{font-family:Arial;margin:30px} details{margin-bottom:15px;background:#f5f5f5;padding:10px;border-radius:5px} summary{font-weight:bold;cursor:pointer}</style></head>
<body><h2>❓ Frequently Asked Questions</h2><a href="index.php">← Back</a><br><br>
<?php foreach($faqs as $f): ?>
<details><summary><?= htmlspecialchars($f['question']) ?></summary><p><?= nl2br(htmlspecialchars($f['answer'])) ?></p></details>
<?php endforeach; ?>
</body></html>
