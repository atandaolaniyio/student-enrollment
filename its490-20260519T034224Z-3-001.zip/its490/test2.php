<?php
echo "<h1>Test Page 2 - PHP is working</h1>";
echo "<p>Current time: " . date('Y-m-d H:i:s') . "</p>";
require_once 'db.php';
echo "<p>Database connection: OK</p>";
?>
