<?php
// Database connection settings
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "StudentList";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$signup_success = false;

// Check if form is submitted
if(isset($_POST['username']) && isset($_POST['password'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Generate a random salt
    $salt = bin2hex(random_bytes(16));
    
    // Hash the password with the salt
    $hashed_password = password_hash($password . $salt, PASSWORD_DEFAULT);

    // Insert user data into the database
    $sql = "INSERT INTO users (username, password, salt) VALUES ('$username', '$hashed_password', '$salt')";
    
    if ($conn->query($sql) === TRUE) {
        $signup_success = true;
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Signup Page</title>
    <link rel="stylesheet" type="text/css" href="style.css" />
</head>
<body>
    <header class="header">
        <div class="container">
            <div class="top-left">
                <div class="brand-lockup">
    <img src="imgs/pnw-lion.svg" class="pnw-lion-logo" alt="Purdue Northwest Lion Logo">
    <div class="logo">
        <a href="index.html"><h1>ClickOn</h1></a>
    </div>
</div>
            </div>
            <div class="top-right">
                <nav>
                    <ul>
                        <li><a href="about.html">About</a></li>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="signup.php">Signup</a></li>
                    </ul>
                </nav>
            </div>
        </div>
    </header>

    <div class="container">
        <div class="forms-container">
            <!-- Signup Form -->
            <div class="form-wrapper">
                <h2>Sign Up</h2>
                <?php if($signup_success): ?>
                    <p class="success-message">Signup successful! You can now login.</p>
                <?php endif; ?>
                <form action="signup.php" method="post">
                    <label for="signup-username">Username:</label>
                    <input type="text" id="signup-username" name="username" required>
                    <label for="signup-password">Password:</label>
                    <input type="password" id="signup-password" name="password" required>
                    <label for="Confirm password">Confirm Password:</label><br>
                    <input type="password" id="cpassword" name="cpassword" required><br><br>

                    <button type="submit">Sign Up</button>
                </form>
                <p>Already have an account? <a href="login.php">Login here</a>.</p>
            </div>
        </div>
    </div>

    <footer class="footer">
        <div class="container">
            <div class="social-links">
                <a href="#"><img src="linkedin.png" alt="LinkedIn"></a>
                <a href="#"><img src="twitter.png" alt="Twitter"></a>
                <a href="#"><img src="fb.png" alt="Facebook"></a>
                <a href="#"><img src="google.png" alt="Facebook"></a>
            </div>
        </div>
        <p>&copy; 2024 ClickOn. All rights reserved.</p>
    </footer>
</body>
</html>