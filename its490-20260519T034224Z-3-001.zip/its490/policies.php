<?php require_once 'db.php'; $policies = $pdo->query("SELECT id, name FROM policies ORDER BY name")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>Policies</title><style>body{font-family:Arial;margin:30px} table{border-collapse:collapse;width:100%} th,td{border:1px solid #ccc;padding:10px} th{background:#4a86e8;color:white}</style></head>
<body><h2>📜 University Policies</h2><a href="index.php">← Back</a><br><br>
<table><tr><th>Policy Name</th><th>Action</th></tr>
<?php foreach($policies as $p): ?>
<tr><td><?= htmlspecialchars($p['name']) ?></td><td><a href="policy.php?id=<?= $p['id'] ?>">View Details</a></td></tr>
<?php endforeach; ?>
</table></body></html>
