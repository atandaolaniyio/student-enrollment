<?php
$host     = 'database1.cfcucs4a2nij.us-east-2.rds.amazonaws.com';
$dbname   = 'its490';
$username = 'admin';
$password = 'Henry123456';

try {
    $pdo = new PDO(
        "mysql:host=$host;dbname=$dbname;charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    echo "✅ SUCCESS: Connected to RDS without SSL!";
} catch (PDOException $e) {
    die("❌ FAILED: " . $e->getMessage());
}
?>
