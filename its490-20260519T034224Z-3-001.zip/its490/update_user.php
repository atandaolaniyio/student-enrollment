<?php
require_once 'config.php';

$data = json_decode(file_get_contents('php://input'), true);

$stmt = $conn->prepare("UPDATE users SET username = ?, email = ?, role = ? WHERE id = ?");
$stmt->bind_param("sssi", $data['username'], $data['email'], $data['role'], $data['id']);

$response = ['success' => $stmt->execute()];
echo json_encode($response);
?>
