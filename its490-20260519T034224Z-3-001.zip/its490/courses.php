<?php
require_once 'db.php';
$courses = $pdo->query("SELECT id, course_name, title FROM courses ORDER BY course_name")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>All Courses</title>
    <style>
        body {font-family: Arial, sans-serif; margin: 30px;}
        table {border-collapse: collapse; width: 100%;}
        th, td {border: 1px solid #ccc; padding: 10px;}
        th {background: #4a86e8; color: white;}
        a {text-decoration: none; color: #4a86e8;}
        a:hover {text-decoration: underline;}
    </style>
</head>
<body>
    <h2>📚 Course Schedule Catalog</h2>
    <a href="index.php">← Back to Dashboard</a><br><br>
    <table>
        <tr><th>Course Code</th><th>Title</th><th>View Schedule</th></tr>
        <?php foreach($courses as $c): ?>
        <tr>
            <td><?= htmlspecialchars($c['course_name']) ?></td>
            <td><?= htmlspecialchars($c['title']) ?></td>
            <td><a href="course.php?id=<?= $c['id'] ?>">📅 View Weekly Schedule</a></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
