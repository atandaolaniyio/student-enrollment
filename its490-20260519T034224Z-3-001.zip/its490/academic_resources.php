<?php require_once 'db.php'; $resources = $pdo->query("SELECT * FROM academic_resources ORDER BY id")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>Academic Resources</title><style>body{font-family:Arial;margin:30px} .card{border:1px solid #ddd;padding:15px;margin-bottom:20px;border-radius:8px}</style></head>
<body><h2>📚 Academic Resources</h2><a href="index.php">← Back</a><br><br>
<?php foreach($resources as $r): ?>
<div class="card"><h3><?= htmlspecialchars($r['name']) ?></h3><div><?= nl2br(htmlspecialchars($r['information'])) ?></div></div>
<?php endforeach; ?>
</body></html>
