<?php require_once 'db.php'; $id = $_GET['id'] ?? 0; $stmt = $pdo->prepare("SELECT * FROM policies WHERE id=?"); $stmt->execute([$id]); $p = $stmt->fetch(); if(!$p) die("Policy not found."); ?>
<!DOCTYPE html>
<html><head><title><?= htmlspecialchars($p['name']) ?></title><style>body{font-family:Arial;margin:30px} .content{background:#f9f9f9;padding:20px;border-radius:5px}</style></head>
<body><a href="policies.php">← Back to Policies</a><h2><?= htmlspecialchars($p['name']) ?></h2><div class="content"><?= nl2br(htmlspecialchars($p['information'])) ?></div></body></html>
