<?php
$host     = 'database1.cfcucs4a2nij.us-east-2.rds.amazonaws.com';
$username = 'admin';
$password = 'Henry123456';

try {
    $pdo = new PDO(
        "mysql:host=$host;charset=utf8mb4",
        $username,
        $password,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
    $stmt = $pdo->query("SHOW DATABASES");
    echo "Databases on your RDS instance:\n";
    while ($row = $stmt->fetch()) {
        echo " - " . $row['Database'] . "\n";
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
