<?php
require_once 'db.php';

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $student_id = $_POST['student_id'] ?? '';
    $course_id = $_POST['course_id'] ?? '';
    $enrollment_date = $_POST['enrollment_date'] ?? date('Y-m-d');
    $status = $_POST['status'] ?? 'Active';
    $grade = $_POST['grade'] ?? null;
    
    if ($student_id && $course_id) {
        try {
            $stmt = $pdo->prepare("INSERT INTO enrollments (student_id, course_id, enrollment_date, status, grade) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$student_id, $course_id, $enrollment_date, $status, $grade]);
            $message = "✅ Enrollment added successfully!";
            header("Location: enrollments.php?msg=added");
            exit;
        } catch (PDOException $e) {
            $error = "Error: " . $e->getMessage();
        }
    } else {
        $error = "Please select both a student and a course.";
    }
}

$students = $pdo->query("SELECT id, name FROM students ORDER BY name")->fetchAll();
$courses = $pdo->query("SELECT id, course_name FROM courses ORDER BY course_name")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Enrollment</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fb; }
        .header { background: #2c3e50; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header a { color: white; text-decoration: none; margin-left: 15px; padding: 8px 15px; border-radius: 5px; }
        .header a:hover { background: #4a86e8; }
        .container { max-width: 600px; margin: 50px auto; padding: 20px; }
        .card { background: white; border-radius: 10px; padding: 30px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2 { color: #2c3e50; margin-bottom: 20px; }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 8px; font-weight: bold; color: #2c3e50; }
        select, input { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; }
        button { background: #27ae60; color: white; padding: 12px 24px; border: none; border-radius: 5px; cursor: pointer; font-size: 16px; width: 100%; }
        button:hover { background: #229954; }
        .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 5px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 5px; margin-bottom: 15px; }
        .back-link { display: inline-block; margin-top: 15px; color: #4a86e8; text-decoration: none; }
    </style>
</head>
<body>
<div class="header">
    <h1>🎓 Concurrent Enrollment System</h1>
    <div><a href="index.php">🏠 Home</a> <a href="admin_dashboard.php?table=enrollments">⚙️ Manage Enrollments</a> <a href="enrollments.php">📋 View All</a></div>
</div>

<div class="container">
    <div class="card">
        <h2>➕ Add New Enrollment</h2>
        
        <?php if ($message): ?>
            <div class="success"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <form method="POST">
            <div class="form-group">
                <label>👨‍🎓 Student</label>
                <select name="student_id" required>
                    <option value="">Select Student</option>
                    <?php foreach ($students as $student): ?>
                        <option value="<?php echo $student['id']; ?>"><?php echo htmlspecialchars($student['name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>📖 Course</label>
                <select name="course_id" required>
                    <option value="">Select Course</option>
                    <?php foreach ($courses as $course): ?>
                        <option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['course_name']); ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>📅 Enrollment Date</label>
                <input type="date" name="enrollment_date" class="date-input" value="<?php echo date('Y-m-d'); ?>" required>
            </div>
            
            <div class="form-group">
                <label>📌 Status</label>
                <select name="status">
                    <option value="Active">Active</option>
                    <option value="Completed">Completed</option>
                    <option value="Dropped">Dropped</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>🎓 Grade (Optional)</label>
                <select name="grade">
                    <option value="">N/A</option>
                    <option value="A">A</option>
                    <option value="B">B</option>
                    <option value="C">C</option>
                    <option value="D">D</option>
                    <option value="F">F</option>
                </select>
            </div>
            
            <button type="submit">💾 Save Enrollment</button>
        </form>
        
        <a href="enrollments.php" class="back-link">← Back to Enrollments List</a>
    </div>
</div>

<script>
flatpickr(".date-input", {
    dateFormat: "Y-m-d",
    allowInput: true
});
</script>
</body>
</html>
