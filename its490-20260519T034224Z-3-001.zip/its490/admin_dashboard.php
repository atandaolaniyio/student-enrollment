﻿sudo cat > /var/www/html/its490/admin_dashboard.php << 'EOF'
<?php
require_once 'db.php';

$table = isset($_GET['table']) ? $_GET['table'] : 'students';
$action = isset($_GET['action']) ? $_GET['action'] : 'list';
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Handle delete
if ($action == 'delete' && $id > 0) {
    $stmt = $pdo->prepare("DELETE FROM $table WHERE id = ?");
    $stmt->execute([$id]);
    header("Location: admin_dashboard.php?table=$table&msg=deleted");
    exit;
}

// Handle add/edit form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['add'])) {
        unset($_POST['add']);
        $columns = array_keys($_POST);
        $placeholders = ':' . implode(', :', $columns);
        $sql = "INSERT INTO $table (" . implode(',', $columns) . ") VALUES (" . $placeholders . ")";
        $stmt = $pdo->prepare($sql);
        foreach ($_POST as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->execute();
        header("Location: admin_dashboard.php?table=$table&msg=added");
        exit;
    } elseif (isset($_POST['edit']) && $id > 0) {
        unset($_POST['edit']);
        $sets = [];
        foreach ($_POST as $key => $value) {
            $sets[] = "$key = :$key";
        }
        $sql = "UPDATE $table SET " . implode(', ', $sets) . " WHERE id = :id";
        $stmt = $pdo->prepare($sql);
        foreach ($_POST as $key => $value) {
            $stmt->bindValue(":$key", $value);
        }
        $stmt->bindValue(":id", $id);
        $stmt->execute();
        header("Location: admin_dashboard.php?table=$table&msg=updated");
        exit;
    }
}

// Get record for editing
$edit_record = null;
if ($action == 'edit' && $id > 0) {
    if ($table == 'enrollments') {
        $stmt = $pdo->prepare("SELECT e.*, s.name as student_name, c.course_name FROM enrollments e LEFT JOIN students s ON e.student_id = s.id LEFT JOIN courses c ON e.course_id = c.id WHERE e.id = ?");
        $stmt->execute([$id]);
        $edit_record = $stmt->fetch();
    } else {
        $stmt = $pdo->prepare("SELECT * FROM $table WHERE id = ?");
        $stmt->execute([$id]);
        $edit_record = $stmt->fetch();
    }
    if (!$edit_record) {
        header("Location: admin_dashboard.php?table=$table");
        exit;
    }
}

// Get all records
if ($table == 'enrollments') {
    $records = $pdo->query("SELECT e.*, s.name as student_name, c.course_name FROM enrollments e LEFT JOIN students s ON e.student_id = s.id LEFT JOIN courses c ON e.course_id = c.id ORDER BY e.id DESC")->fetchAll();
} else {
    $records = $pdo->query("SELECT * FROM $table ORDER BY id DESC")->fetchAll();
}

// Get columns
if ($table == 'enrollments') {
    $column_names = ['id', 'student_name', 'course_name', 'enrollment_date', 'status', 'grade'];
} else {
    $columns = $pdo->query("DESCRIBE $table")->fetchAll();
    $column_names = array_column($columns, 'Field');
}

// Get message
$msg = isset($_GET['msg']) ? $_GET['msg'] : '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>CRUD Admin - <?php echo ucfirst($table); ?></title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f5f7fb; }
        .header { background: #2c3e50; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }
        .header a { color: white; text-decoration: none; margin-left: 15px; padding: 8px 15px; border-radius: 5px; }
        .header a:hover { background: #4a86e8; }
        .container { display: flex; }
        .sidebar { width: 260px; background: #34495e; color: white; min-height: 100vh; padding: 20px; }
        .sidebar a { display: block; color: white; text-decoration: none; padding: 10px; margin: 5px 0; border-radius: 5px; }
        .sidebar a:hover, .sidebar a.active { background: #4a86e8; }
        .content { flex: 1; padding: 20px; }
        .card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
        h2, h3 { margin-bottom: 20px; color: #2c3e50; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 12px; text-align: left; border-bottom: 1px solid #e0e0e0; }
        th { background: #4a86e8; color: white; font-weight: 600; }
        tr:hover { background: #f5f5f5; }
        .btn { display: inline-block; padding: 6px 12px; margin: 2px; border-radius: 4px; text-decoration: none; font-size: 12px; }
        .btn-edit { background: #4a86e8; color: white; }
        .btn-delete { background: #e74c3c; color: white; }
        .btn-add { background: #27ae60; color: white; padding: 10px 20px; margin-bottom: 20px; display: inline-block; text-decoration: none; border-radius: 5px; }
        .btn-save { background: #27ae60; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; color: #2c3e50; }
        input, textarea, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; font-size: 14px; }
        textarea { min-height: 100px; }
        .success { background: #d4edda; color: #155724; padding: 12px; border-radius: 5px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 12px; border-radius: 5px; margin-bottom: 15px; }
        .status-badge { padding: 4px 8px; border-radius: 4px; font-size: 11px; font-weight: bold; }
        .status-active { background: #d4edda; color: #155724; }
        .status-completed { background: #cce5ff; color: #004085; }
        .status-dropped { background: #f8d7da; color: #721c24; }
        @media (max-width: 768px) { .container { flex-direction: column; } .sidebar { width: 100%; min-height: auto; } }
    </style>
</head>
<body>
<div class="header">
    <h1>ðŸŽ“ CRUD Admin Panel - Concurrent Enrollment System</h1>
    <div><a href="index.php">ðŸ  Home</a> <a href="record_bank.php">ðŸ“š Record Bank</a> <a href="push_notifications.php">ðŸ”” Push</a></div>
</div>
<div class="container">
    <div class="sidebar">
        <h3>ðŸ“‹ Manage Tables</h3>
        <a href="?table=students" class="<?php echo $table=='students'?'active':''; ?>">ðŸ‘¨â€ðŸŽ“ Students</a>
        <a href="?table=courses" class="<?php echo $table=='courses'?'active':''; ?>">ðŸ“– Courses</a>
        <a href="?table=enrollments" class="<?php echo $table=='enrollments'?'active':''; ?>">ðŸ“‹ Enrollments</a>
        <a href="?table=policies" class="<?php echo $table=='policies'?'active':''; ?>">ðŸ“œ Policies</a>
        <a href="?table=faq" class="<?php echo $table=='faq'?'active':''; ?>">â“ FAQ</a>
        <a href="?table=campus_safety" class="<?php echo $table=='campus_safety'?'active':''; ?>">ðŸš” Safety</a>
        <a href="?table=building_hours" class="<?php echo $table=='building_hours'?'active':''; ?>">ðŸ›ï¸ Hours</a>
        <a href="?table=academic_resources" class="<?php echo $table=='academic_resources'?'active':''; ?>">ðŸ“š Resources</a>
        <a href="?table=cep_info" class="<?php echo $table=='cep_info'?'active':''; ?>">ðŸŽ“ CEP Info</a>
        <a href="?table=course_descriptions" class="<?php echo $table=='course_descriptions'?'active':''; ?>">ðŸ“˜ Descriptions</a>
        <a href="?table=device_tokens" class="<?php echo $table=='device_tokens'?'active':''; ?>">ðŸ“± Devices</a>
        <hr style="margin: 15px 0;">
        <a href="upload_students.php">ðŸ“¤ Bulk Upload CSV</a>
        <a href="add_enrollment.php">âž• Add Enrollment</a>
        <a href="enrollments.php">ðŸ“‹ View Enrollments</a>
    </div>
    
    <div class="content">
        <div class="card">
            <h2>ðŸ“Š Manage <?php echo ucfirst(str_replace('_', ' ', $table)); ?></h2>
            
            <?php if ($msg == 'added'): ?>
                <div class="success">âœ… Record added successfully!</div>
            <?php elseif ($msg == 'updated'): ?>
                <div class="success">âœ… Record updated successfully!</div>
            <?php elseif ($msg == 'deleted'): ?>
                <div class="success">âœ… Record deleted successfully!</div>
            <?php endif; ?>
            
            <?php if ($action == 'add'): ?>
                <h3>âž• Add New Record</h3>
                <form method="POST">
                    <?php if ($table == 'enrollments'): ?>
                        <div class="form-group">
                            <label>Student</label>
                            <select name="student_id" required>
                                <option value="">Select Student</option>
                                <?php $students = $pdo->query("SELECT id, name FROM students ORDER BY name")->fetchAll(); ?>
                                <?php foreach ($students as $s): ?>
                                    <option value="<?php echo $s['id']; ?>"><?php echo htmlspecialchars($s['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Course</label>
                            <select name="course_id" required>
                                <option value="">Select Course</option>
                                <?php $courses = $pdo->query("SELECT id, course_name FROM courses ORDER BY course_name")->fetchAll(); ?>
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?php echo $c['id']; ?>"><?php echo htmlspecialchars($c['course_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Enrollment Date</label>
                            <input type="date" name="enrollment_date" class="date-input" value="<?php echo date('Y-m-d'); ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <option value="Active">Active</option>
                                <option value="Completed">Completed</option>
                                <option value="Dropped">Dropped</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Grade</label>
                            <select name="grade">
                                <option value="">N/A</option>
                                <option value="A">A</option>
                                <option value="B">B</option>
                                <option value="C">C</option>
                                <option value="D">D</option>
                                <option value="F">F</option>
                            </select>
                        </div>
                    <?php else: ?>
                        <?php foreach ($column_names as $col): ?>
                            <?php if ($col != 'id' && $col != 'created_at' && $col != 'updated_at'): ?>
                                <div class="form-group">
                                    <label><?php echo ucfirst(str_replace('_', ' ', $col)); ?></label>
                                    <?php if (strpos($col, 'date') !== false): ?>
                                        <input type="date" name="<?php echo $col; ?>" class="date-input" value="<?php echo date('Y-m-d'); ?>">
                                    <?php elseif (strpos($col, 'description') !== false || strpos($col, 'information') !== false || $col == 'answer'): ?>
                                        <textarea name="<?php echo $col; ?>" rows="4"></textarea>
                                    <?php else: ?>
                                        <input type="text" name="<?php echo $col; ?>">
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <button type="submit" name="add" class="btn-save">ðŸ’¾ Save Record</button>
                    <a href="admin_dashboard.php?table=<?php echo $table; ?>" style="margin-left: 10px;">Cancel</a>
                </form>
                
            <?php elseif ($action == 'edit' && $edit_record): ?>
                <h3>âœï¸ Edit Record #<?php echo $id; ?></h3>
                <form method="POST">
                    <?php if ($table == 'enrollments'): ?>
                        <div class="form-group">
                            <label>Student</label>
                            <select name="student_id" required>
                                <option value="">Select Student</option>
                                <?php $students = $pdo->query("SELECT id, name FROM students ORDER BY name")->fetchAll(); ?>
                                <?php foreach ($students as $s): ?>
                                    <option value="<?php echo $s['id']; ?>" <?php echo ($s['id'] == $edit_record['student_id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($s['name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Course</label>
                            <select name="course_id" required>
                                <option value="">Select Course</option>
                                <?php $courses = $pdo->query("SELECT id, course_name FROM courses ORDER BY course_name")->fetchAll(); ?>
                                <?php foreach ($courses as $c): ?>
                                    <option value="<?php echo $c['id']; ?>" <?php echo ($c['id'] == $edit_record['course_id']) ? 'selected' : ''; ?>><?php echo htmlspecialchars($c['course_name']); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Enrollment Date</label>
                            <input type="date" name="enrollment_date" class="date-input" value="<?php echo $edit_record['enrollment_date']; ?>" required>
                        </div>
                        <div class="form-group">
                            <label>Status</label>
                            <select name="status">
                                <option value="Active" <?php echo $edit_record['status'] == 'Active' ? 'selected' : ''; ?>>Active</option>
                                <option value="Completed" <?php echo $edit_record['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                <option value="Dropped" <?php echo $edit_record['status'] == 'Dropped' ? 'selected' : ''; ?>>Dropped</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Grade</label>
                            <select name="grade">
                                <option value="">N/A</option>
                                <option value="A" <?php echo $edit_record['grade'] == 'A' ? 'selected' : ''; ?>>A</option>
                                <option value="B" <?php echo $edit_record['grade'] == 'B' ? 'selected' : ''; ?>>B</option>
                                <option value="C" <?php echo $edit_record['grade'] == 'C' ? 'selected' : ''; ?>>C</option>
                                <option value="D" <?php echo $edit_record['grade'] == 'D' ? 'selected' : ''; ?>>D</option>
                                <option value="F" <?php echo $edit_record['grade'] == 'F' ? 'selected' : ''; ?>>F</option>
                            </select>
                        </div>
                    <?php else: ?>
                        <?php foreach ($column_names as $col): ?>
                            <?php if ($col != 'id' && $col != 'created_at' && $col != 'updated_at'): ?>
                                <div class="form-group">
                                    <label><?php echo ucfirst(str_replace('_', ' ', $col)); ?></label>
                                    <?php if (strpos($col, 'date') !== false): ?>
                                        <input type="date" name="<?php echo $col; ?>" class="date-input" value="<?php echo $edit_record[$col] ?? date('Y-m-d'); ?>">
                                    <?php elseif (strpos($col, 'description') !== false || strpos($col, 'information') !== false || $col == 'answer'): ?>
                                        <textarea name="<?php echo $col; ?>" rows="4"><?php echo htmlspecialchars($edit_record[$col] ?? ''); ?></textarea>
                                    <?php else: ?>
                                        <input type="text" name="<?php echo $col; ?>" value="<?php echo htmlspecialchars($edit_record[$col] ?? ''); ?>">
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    <button type="submit" name="edit" class="btn-save">ðŸ’¾ Update Record</button>
                    <a href="admin_dashboard.php?table=<?php echo $table; ?>" style="margin-left: 10px;">Cancel</a>
                </form>
                
            <?php else: ?>
                <div style="margin-bottom: 20px;">
                    <a href="?table=<?php echo $table; ?>&action=add" class="btn-add">âž• Add New Record</a>
                    <?php if ($table == 'students'): ?>
                        <a href="upload_students.php" style="margin-left: 10px; background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">ðŸ“¤ Bulk Upload CSV</a>
                        <a href="record_bank.php" style="margin-left: 10px; background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">ðŸ“š Student Record Bank</a>
                    <?php endif; ?>
                    <?php if ($table == 'enrollments'): ?>
                        <a href="add_enrollment.php" style="margin-left: 10px; background: #17a2b8; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">âž• Quick Add Enrollment</a>
                        <a href="enrollments.php" style="margin-left: 10px; background: #6c757d; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">ðŸ“‹ View All Enrollments</a>
                    <?php endif; ?>
                </div>
                
                <?php if (count($records) == 0): ?>
                    <p>No records found. Click "Add New Record" to get started.</p>
                <?php else: ?>
                    <div style="overflow-x: auto;">
                        <table>
                            <thead>
                                <tr>
                                    <?php foreach ($column_names as $col): ?>
                                        <th><?php echo ucfirst(str_replace('_', ' ', $col)); ?></th>
                                    <?php endforeach; ?>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($records as $record): ?>
                                <tr>
                                    <?php foreach ($column_names as $col): ?>
                                        <td>
                                            <?php 
                                            $value = $record[$col] ?? '';
                                            if ($col == 'status') {
                                                $class = $value == 'Active' ? 'status-active' : ($value == 'Completed' ? 'status-completed' : 'status-dropped');
                                                echo "<span class='status-badge $class'>" . htmlspecialchars($value) . "</span>";
                                            } elseif ($col == 'grade' && $value) {
                                                echo "<strong>" . htmlspecialchars($value) . "</strong>";
                                            } elseif (strpos($col, 'date') !== false && $value) {
                                                echo date('M d, Y', strtotime($value));
                                            } elseif (strlen($value) > 50) {
                                                echo htmlspecialchars(substr($value, 0, 50)) . '...';
                                            } else {
                                                echo htmlspecialchars($value);
                                            }
                                            ?>
                                        </td>
                                    <?php endforeach; ?>
                                    <td>
                                        <a href="?table=<?php echo $table; ?>&action=edit&id=<?php echo $record['id']; ?>" class="btn btn-edit">âœï¸ Edit</a>
                                        <a href="?table=<?php echo $table; ?>&action=delete&id=<?php echo $record['id']; ?>" class="btn btn-delete" onclick="return confirm('Delete this record permanently?')">ðŸ—‘ï¸ Delete</a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
flatpickr(".date-input", {
    dateFormat: "Y-m-d",
    allowInput: true
});
</script>
</body>
</html>
EOF

sudo chown apache:apache /var/www/html/its490/admin_dashboard.php
sudo chmod 644 /var/www/html/its490/admin_dashboard.php

