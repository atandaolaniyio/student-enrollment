<?php
require_once 'includes/Database.php';

$db = new Database();
$conn = $db->getConnection();

// Get article ID from URL
$id = $_GET['id'] ?? 0;

// Fetch the article
$stmt = $conn->prepare("SELECT * FROM news WHERE id = ?");
$stmt->execute([$id]);
$article = $stmt->fetch();

// If article not found, redirect to homepage
if (!$article) {
    header('Location: index.php');
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($article['title']); ?> - Purdue Northwest Dual Credit</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <style>
        /* Purdue Northwest Colors: Gold (#CAB77F) and Black (#000000) */
        :root {
            --pnw-gold: #CAB77F;
            --pnw-black: #000000;
            --pnw-dark-gold: #B69E5C;
        }
        
        body {
            background: linear-gradient(135deg, #f5f5f5 0%, #e0e0e0 100%);
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
        }
        
        /* Purdue Header with Lion */
        .purdue-header {
            background: linear-gradient(135deg, var(--pnw-black) 0%, #333333 100%);
            color: var(--pnw-gold);
            padding: 30px;
            border-radius: 15px 15px 0 0;
            margin-bottom: 0;
            text-align: center;
            position: relative;
            border-bottom: 5px solid var(--pnw-gold);
            box-shadow: 0 4px 15px rgba(0,0,0,0.3);
        }
        
        .header-content {
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 30px;
            flex-wrap: wrap;
        }
        
        .lion-image {
            width: 100px;
            height: 100px;
            background: linear-gradient(135deg, var(--pnw-gold), #B69E5C);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            box-shadow: 0 4px 10px rgba(0,0,0,0.5);
            animation: roar 3s infinite;
        }
        
        .lion-image i {
            font-size: 60px;
            color: var(--pnw-black);
            text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
        }
        
        @keyframes roar {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); box-shadow: 0 6px 15px var(--pnw-gold); }
            100% { transform: scale(1); }
        }
        
        .header-text h1 {
            font-size: 2.5em;
            margin: 0;
            text-shadow: 2px 2px 4px rgba(0,0,0,0.5);
            letter-spacing: 2px;
        }
        
        .header-text p {
            font-size: 1.2em;
            margin: 10px 0 0;
            opacity: 0.9;
        }
        
        /* Navigation Bar */
        .nav-bar {
            background: var(--pnw-black);
            padding: 15px;
            margin-bottom: 30px;
            display: flex;
            gap: 15px;
            flex-wrap: wrap;
            justify-content: center;
            border-bottom: 3px solid var(--pnw-gold);
        }
        
        .nav-link {
            color: var(--pnw-gold);
            text-decoration: none;
            padding: 8px 15px;
            border-radius: 5px;
            transition: all 0.3s;
            font-weight: bold;
        }
        
        .nav-link:hover {
            background: var(--pnw-gold);
            color: var(--pnw-black);
            transform: translateY(-2px);
        }
        
        .nav-link.active {
            background: var(--pnw-gold);
            color: var(--pnw-black);
        }
        
        /* Article Styles */
        .article-full {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            animation: fadeIn 0.5s ease;
            border: 1px solid var(--pnw-gold);
            position: relative;
            overflow: hidden;
        }
        
        .article-full::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 5px;
            background: linear-gradient(90deg, var(--pnw-gold), var(--pnw-black), var(--pnw-gold));
        }
        
        .article-full h1 {
            color: var(--pnw-black);
            font-size: 2.8em;
            margin-bottom: 20px;
            border-bottom: 3px solid var(--pnw-gold);
            padding-bottom: 15px;
            font-weight: 700;
        }
        
        .article-meta {
            background: linear-gradient(135deg, #f8f8f8 0%, #eeeeee 100%);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
            display: flex;
            gap: 30px;
            flex-wrap: wrap;
            border-left: 5px solid var(--pnw-gold);
        }
        
        .article-meta i {
            color: var(--pnw-gold);
            margin-right: 8px;
        }
        
        .article-meta span {
            color: var(--pnw-black);
            font-weight: 500;
        }
        
        .article-content {
            font-size: 1.2em;
            line-height: 1.9;
            color: #333;
        }
        
        .article-content p {
            margin-bottom: 25px;
        }
        
        /* Dual Credit Badge */
        .dual-credit-badge {
            display: inline-block;
            background: linear-gradient(135deg, var(--pnw-gold), #B69E5C);
            color: var(--pnw-black);
            padding: 8px 20px;
            border-radius: 30px;
            font-weight: bold;
            margin-bottom: 20px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.2);
        }
        
        /* Buttons */
        .btn-purdue {
            display: inline-block;
            background: var(--pnw-black);
            color: var(--pnw-gold);
            padding: 12px 30px;
            border-radius: 30px;
            text-decoration: none;
            font-weight: bold;
            transition: all 0.3s;
            border: 2px solid var(--pnw-gold);
            margin-top: 20px;
        }
        
        .btn-purdue:hover {
            background: var(--pnw-gold);
            color: var(--pnw-black);
            transform: translateX(-5px);
            border-color: var(--pnw-black);
        }
        
        /* Footer */
        .purdue-footer {
            background: var(--pnw-black);
            color: var(--pnw-gold);
            padding: 30px;
            border-radius: 0 0 15px 15px;
            margin-top: 30px;
            text-align: center;
            border-top: 5px solid var(--pnw-gold);
        }
        
        /* Social Links */
        .social-links {
            margin: 30px 0;
        }
        
        .social-link {
            display: inline-block;
            padding: 10px 20px;
            margin: 0 5px;
            border-radius: 5px;
            color: white;
            text-decoration: none;
            transition: all 0.3s;
        }
        
        .social-link.facebook { background: #1877f2; }
        .social-link.twitter { background: #1da1f2; }
        .social-link.instagram { background: linear-gradient(45deg, #f09433, #d62976, #962fbf); }
        .social-link:hover {
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        
        /* Animation */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 15px;
            }
            
            .article-full h1 {
                font-size: 2em;
            }
            
            .article-meta {
                flex-direction: column;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Purdue Header with Lion -->
        <div class="purdue-header">
            <div class="header-content">
                <div class="lion-image">
                    <i class="fas fa-lion"></i>
                </div>
                <div class="header-text">
                    <h1><i class="fas fa-graduation-cap"></i> PURDUE NORTHWEST</h1>
                    <p>Dual Credit Program - Pride of the Pride</p>
                </div>
            </div>
        </div>

        <!-- Navigation Bar -->
        <div class="nav-bar">
            <a href="index.php" class="nav-link"><i class="fas fa-home"></i> Home</a>
            <a href="dashboard.php" class="nav-link"><i class="fas fa-compass"></i> Dashboard</a>
            <a href="enrollment/students.php" class="nav-link"><i class="fas fa-users"></i> Dual Credit Students</a>
            <a href="enrollment/register-student.php" class="nav-link"><i class="fas fa-user-plus"></i> Register</a>
            <a href="enrollment/enroll-course.php" class="nav-link"><i class="fas fa-book"></i> Enroll</a>
            <a href="enrollment/courses.php" class="nav-link"><i class="fas fa-graduation-cap"></i> Courses</a>
            <a href="article.php?id=<?php echo $id; ?>" class="nav-link active"><i class="fas fa-newspaper"></i> Article</a>
        </div>

        <main>
            <!-- Dual Credit Badge -->
            <div style="text-align: center; margin-bottom: 20px;">
                <span class="dual-credit-badge">
                    <i class="fas fa-star"></i> Purdue Northwest Dual Credit Article
                </span>
            </div>

            <!-- Article Content -->
            <article class="article-full">
                <h1><?php echo htmlspecialchars($article['title']); ?></h1>
                
                <div class="article-meta">
                    <span><i class="fas fa-calendar-alt"></i> <?php echo date('F j, Y', strtotime($article['published_at'])); ?></span>
                    <span><i class="fas fa-clock"></i> <?php echo date('g:i a', strtotime($article['published_at'])); ?></span>
                    <span><i class="fas fa-user-graduate"></i> <?php echo htmlspecialchars($article['author'] ?? 'PNW Dual Credit Office'); ?></span>
                    <span><i class="fas fa-tag"></i> Dual Credit Program</span>
                </div>
                
                <div class="article-content">
                    <?php echo nl2br(htmlspecialchars($article['content'])); ?>
                </div>
                
                <div style="text-align: center;">
                    <a href="index.php" class="btn-purdue">
                        <i class="fas fa-arrow-left"></i> Back to PNW News
                    </a>
                </div>
            </article>

            <!-- Dual Credit Information Section -->
            <div style="background: linear-gradient(135deg, #f8f8f8 0%, #e8e8e8 100%); padding: 30px; border-radius: 15px; margin-top: 30px; border: 1px solid var(--pnw-gold);">
                <h3 style="color: var(--pnw-black); text-align: center; margin-bottom: 20px;">
                    <i class="fas fa-star" style="color: var(--pnw-gold);"></i> 
                    About Purdue Northwest Dual Credit
                </h3>
                <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px;">
                    <div style="text-align: center;">
                        <i class="fas fa-check-circle" style="color: var(--pnw-gold); font-size: 30px;"></i>
                        <h4 style="color: var(--pnw-black);">Earn College Credit</h4>
                        <p>While still in high school</p>
                    </div>
                    <div style="text-align: center;">
                        <i class="fas fa-dollar-sign" style="color: var(--pnw-gold); font-size: 30px;"></i>
                        <h4 style="color: var(--pnw-black);">Save on Tuition</h4>
                        <p>Reduced cost for dual credit</p>
                    </div>
                    <div style="text-align: center;">
                        <i class="fas fa-university" style="color: var(--pnw-gold); font-size: 30px;"></i>
                        <h4 style="color: var(--pnw-black);">PNW Faculty</h4>
                        <p>Learn from university instructors</p>
                    </div>
                </div>
            </div>

            <!-- Social Media Links -->
            <div class="social-links" style="text-align: center;">
                <h3 style="color: var(--pnw-black); margin-bottom: 15px;">
                    <i class="fas fa-share-alt"></i> Follow Purdue Northwest
                </h3>
                <div>
                    <a href="https://facebook.com/PurdueNorthwest" target="_blank" class="social-link facebook">
                        <i class="fab fa-facebook"></i> Facebook
                    </a>
                    <a href="https://twitter.com/PurdueNW" target="_blank" class="social-link twitter">
                        <i class="fab fa-twitter"></i> Twitter
                    </a>
                    <a href="https://instagram.com/purduenw" target="_blank" class="social-link instagram">
                        <i class="fab fa-instagram"></i> Instagram
                    </a>
                </div>
            </div>
        </main>

        <!-- Purdue Footer -->
        <div class="purdue-footer">
            <div style="display: flex; align-items: center; justify-content: center; gap: 20px; margin-bottom: 20px;">
                <i class="fas fa-lion" style="font-size: 40px;"></i>
                <div>
                    <h3 style="margin: 0;">Purdue University Northwest</h3>
                    <p style="margin: 5px 0 0; opacity: 0.8;">Dual Credit Program - Est. 1946</p>
                </div>
            </div>
            <p>&copy; <?php echo date('Y'); ?> Purdue University Northwest. All rights reserved.</p>
            <p style="font-size: 12px; margin-top: 10px;">2200 169th Street, Hammond, Indiana 46323 | (219) 989-2400</p>
            <p style="margin-top: 15px;">
                <i class="fas fa-star" style="color: var(--pnw-gold);"></i> 
                <i class="fas fa-star" style="color: var(--pnw-gold);"></i> 
                <i class="fas fa-star" style="color: var(--pnw-gold);"></i> 
                #PNWPride
            </p>
        </div>
    </div>
</body>
</html>
