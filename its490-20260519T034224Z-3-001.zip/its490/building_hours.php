<?php require_once 'db.php'; $hammond = $pdo->query("SELECT * FROM building_hours WHERE campus=1 ORDER BY name")->fetchAll(); $westville = $pdo->query("SELECT * FROM building_hours WHERE campus=2 ORDER BY name")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>Building Hours</title><style>body{font-family:Arial;margin:30px} table{border-collapse:collapse;width:100%;margin-bottom:30px} th,td{border:1px solid #ccc;padding:8px;font-size:14px} th{background:#4a86e8;color:white}</style></head>
<body><h2>🏛️ Building Hours</h2><a href="index.php">← Back</a><br><br>
<h3>Hammond Campus</h3><table><tr><th>Building</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th><th>Sun</th></tr>
<?php foreach($hammond as $b): ?>
<tr><td><?= htmlspecialchars($b['name']) ?></td><td><?= $b['monday'] ?></td><td><?= $b['tuesday'] ?></td><td><?= $b['wednesday'] ?></td><td><?= $b['thursday'] ?></td><td><?= $b['friday'] ?></td><td><?= $b['saturday'] ?></td><td><?= $b['sunday'] ?></td></tr>
<?php endforeach; ?>
</table><h3>Westville Campus</h3><table><tr><th>Building</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th><th>Sun</th></tr>
<?php foreach($westville as $b): ?>
<tr><td><?= htmlspecialchars($b['name']) ?></td><td><?= $b['monday'] ?></td><td><?= $b['tuesday'] ?></td><td><?= $b['wednesday'] ?></td><td><?= $b['thursday'] ?></td><td><?= $b['friday'] ?></td><td><?= $b['saturday'] ?></td><td><?= $b['sunday'] ?></td></tr>
<?php endforeach; ?>
</table></body></html>
