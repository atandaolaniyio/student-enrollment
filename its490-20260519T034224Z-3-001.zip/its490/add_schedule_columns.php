<?php
require_once 'db.php';

try {
    // Add columns for weekly schedule if they don't exist
    $columns = ['title', 'monday', 'tuesday', 'wednesday', 'thursday', 'friday'];
    foreach ($columns as $col) {
        try {
            $pdo->exec("ALTER TABLE courses ADD COLUMN $col TEXT");
            echo "Added column: $col<br>\n";
        } catch (PDOException $e) {
            if (strpos($e->getMessage(), 'Duplicate column') !== false) {
                echo "Column $col already exists.<br>\n";
            } else {
                throw $e;
            }
        }
    }
    echo "✅ Schedule columns ready.<br>\n";
} catch (PDOException $e) {
    echo "Error: " . $e->getMessage() . "<br>\n";
}
?>
