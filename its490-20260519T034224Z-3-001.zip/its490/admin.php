<?php
session_start();
require_once 'config.php';

// Simple admin authentication (improve this for production!)
$is_logged_in = false;
$error = '';

// Check if already logged in
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    $is_logged_in = true;
}

// Handle login
if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Simple hardcoded admin check - in production, check against database
    if ($username === 'admin' && $password === '123456') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = $username;
        $is_logged_in = true;
    } else {
        $error = 'Invalid username or password';
    }
}

// Handle logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// Handle actions if logged in
if ($is_logged_in) {
    // Add user
    if (isset($_POST['add_user'])) {
        $username = $_POST['username'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, created_at) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("sss", $username, $email, $password);
        
        if ($stmt->execute()) {
            // Add notification
            $notif_msg = "New user $username joined";
            $notif = $conn->prepare("INSERT INTO notifications (message, type, user_id) VALUES (?, 'info', ?)");
            $notif->bind_param("si", $notif_msg, $stmt->insert_id);
            $notif->execute();
            
            $success = "User added successfully!";
        } else {
            $error = "Error adding user: " . $conn->error;
        }
    }
    
    // Delete user
    if (isset($_GET['delete_user'])) {
        $id = intval($_GET['delete_user']);
        
        // First delete user's notifications
        $conn->query("DELETE FROM notifications WHERE user_id = $id");
        // Then delete user
        $conn->query("DELETE FROM users WHERE id = $id");
        
        header('Location: admin.php');
        exit;
    }
    
    // Add notification
    if (isset($_POST['add_notification'])) {
        $message = $_POST['message'];
        $type = $_POST['type'];
        $user_id = !empty($_POST['user_id']) ? intval($_POST['user_id']) : null;
        
        $stmt = $conn->prepare("INSERT INTO notifications (message, type, user_id, is_read) VALUES (?, ?, ?, FALSE)");
        $stmt->bind_param("ssi", $message, $type, $user_id);
        
        if ($stmt->execute()) {
            $success = "Notification added successfully!";
        } else {
            $error = "Error adding notification: " . $conn->error;
        }
    }
    
    // Delete notification
    if (isset($_GET['delete_notification'])) {
        $id = intval($_GET['delete_notification']);
        $conn->query("DELETE FROM notifications WHERE id = $id");
        header('Location: admin.php');
        exit;
    }
    
    // Mark all as read
    if (isset($_GET['mark_all_read'])) {
        $conn->query("UPDATE notifications SET is_read = TRUE");
        header('Location: admin.php');
        exit;
    }
    
    // Fetch data for display
    $users = $conn->query("SELECT * FROM users ORDER BY id DESC");
    $notifications = $conn->query("SELECT n.*, u.username FROM notifications n LEFT JOIN users u ON n.user_id = u.id ORDER BY n.created_at DESC LIMIT 50");
    $stats = [
        'total_users' => $conn->query("SELECT COUNT(*) as count FROM users")->fetch_assoc()['count'],
        'total_notifications' => $conn->query("SELECT COUNT(*) as count FROM notifications")->fetch_assoc()['count'],
        'unread_notifications' => $conn->query("SELECT COUNT(*) as count FROM notifications WHERE is_read = FALSE")->fetch_assoc()['count']
    ];
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - its490 Project</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: #f5f5f5;
            min-height: 100vh;
        }
        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 20px;
        }
        .header {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .header h1 {
            font-size: 24px;
        }
        .header h1 span {
            font-size: 14px;
            background: rgba(255,255,255,0.2);
            padding: 5px 10px;
            border-radius: 20px;
            margin-left: 10px;
        }
        .logout-btn {
            background: rgba(255,255,255,0.2);
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            text-decoration: none;
            transition: background 0.3s;
        }
        .logout-btn:hover {
            background: rgba(255,255,255,0.3);
        }
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }
        .stat-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .stat-card h3 {
            color: #666;
            font-size: 14px;
            margin-bottom: 10px;
        }
        .stat-card .number {
            font-size: 36px;
            font-weight: bold;
            color: #667eea;
        }
        .action-bar {
            background: white;
            padding: 15px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
        }
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 14px;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        .btn-primary {
            background: #667eea;
            color: white;
        }
        .btn-primary:hover {
            background: #5a67d8;
        }
        .btn-success {
            background: #48bb78;
            color: white;
        }
        .btn-success:hover {
            background: #38a169;
        }
        .btn-danger {
            background: #f56565;
            color: white;
        }
        .btn-danger:hover {
            background: #e53e3e;
        }
        .btn-warning {
            background: #ed8936;
            color: white;
        }
        .btn-warning:hover {
            background: #dd6b20;
        }
        .card {
            background: white;
            border-radius: 10px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .card h2 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 20px;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-size: 14px;
        }
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        .form-group textarea {
            height: 100px;
            resize: vertical;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th {
            background: #f8f9fa;
            padding: 12px;
            text-align: left;
            font-size: 14px;
            color: #555;
        }
        td {
            padding: 12px;
            border-bottom: 1px solid #f0f0f0;
        }
        tr:hover {
            background: #f8f9fa;
        }
        .badge {
            padding: 3px 8px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: bold;
        }
        .badge-success { background: #c6f6d5; color: #22543d; }
        .badge-info { background: #bee3f8; color: #2c5282; }
        .badge-warning { background: #feebc8; color: #744210; }
        .badge-unread { background: #fed7d7; color: #742a2a; }
        .action-links a {
            margin-right: 10px;
            text-decoration: none;
            font-size: 13px;
        }
        .alert {
            padding: 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }
        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border: 1px solid #9ae6b4;
        }
        .alert-error {
            background: #fed7d7;
            color: #742a2a;
            border: 1px solid #fc8181;
        }
        .tabs {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .tab {
            padding: 10px 20px;
            background: white;
            border: none;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
        }
        .tab.active {
            background: #667eea;
            color: white;
        }
        .tab-content {
            display: none;
        }
        .tab-content.active {
            display: block;
        }
        .login-container {
            max-width: 400px;
            margin: 100px auto;
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.2);
        }
        .login-container h2 {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
        }
        .login-container input {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .login-container button {
            width: 100%;
            padding: 12px;
            background: #667eea;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }
        .login-container button:hover {
            background: #5a67d8;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php if (!$is_logged_in): ?>
            <!-- Login Form -->
            <div class="login-container">
                <h2>Admin Login</h2>
                <?php if ($error): ?>
                    <div class="alert alert-error"><?php echo $error; ?></div>
                <?php endif; ?>
                <form method="POST">
                    <input type="text" name="username" placeholder="Username" required>
                    <input type="password" name="password" placeholder="Password" required>
                    <button type="submit" name="login">Login</button>
                </form>
            </div>
        <?php else: ?>
            <!-- Admin Dashboard -->
            <div class="header">
                <h1>Admin Panel <span>its490 Project</span></h1>
                <a href="?logout=1" class="logout-btn">Logout</a>
            </div>

            <?php if (isset($success)): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            <?php if ($error): ?>
                <div class="alert alert-error"><?php echo $error; ?></div>
            <?php endif; ?>

            <!-- Statistics -->
            <div class="stats-grid">
                <div class="stat-card">
                    <h3>Total Users</h3>
                    <div class="number"><?php echo $stats['total_users']; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Total Notifications</h3>
                    <div class="number"><?php echo $stats['total_notifications']; ?></div>
                </div>
                <div class="stat-card">
                    <h3>Unread Notifications</h3>
                    <div class="number"><?php echo $stats['unread_notifications']; ?></div>
                </div>
            </div>

            <!-- Action Bar -->
            <div class="action-bar">
                <button class="btn btn-primary" onclick="showTab('users')">Manage Users</button>
                <button class="btn btn-success" onclick="showTab('notifications')">Manage Notifications</button>
                <button class="btn btn-warning" onclick="showTab('add-user')">Add User</button>
                <button class="btn btn-info" onclick="showTab('add-notification')">Add Notification</button>
                <a href="?mark_all_read=1" class="btn btn-danger">Mark All Read</a>
                <a href="../index.php" class="btn" style="background: #718096; color: white;">View Site</a>
            </div>

            <!-- Tabs -->
            <div class="tabs">
                <button class="tab active" onclick="showTab('users')">Users</button>
                <button class="tab" onclick="showTab('notifications')">Notifications</button>
                <button class="tab" onclick="showTab('add-user')">Add User</button>
                <button class="tab" onclick="showTab('add-notification')">Add Notification</button>
            </div>

            <!-- Users Tab -->
            <div id="users-tab" class="tab-content active">
                <div class="card">
                    <h2>User Management</h2>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Username</th>
                                    <th>Email</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($user = $users->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $user['id']; ?></td>
                                    <td><?php echo htmlspecialchars($user['username']); ?></td>
                                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($user['created_at'])); ?></td>
                                    <td class="action-links">
                                        <a href="?delete_user=<?php echo $user['id']; ?>" 
                                           onclick="return confirm('Delete this user?')" 
                                           style="color: #f56565;">Delete</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Notifications Tab -->
            <div id="notifications-tab" class="tab-content">
                <div class="card">
                    <h2>Notification Management</h2>
                    <div class="table-container">
                        <table>
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Message</th>
                                    <th>Type</th>
                                    <th>For</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($notif = $notifications->fetch_assoc()): ?>
                                <tr>
                                    <td>#<?php echo $notif['id']; ?></td>
                                    <td><?php echo htmlspecialchars($notif['message']); ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $notif['type']; ?>">
                                            <?php echo $notif['type']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo $notif['username'] ?: 'All Users'; ?></td>
                                    <td>
                                        <?php if($notif['is_read']): ?>
                                            <span class="badge badge-success">Read</span>
                                        <?php else: ?>
                                            <span class="badge badge-unread">Unread</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo date('Y-m-d H:i', strtotime($notif['created_at'])); ?></td>
                                    <td class="action-links">
                                        <a href="?delete_notification=<?php echo $notif['id']; ?>" 
                                           onclick="return confirm('Delete this notification?')"
                                           style="color: #f56565;">Delete</a>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Add User Tab -->
            <div id="add-user-tab" class="tab-content">
                <div class="card">
                    <h2>Add New User</h2>
                    <form method="POST">
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Username</label>
                                <input type="text" name="username" required>
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" required>
                            </div>
                            <div class="form-group">
                                <label>Password</label>
                                <input type="password" name="password" required>
                            </div>
                        </div>
                        <button type="submit" name="add_user" class="btn btn-success">Add User</button>
                    </form>
                </div>
            </div>

            <!-- Add Notification Tab -->
            <div id="add-notification-tab" class="tab-content">
                <div class="card">
                    <h2>Add New Notification</h2>
                    <form method="POST">
                        <div class="form-group">
                            <label>Message</label>
                            <textarea name="message" required></textarea>
                        </div>
                        <div class="form-grid">
                            <div class="form-group">
                                <label>Type</label>
                                <select name="type">
                                    <option value="info">Info</option>
                                    <option value="success">Success</option>
                                    <option value="warning">Warning</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Send to (leave empty for all users)</label>
                                <select name="user_id">
                                    <option value="">All Users</option>
                                    <?php 
                                    $users->data_seek(0); // Reset pointer
                                    while($user = $users->fetch_assoc()): 
                                    ?>
                                    <option value="<?php echo $user['id']; ?>">
                                        <?php echo htmlspecialchars($user['username']); ?>
                                    </option>
                                    <?php endwhile; ?>
                                </select>
                            </div>
                        </div>
                        <button type="submit" name="add_notification" class="btn btn-success">Add Notification</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>

    <script>
    function showTab(tabName) {
        // Hide all tabs
        document.querySelectorAll('.tab-content').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Show selected tab
        document.getElementById(tabName + '-tab').classList.add('active');
        
        // Update tab buttons
        document.querySelectorAll('.tab').forEach(btn => {
            btn.classList.remove('active');
        });
        event.target.classList.add('active');
    }
    </script>
</body>
</html>
