<?php
require_once 'db.php';

echo "<h2>Importing Academic Resources Data (SAFE MODE)</h2>";
echo "<p>This script will:</p>";
echo "<ul>";
echo "<li>✅ Keep your existing 2 records (Tutoring Center, Writing Lab)</li>";
echo "<li>✅ Add 5 new records from CSV</li>";
echo "<li>✅ NEVER delete any existing data</li>";
echo "</ul>";

// Academic resources data from CSV
$resources = [
    [
        'name' => 'Academic Colleges',
        'category' => 'Colleges',
        'information' => 'College of Business
L. Hamer, Dean
Hammond Campus: Anderson Building 356, (219)989-2595
Westville Campus: Technology Building 186, (219)785-5263

College of Humanities, Education, and Social Sciences
E. Carey, Dean
Hammond Campus: Classroom Office Building 152, (219)989-2401
Westville Campus: Technology Building 341, (219)785-5647

College of Engineering and Science
N. Latif, Interim Dean
Hammond Campus: Gyte Building 181, (219)989-2468
Westville Campus: Schwarz Building 160, (219)785-5736

College of Nursing
L. Hopp, Dean
Hammond Campus: Classroom Office Building 313, (219)989-2814
Westville Campus: Technology Building 357, (219)785-5454

College of Technology
N. Latif, Dean
Hammond Campus: Anderson Building 202, (219)989-8324
Westville Campus: Technology Building 269, (219)785-5619

Honors College
J. Swarts, Dean
Hammond Campus: Student Union Library 320, (219)989-3160
Westville Campus: Library Student Faculty 069, (219)785-5366'
    ],
    [
        'name' => 'Academic Calendar',
        'category' => 'Calendar',
        'information' => 'See PNWs Academic Schedule: https://www.pnw.edu/registrar/academic-schedule/'
    ],
    [
        'name' => 'Degrees',
        'category' => 'Academics',
        'information' => 'Please check the online listing of current degrees offered. https://www.pnw.edu/program-finder/'
    ],
    [
        'name' => 'Academic Advising',
        'category' => 'Advising',
        'information' => 'The responsibility for all academic decisions belongs to the student.

https://www.pnw.edu/advising/
https://www.pnw.edu/advising/exploratory-advising/

Purdue University Northwest recognizes academic advising as a critical component of the educational experience of students.'
    ],
    [
        'name' => 'Student Academic Support',
        'category' => 'Support Services',
        'information' => 'Location: Hammond Campus: Gyte Building, room 102 | Westville Campus: LSF Building, room 202
Phone: Hammond: (219)989-3227 | Westville: (219)785-5628
Website: pnw.edu/sas | Email: sas@pnw.edu'
    ]
];

$inserted = 0;
$existing_count = 0;

foreach ($resources as $resource) {
    // Check if record already exists
    $check = $pdo->prepare("SELECT id FROM academic_resources WHERE name = ?");
    $check->execute([$resource['name']]);
    
    if (!$check->fetch()) {
        // Only insert if it doesn't exist
        $insert = $pdo->prepare("INSERT INTO academic_resources (name, category, information, is_active) VALUES (?, ?, ?, 1)");
        $insert->execute([$resource['name'], $resource['category'], $resource['information']]);
        echo "✅ Added new: " . htmlspecialchars($resource['name']) . "<br>";
        $inserted++;
    } else {
        echo "⏭️ Already exists: " . htmlspecialchars($resource['name']) . " (skipped)<br>";
        $existing_count++;
    }
}

echo "<hr>";
echo "<strong>Summary:</strong><br>";
echo "📊 Your existing records (Tutoring Center, Writing Lab): KEPT<br>";
echo "✅ New records added: $inserted<br>";
echo "⏭️ Already existed: $existing_count<br>";
echo "<br><strong>🎉 Total records now: " . ($inserted + $existing_count + 2) . "</strong><br>";

// Show all current records
echo "<h3>All Academic Resources in Database:</h3>";
$all = $pdo->query("SELECT id, name, category FROM academic_resources ORDER BY id");
echo "<table border='1' cellpadding='8' style='border-collapse: collapse;'>";
echo "<tr><th>ID</th><th>Name</th><th>Category</th></tr>";
while ($row = $all->fetch()) {
    $highlight = ($row['name'] == 'Tutoring Center' || $row['name'] == 'Writing Lab') ? 'style="background:#d4edda;"' : '';
    echo "<tr $highlight>";
    echo "<td>" . $row['id'] . "</td>";
    echo "<td>" . htmlspecialchars($row['name']) . "</td>";
    echo "<td>" . htmlspecialchars($row['category'] ?? 'N/A') . "</td>";
    echo "</tr>";
}
echo "</table>";
echo "<p><span style='background:#d4edda;padding:2px 8px;'>Green highlighted</span> = Your original records (preserved)</p>";

echo '<br><a href="admin_dashboard.php?table=academic_resources" style="background:#4a86e8;color:white;padding:10px 15px;text-decoration:none;border-radius:5px;">📊 View in Admin Panel</a>';
?>
