<?php
include 'config.php';

// Get current table from URL, default to first table
$current_table = isset($_GET['table']) ? $_GET['table'] : '';

// Get all tables in database
$tables_result = $conn->query("SHOW TABLES");
$tables = [];
while ($row = $tables_result->fetch_array()) {
    $tables[] = $row[0];
}

// If no table selected, use the first one
if (empty($current_table) && !empty($tables)) {
    $current_table = $tables[0];
}

// Handle Add Record
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_record'])) {
    $table = $conn->real_escape_string($_POST['table_name']);
    
    // Get column info for this table
    $columns_result = $conn->query("SHOW COLUMNS FROM `$table`");
    $columns = [];
    $values = [];
    $fields = [];
    
    while ($col = $columns_result->fetch_assoc()) {
        $field = $col['Field'];
        // Skip auto-increment columns
        if ($col['Extra'] != 'auto_increment') {
            if (isset($_POST[$field])) {
                $columns[] = "`$field`";
                $values[] = "'" . $conn->real_escape_string($_POST[$field]) . "'";
                $fields[] = $field;
            }
        }
    }
    
    if (!empty($columns)) {
        $sql = "INSERT INTO `$table` (" . implode(", ", $columns) . ") VALUES (" . implode(", ", $values) . ")";
        if ($conn->query($sql)) {
            header("Location: index.php?table=$table&msg=added");
            exit();
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

// Handle Edit Record
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_record'])) {
    $table = $conn->real_escape_string($_POST['table_name']);
    $id = intval($_POST['id']);
    $id_field = $_POST['id_field'];
    
    // Build update query
    $updates = [];
    $columns_result = $conn->query("SHOW COLUMNS FROM `$table`");
    
    while ($col = $columns_result->fetch_assoc()) {
        $field = $col['Field'];
        if ($field != $id_field && isset($_POST[$field])) {
            $updates[] = "`$field` = '" . $conn->real_escape_string($_POST[$field]) . "'";
        }
    }
    
    if (!empty($updates)) {
        $sql = "UPDATE `$table` SET " . implode(", ", $updates) . " WHERE `$id_field` = $id";
        if ($conn->query($sql)) {
            header("Location: index.php?table=$table&msg=updated");
            exit();
        } else {
            $error = "Error: " . $conn->error;
        }
    }
}

// Handle Delete Record
if (isset($_GET['delete']) && isset($_GET['id']) && isset($_GET['id_field'])) {
    $table = $conn->real_escape_string($_GET['table']);
    $id = intval($_GET['id']);
    $id_field = $conn->real_escape_string($_GET['id_field']);
    
    $sql = "DELETE FROM `$table` WHERE `$id_field` = $id";
    if ($conn->query($sql)) {
        header("Location: index.php?table=$table&msg=deleted");
        exit();
    }
}

// Get data for current table
$data = [];
$columns = [];
$id_field = '';
$primary_key = '';

if (!empty($current_table) && in_array($current_table, $tables)) {
    // Get column info
    $columns_result = $conn->query("SHOW COLUMNS FROM `$current_table`");
    while ($col = $columns_result->fetch_assoc()) {
        $columns[] = $col;
        if ($col['Key'] == 'PRI') {
            $primary_key = $col['Field'];
            $id_field = $col['Field'];
        }
    }
    
    // Get data
    $data_result = $conn->query("SELECT * FROM `$current_table` ORDER BY `$primary_key` DESC");
    while ($row = $data_result->fetch_assoc()) {
        $data[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Database Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .app-container {
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles */
        .sidebar {
            width: 280px;
            background: rgba(255, 255, 255, 0.95);
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            padding: 20px;
            overflow-y: auto;
        }
        
        .sidebar h2 {
            color: #333;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #667eea;
        }
        
        .table-list {
            list-style: none;
        }
        
        .table-list li {
            margin-bottom: 8px;
        }
        
        .table-list a {
            display: block;
            padding: 10px 15px;
            color: #555;
            text-decoration: none;
            border-radius: 8px;
            transition: all 0.3s;
        }
        
        .table-list a:hover {
            background: #667eea;
            color: white;
            transform: translateX(5px);
        }
        
        .table-list a.active {
            background: #667eea;
            color: white;
            font-weight: bold;
        }
        
        /* Main Content Styles */
        .main-content {
            flex: 1;
            padding: 30px;
            overflow-y: auto;
        }
        
        .content-card {
            background: white;
            border-radius: 15px;
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
            padding: 30px;
        }
        
        h1 {
            color: #333;
            margin-bottom: 10px;
        }
        
        .subtitle {
            color: #666;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid #e0e0e0;
        }
        
        .message {
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            text-align: center;
        }
        
        .message.success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .message.error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Form Styles */
        .form-container {
            background: #f8f9fa;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 30px;
        }
        
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 15px;
        }
        
        .form-group {
            margin-bottom: 15px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            color: #555;
            font-weight: bold;
        }
        
        .form-group input, .form-group select, .form-group textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }
        
        button {
            background: #667eea;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: all 0.3s;
        }
        
        button:hover {
            transform: translateY(-2px);
            background: #5a67d8;
        }
        
        /* Records Display - Vertical Layout */
        .records-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
            margin-top: 20px;
        }
        
        .record-card {
            background: white;
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            transition: all 0.3s;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .record-card:hover {
            transform: translateX(5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
            border-left: 4px solid #667eea;
        }
        
        .record-field {
            display: flex;
            padding: 8px 12px;
            border-bottom: 1px solid #f0f0f0;
        }
        
        .record-field:last-child {
            border-bottom: none;
        }
        
        .field-label {
            font-weight: bold;
            width: 200px;
            color: #555;
        }
        
        .field-value {
            flex: 1;
            color: #333;
            word-break: break-word;
        }
        
        .record-actions {
            margin-top: 15px;
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }
        
        .btn-edit {
            background: #28a745;
        }
        
        .btn-edit:hover {
            background: #218838;
        }
        
        .btn-delete {
            background: #dc3545;
        }
        
        .btn-delete:hover {
            background: #c82333;
        }
        
        .btn-cancel {
            background: #6c757d;
        }
        
        /* Modal Styles */
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
            animation: fadeIn 0.3s;
        }
        
        .modal-content {
            background-color: white;
            margin: 5% auto;
            padding: 30px;
            border-radius: 10px;
            width: 90%;
            max-width: 600px;
            max-height: 80%;
            overflow-y: auto;
            animation: slideIn 0.3s;
        }
        
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
        
        @keyframes slideIn {
            from { transform: translateY(-50px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }
        
        .close {
            float: right;
            font-size: 28px;
            cursor: pointer;
            color: #aaa;
        }
        
        .close:hover {
            color: #000;
        }
        
        @media (max-width: 768px) {
            .app-container {
                flex-direction: column;
            }
            
            .sidebar {
                width: 100%;
            }
            
            .record-field {
                flex-direction: column;
            }
            
            .field-label {
                width: 100%;
                margin-bottom: 5px;
            }
            
            .main-content {
                padding: 20px;
            }
        }
        
        .stats {
            display: inline-block;
            background: #667eea;
            color: white;
            padding: 2px 8px;
            border-radius: 20px;
            font-size: 12px;
            margin-left: 10px;
        }
        
        .empty-state {
            text-align: center;
            padding: 60px;
            color: #999;
        }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar with table list -->
        <div class="sidebar">
            <h2>📊 Database Tables</h2>
            <ul class="table-list">
                <?php foreach ($tables as $table): ?>
                    <li>
                        <a href="index.php?table=<?php echo urlencode($table); ?>" 
                           class="<?php echo $current_table == $table ? 'active' : ''; ?>">
                            📁 <?php echo htmlspecialchars($table); ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
        
        <!-- Main content -->
        <div class="main-content">
            <div class="content-card">
                <h1>📋 <?php echo htmlspecialchars($current_table); ?> Management</h1>
                <p class="subtitle">View, add, edit, and delete records from <?php echo htmlspecialchars($current_table); ?></p>
                
                <?php if(isset($_GET['msg'])): ?>
                    <div class="message success">
                        <?php 
                        if($_GET['msg'] == 'added') echo "✅ Record added successfully!";
                        if($_GET['msg'] == 'updated') echo "✏️ Record updated successfully!";
                        if($_GET['msg'] == 'deleted') echo "🗑️ Record deleted successfully!";
                        ?>
                    </div>
                <?php endif; ?>
                
                <?php if(isset($error)): ?>
                    <div class="message error">
                        <?php echo $error; ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!empty($current_table) && in_array($current_table, $tables)): ?>
                    <!-- Add Record Form -->
                    <div class="form-container">
                        <h3>➕ Add New Record</h3>
                        <form method="POST" action="">
                            <input type="hidden" name="table_name" value="<?php echo htmlspecialchars($current_table); ?>">
                            <div class="form-grid">
                                <?php foreach ($columns as $col): ?>
                                    <?php if ($col['Extra'] != 'auto_increment' && $col['Field'] != $primary_key): ?>
                                        <div class="form-group">
                                            <label><?php echo htmlspecialchars($col['Field']); ?>:</label>
                                            <?php if (strpos($col['Type'], 'text') !== false): ?>
                                                <textarea name="<?php echo htmlspecialchars($col['Field']); ?>" rows="3"></textarea>
                                            <?php else: ?>
                                                <input type="text" name="<?php echo htmlspecialchars($col['Field']); ?>" 
                                                       <?php echo ($col['Null'] == 'NO' && $col['Default'] === null) ? 'required' : ''; ?>>
                                            <?php endif; ?>
                                        </div>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </div>
                            <button type="submit" name="add_record">Add Record</button>
                        </form>
                    </div>
                    
                    <!-- Records Display -->
                    <div class="records-container">
                        <h3>📝 Records (<?php echo count($data); ?> total)</h3>
                        <?php if (count($data) > 0): ?>
                            <?php foreach ($data as $row): ?>
                                <div class="record-card">
                                    <?php foreach ($row as $field => $value): ?>
                                        <div class="record-field">
                                            <div class="field-label"><?php echo htmlspecialchars($field); ?>:</div>
                                            <div class="field-value">
                                                <?php echo htmlspecialchars($value !== null ? $value : '(NULL)'); ?>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                    <div class="record-actions">
                                        <button class="btn-edit" onclick="openEditModal(<?php echo htmlspecialchars(json_encode($row)); ?>, '<?php echo htmlspecialchars($current_table); ?>', '<?php echo htmlspecialchars($primary_key); ?>')">✏️ Edit</button>
                                        <button class="btn-delete" onclick="confirmDelete('<?php echo htmlspecialchars($current_table); ?>', <?php echo $row[$primary_key]; ?>, '<?php echo htmlspecialchars($primary_key); ?>')">🗑️ Delete</button>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="empty-state">
                                <p>📭 No records found in this table.</p>
                                <p>Click "Add Record" above to create your first entry!</p>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="empty-state">
                        <p>📂 Select a table from the sidebar to view and manage records.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Edit Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeModal()">&times;</span>
            <h3>✏️ Edit Record</h3>
            <form method="POST" action="" id="editForm">
                <input type="hidden" name="table_name" id="edit_table_name">
                <input type="hidden" name="id" id="edit_id">
                <input type="hidden" name="id_field" id="edit_id_field">
                <div id="edit_fields"></div>
                <div style="margin-top: 20px;">
                    <button type="submit" name="edit_record">Update Record</button>
                    <button type="button" class="btn-cancel" onclick="closeModal()">Cancel</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function openEditModal(record, tableName, idField) {
            document.getElementById('edit_table_name').value = tableName;
            document.getElementById('edit_id').value = record[idField];
            document.getElementById('edit_id_field').value = idField;
            
            // Generate form fields
            let fieldsHtml = '';
            for (let field in record) {
                if (field !== idField) {
                    fieldsHtml += `
                        <div class="form-group">
                            <label>${field}:</label>
                            <input type="text" name="${field}" value="${escapeHtml(record[field] || '')}">
                        </div>
                    `;
                }
            }
            document.getElementById('edit_fields').innerHTML = fieldsHtml;
            document.getElementById('editModal').style.display = 'block';
        }
        
        function escapeHtml(text) {
            if (text === null || text === undefined) return '';
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }
        
        function closeModal() {
            document.getElementById('editModal').style.display = 'none';
        }
        
        function confirmDelete(tableName, id, idField) {
            if (confirm('Are you sure you want to delete this record? This action cannot be undone!')) {
                window.location.href = `index.php?table=${tableName}&delete=1&id=${id}&id_field=${idField}`;
            }
        }
        
        // Close modal when clicking outside
        window.onclick = function(event) {
            let modal = document.getElementById('editModal');
            if (event.target == modal) {
                modal.style.display = 'none';
            }
        }
        
        // Auto-hide message after 3 seconds
        setTimeout(function() {
            let message = document.querySelector('.message');
            if (message) {
                message.style.display = 'none';
            }
        }, 3000);
    </script>
</body>
</html>

<?php
$conn->close();
?>
