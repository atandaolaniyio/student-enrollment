<?php
require_once 'db.php';
$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("SELECT * FROM students WHERE id = ?");
$stmt->execute([$id]);
$student = $stmt->fetch();

if (!$student) die("Student not found");

$enrollments = $pdo->prepare("SELECT e.*, c.course_name FROM enrollments e JOIN courses c ON e.course_id = c.id WHERE e.student_id = ? ORDER BY e.enrollment_date DESC");
$enrollments->execute([$id]);
$enrollments = $enrollments->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Student Record</title>
    <style>
        body {font-family: Arial, sans-serif; margin: 30px;}
        table {border-collapse: collapse; width: 100%;}
        th, td {border: 1px solid #ccc; padding: 10px;}
    </style>
</head>
<body>
    <h2>Student Record: <?= htmlspecialchars($student['first_name'].' '.$student['last_name']) ?></h2>
    <a href="students.php">← Back to Students</a><br><br>

    <h3>Enrollments</h3>
    <table>
        <tr><th>Course</th><th>Date</th><th>Status</th><th>Grade</th></tr>
        <?php if (empty($enrollments)): ?>
            <tr><td colspan="4">No enrollments yet</td></tr>
        <?php else: foreach($enrollments as $e): ?>
            <tr>
                <td><?= htmlspecialchars($e['course_name']) ?></td>
                <td><?= $e['enrollment_date'] ?></td>
                <td><?= $e['status'] ?></td>
                <td><?= $e['grade'] ?? 'N/A' ?></td>
            </tr>
        <?php endforeach; endif; ?>
    </table>
</body>
</html>
