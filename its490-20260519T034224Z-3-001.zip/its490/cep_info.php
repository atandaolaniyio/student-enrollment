<?php require_once 'db.php'; $info = $pdo->query("SELECT * FROM cep_info ORDER BY id")->fetchAll(); ?>
<!DOCTYPE html>
<html><head><title>Concurrent Enrollment Info</title><style>body{font-family:Arial;margin:30px} .card{border:1px solid #ddd;padding:15px;margin-bottom:20px;border-radius:8px}</style></head>
<body><h2>🎓 Concurrent Enrollment Program</h2><a href="index.php">← Back</a><br><br>
<?php foreach($info as $i): ?>
<div class="card"><h3><?= htmlspecialchars($i['name']) ?></h3><div><?= nl2br(htmlspecialchars($i['information'])) ?></div></div>
<?php endforeach; ?>
</body></html>
