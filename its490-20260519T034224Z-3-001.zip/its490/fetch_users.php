<?php
require_once 'config.php';

$search = $_GET['search'] ?? '';
$where = '';
if ($search) {
    $search = $conn->real_escape_string($search);
    $where = "WHERE username LIKE '%$search%' OR email LIKE '%$search%'";
}

$sql = "SELECT id, username, email, role FROM users $where ORDER BY id";
$result = $conn->query($sql);
?>
<table border="1" cellpadding="8" cellspacing="0" style="width:100%; border-collapse: collapse;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Username</th>
            <th>Email</th>
            <th>Role</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php while($user = $result->fetch_assoc()): ?>
            <tr id="user-row-<?php echo $user['id']; ?>">
                <td><?php echo $user['id']; ?></td>
                <td class="editable-cell" data-field="username"><?php echo htmlspecialchars($user['username']); ?></td>
                <td class="editable-cell" data-field="email"><?php echo htmlspecialchars($user['email']); ?></td>
                <td class="editable-cell" data-field="role"><?php echo htmlspecialchars($user['role']); ?></td>
                <td class="actions">
                    <button class="btn-edit" onclick="editUser(<?php echo $user['id']; ?>)">Edit</button>
                    <button class="btn-delete" onclick="deleteUser(<?php echo $user['id']; ?>)">Delete</button>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>
