<?php
require_once "config.php";
$section = $_GET["section"] ?? "students";
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    unset($_POST["submit"]);
    $columns = array_keys($_POST);
    $placeholders = ":" . implode(", :", $columns);
    $sql = "INSERT INTO $section (" . implode(",", $columns) . ") VALUES (" . $placeholders . ")";
    $stmt = $pdo->prepare($sql);
    
    foreach($_POST as $key => $value) {
        $stmt->bindValue(":$key", $value);
    }
    
    if ($stmt->execute()) {
        header("Location: admin_dashboard.php?section=$section");
        exit;
    } else {
        $message = "Error adding record";
    }
}

$stmt = $pdo->query("SHOW COLUMNS FROM $section");
$columns = $stmt->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Record</title>
    <style>
        body { font-family: Arial; margin: 40px; background: #f0f2f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; }
        input, textarea, select { width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ddd; border-radius: 4px; }
        button { background: #4a86e8; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; }
        .error { color: red; padding: 10px; background: #f8d7da; border-radius: 5px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Add New Record to <?php echo ucfirst($section); ?></h2>
    <a href="admin_dashboard.php?section=<?php echo $section; ?>">← Back</a>
    
    <?php if($message): ?>
        <div class="error"><?php echo $message; ?></div>
    <?php endif; ?>
    
    <form method="POST">
        <?php foreach($columns as $col): ?>
            <?php if($col["Field"] != "id" && $col["Field"] != "created_at" && $col["Field"] != "updated_at"): ?>
                <label><?php echo ucfirst(str_replace("_", " ", $col["Field"])); ?>:</label>
                <?php if(strpos($col["Type"], "text") !== false): ?>
                    <textarea name="<?php echo $col["Field"]; ?>" rows="5"></textarea>
                <?php else: ?>
                    <input type="text" name="<?php echo $col["Field"]; ?>">
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; ?>
        <button type="submit" name="submit">Save Record</button>
    </form>
</div>
</body>
</html>
