<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Connect to its490_project for user management
$host = 'database1.cfcucs4a2nij.us-east-2.rds.amazonaws.com';
$username = 'admin';
$password = 'F2mC4?datA';
$database = 'its490_project';

$conn = new mysqli($host, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create users table if it doesn't exist
$conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(50) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

// Handle actions
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['action_add'])) {
        $stmt = $conn->prepare("INSERT INTO users (username, email, password, role) VALUES (?, ?, ?, ?)");
        $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $stmt->bind_param("ssss", $_POST['username'], $_POST['email'], $pass, $_POST['role']);
        if ($stmt->execute()) {
            header("Location: users.php?msg=added");
        } else {
            header("Location: users.php?msg=error&error=" . urlencode($stmt->error));
        }
        exit;
    } elseif (isset($_POST['action_update'])) {
        $stmt = $conn->prepare("UPDATE users SET username=?, email=?, role=? WHERE id=?");
        $stmt->bind_param("sssi", $_POST['username'], $_POST['email'], $_POST['role'], $_POST['id']);
        $stmt->execute();
        header("Location: users.php?msg=updated");
        exit;
    } elseif (isset($_POST['action_delete'])) {
        $stmt = $conn->prepare("DELETE FROM users WHERE id=?");
        $stmt->bind_param("i", $_POST['id']);
        $stmt->execute();
        header("Location: users.php?msg=deleted");
        exit;
    }
}

$users = $conn->query("SELECT id, username, email, role FROM users ORDER BY id");
$message = $_GET['msg'] ?? '';
$error = $_GET['error'] ?? '';
?>
<!DOCTYPE html>
<html>
<head>
    <title>User Management</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f0f2f5; }
        .container { max-width: 1200px; margin: auto; background: white; padding: 20px; border-radius: 8px; }
        h1 { color: #667eea; }
        .btn { padding: 8px 15px; border: none; border-radius: 5px; cursor: pointer; }
        .btn-success { background: #28a745; color: white; }
        .btn-warning { background: #ffc107; }
        .btn-danger { background: #dc3545; color: white; }
        .btn-back { background: #6c757d; color: white; text-decoration: none; display: inline-block; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; margin-top: 20px; }
        th { background: #667eea; color: white; padding: 12px; text-align: left; }
        td { padding: 10px; border-bottom: 1px solid #ddd; }
        .add-form { background: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; }
        .flash { padding: 10px; margin-bottom: 20px; border-radius: 5px; }
        .flash.success { background: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .flash.error { background: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        input, select { padding: 8px; margin: 5px 10px 5px 0; border: 1px solid #ddd; border-radius: 4px; }
    </style>
</head>
<body>
<div class="container">
    <h1>User Management</h1>
    <a href="index.php" class="btn btn-back">← Back to Dashboard</a>
    
    <?php if($message == 'added'): ?>
        <div class="flash success">✅ User added successfully!</div>
    <?php elseif($message == 'updated'): ?>
        <div class="flash success">✅ User updated successfully!</div>
    <?php elseif($message == 'deleted'): ?>
        <div class="flash success">✅ User deleted successfully!</div>
    <?php elseif($error): ?>
        <div class="flash error">❌ Error: <?php echo htmlspecialchars($error); ?></div>
    <?php endif; ?>
    
    <div class="add-form">
        <h3>➕ Add New User</h3>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="password" placeholder="Password" required>
            <select name="role">
                <option value="user">User</option>
                <option value="concurrent_enrollment">Concurrent Enrollment</option>
                <option value="admin">Admin</option>
            </select>
            <button type="submit" name="action_add" class="btn btn-success">Add User</button>
        </form>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if($users && $users->num_rows > 0): ?>
                <?php while($user = $users->fetch_assoc()): ?>
                <tr>
                    <form method="POST" style="display: inline;">
                        <input type="hidden" name="id" value="<?php echo $user['id']; ?>">
                        <td><?php echo $user['id']; ?></td>
                        <td><input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required></td>
                        <td><input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required></td>
                        <td>
                            <select name="role">
                                <option value="user" <?php echo $user['role'] == 'user' ? 'selected' : ''; ?>>User</option>
                                <option value="concurrent_enrollment" <?php echo $user['role'] == 'concurrent_enrollment' ? 'selected' : ''; ?>>Concurrent Enrollment</option>
                                <option value="admin" <?php echo $user['role'] == 'admin' ? 'selected' : ''; ?>>Admin</option>
                            </select>
                        </select>
                        <td>
                            <button type="submit" name="action_update" class="btn btn-warning">Update</button>
                            <button type="submit" name="action_delete" class="btn btn-danger" onclick="return confirm('Delete this user?')">Delete</button>
                        </select>
                    </form>
                </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="5" style="text-align: center;">No users found. Add your first user above!</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>
