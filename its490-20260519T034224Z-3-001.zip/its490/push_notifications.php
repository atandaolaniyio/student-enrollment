<?php
require_once 'db.php';

$message = '';
$error = '';

// Handle add notification
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_notification'])) {
    $title = trim($_POST['title'] ?? '');
    $body = trim($_POST['body'] ?? '');
    $target_type = $_POST['target_type'] ?? 'all';
    
    if ($title && $body) {
        $stmt = $pdo->prepare("INSERT INTO push_notifications (title, body, target_type, sent_to_count, created_at) VALUES (?, ?, ?, 0, NOW())");
        if ($stmt->execute([$title, $body, $target_type])) {
            $message = "✅ Notification record added successfully!";
        } else {
            $error = "❌ Failed to add notification record.";
        }
    } else {
        $error = "❌ Please fill in both title and message body.";
    }
}

// Handle register device
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['register_device'])) {
    $device_token = trim($_POST['device_token'] ?? '');
    $platform = $_POST['platform'] ?? 'android';
    $user_id = trim($_POST['user_id'] ?? '');
    
    if ($device_token) {
        try {
            if ($user_id) {
                $stmt = $pdo->prepare("INSERT INTO device_tokens (device_token, platform, user_id, is_active, created_at) VALUES (?, ?, ?, 1, NOW()) ON DUPLICATE KEY UPDATE platform = ?, user_id = ?, updated_at = NOW()");
                $stmt->execute([$device_token, $platform, $user_id, $platform, $user_id]);
            } else {
                $stmt = $pdo->prepare("INSERT INTO device_tokens (device_token, platform, is_active, created_at) VALUES (?, ?, 1, NOW()) ON DUPLICATE KEY UPDATE platform = ?, updated_at = NOW()");
                $stmt->execute([$device_token, $platform, $platform]);
            }
            $message = "✅ Device registered successfully!";
        } catch (PDOException $e) {
            $error = "❌ Failed to register device: " . $e->getMessage();
        }
    } else {
        $error = "❌ Device token is required.";
    }
}

// Handle delete device
if (isset($_GET['delete_device'])) {
    $stmt = $pdo->prepare("DELETE FROM device_tokens WHERE id = ?");
    $stmt->execute([$_GET['delete_device']]);
    $message = "✅ Device deleted successfully!";
    header("Location: push_notifications.php");
    exit;
}

// Handle delete notification
if (isset($_GET['delete_notification'])) {
    $stmt = $pdo->prepare("DELETE FROM push_notifications WHERE id = ?");
    $stmt->execute([$_GET['delete_notification']]);
    $message = "✅ Notification deleted successfully!";
    header("Location: push_notifications.php");
    exit;
}

// Get all data
$devices = $pdo->query("SELECT * FROM device_tokens ORDER BY created_at DESC")->fetchAll();
$notifications = $pdo->query("SELECT * FROM push_notifications ORDER BY created_at DESC")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Push Notifications System</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body { font-family: Arial, sans-serif; background: #f5f5f5; }
        .header { background: #2c3e50; color: white; padding: 15px 20px; display: flex; justify-content: space-between; align-items: center; }
        .header a { color: white; text-decoration: none; margin-left: 15px; }
        .container { max-width: 1200px; margin: 0 auto; padding: 20px; }
        .card { background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 4px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input, textarea, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }
        textarea { min-height: 100px; }
        button { background: #4a86e8; color: white; padding: 10px 20px; border: none; border-radius: 5px; cursor: pointer; }
        button:hover { background: #3a6ec8; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 10px; text-align: left; border-bottom: 1px solid #ddd; }
        th { background: #4a86e8; color: white; }
        .success { background: #d4edda; color: #155724; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .error { background: #f8d7da; color: #721c24; padding: 10px; border-radius: 5px; margin-bottom: 15px; }
        .btn-delete { background: #e74c3c; color: white; padding: 5px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; }
        .btn-add { background: #27ae60; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block; }
        .tabs { display: flex; gap: 10px; margin-bottom: 20px; }
        .tab { padding: 10px 20px; background: #ddd; cursor: pointer; border-radius: 5px; }
        .tab.active { background: #4a86e8; color: white; }
        .tab-content { display: none; }
        .tab-content.active { display: block; }
    </style>
</head>
<body>
<div class="header">
    <h1>🔔 Push Notifications System</h1>
    <div><a href="index.php">🏠 Dashboard</a> <a href="admin_dashboard.php">⚙️ Admin</a></div>
</div>

<div class="container">
    <?php if ($message): ?>
        <div class="success"><?php echo $message; ?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="error"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="tabs">
        <div class="tab active" onclick="showTab('add')">➕ Add Notification</div>
        <div class="tab" onclick="showTab('devices')">📱 Registered Devices</div>
        <div class="tab" onclick="showTab('history')">📜 Notification History</div>
    </div>

    <!-- Add Notification Tab -->
    <div id="add" class="tab-content active">
        <div class="card">
            <h3>Create New Push Notification</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Notification Title</label>
                    <input type="text" name="title" required placeholder="e.g., New Course Available">
                </div>
                <div class="form-group">
                    <label>Notification Message</label>
                    <textarea name="body" required placeholder="Enter your notification message here..."></textarea>
                </div>
                <div class="form-group">
                    <label>Target Audience</label>
                    <select name="target_type">
                        <option value="all">All Devices</option>
                        <option value="students">Students Only</option>
                        <option value="staff">Staff Only</option>
                    </select>
                </div>
                <button type="submit" name="add_notification">💾 Save Notification Record</button>
            </form>
        </div>
    </div>

    <!-- Registered Devices Tab -->
    <div id="devices" class="tab-content">
        <div class="card">
            <h3>Register New Device</h3>
            <form method="POST">
                <div class="form-group">
                    <label>Device Token (FCM Token)</label>
                    <input type="text" name="device_token" required placeholder="Enter device token from mobile app">
                </div>
                <div class="form-group">
                    <label>Platform</label>
                    <select name="platform">
                        <option value="android">Android</option>
                        <option value="ios">iOS</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>User ID (Optional)</label>
                    <input type="text" name="user_id" placeholder="Associate with specific user">
                </div>
                <button type="submit" name="register_device">📱 Register Device</button>
            </form>
        </div>

        <div class="card">
            <h3>Registered Devices (<?php echo count($devices); ?>)</h3>
            <?php if (count($devices) > 0): ?>
                <table>
                    <thead><tr><th>ID</th><th>Device Token</th><th>Platform</th><th>User ID</th><th>Status</th><th>Registered</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach ($devices as $device): ?>
                        <tr>
                            <td><?php echo $device['id']; ?></td>
                            <td><code><?php echo substr($device['device_token'], 0, 30); ?>...</code></td>
                            <td><?php echo $device['platform']; ?></td>
                            <td><?php echo $device['user_id'] ?? 'N/A'; ?></td>
                            <td><?php echo $device['is_active'] ? '✅ Active' : '❌ Inactive'; ?></td>
                            <td><?php echo date('M d, Y', strtotime($device['created_at'])); ?></td>
                            <td><a href="?delete_device=<?php echo $device['id']; ?>" class="btn-delete" onclick="return confirm('Delete this device?')">Delete</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No devices registered yet.</p>
            <?php endif; ?>
        </div>
    </div>

    <!-- Notification History Tab -->
    <div id="history" class="tab-content">
        <div class="card">
            <h3>Notification History (<?php echo count($notifications); ?>)</h3>
            <?php if (count($notifications) > 0): ?>
                <table>
                    <thead><tr><th>ID</th><th>Title</th><th>Message</th><th>Target</th><th>Created</th><th>Action</th></tr></thead>
                    <tbody>
                        <?php foreach ($notifications as $notif): ?>
                        <tr>
                            <td><?php echo $notif['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($notif['title']); ?></strong></td>
                            <td><?php echo htmlspecialchars(substr($notif['body'], 0, 50)); ?>...</td>
                            <td><?php echo $notif['target_type']; ?></td>
                            <td><?php echo date('M d, Y g:i A', strtotime($notif['created_at'])); ?></td>
                            <td><a href="?delete_notification=<?php echo $notif['id']; ?>" class="btn-delete" onclick="return confirm('Delete this notification?')">Delete</a></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No notifications sent yet. Create your first notification above!</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
function showTab(tabName) {
    var tabs = document.getElementsByClassName('tab-content');
    for (var i = 0; i < tabs.length; i++) {
        tabs[i].classList.remove('active');
    }
    var tabButtons = document.getElementsByClassName('tab');
    for (var i = 0; i < tabButtons.length; i++) {
        tabButtons[i].classList.remove('active');
    }
    document.getElementById(tabName).classList.add('active');
    event.currentTarget.classList.add('active');
}
</script>
</body>
</html>
