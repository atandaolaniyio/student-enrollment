<?php
require_once 'db.php';

// Get actual column names
$cols_students = $pdo->query("DESCRIBE students")->fetchAll();
$student_cols = array_column($cols_students, 'Field');
echo "Students columns: " . implode(', ', $student_cols) . "\n";

// Insert sample students based on actual columns
if (in_array('first_name', $student_cols) && in_array('last_name', $student_cols)) {
    $pdo->exec("INSERT IGNORE INTO students (first_name, last_name, email) VALUES 
        ('John', 'Doe', 'john.doe@example.com'),
        ('Jane', 'Smith', 'jane.smith@example.com'),
        ('Mike', 'Johnson', 'mike.j@example.com')");
    echo "Added students\n";
} elseif (in_array('name', $student_cols)) {
    $pdo->exec("INSERT IGNORE INTO students (name, email) VALUES 
        ('John Doe', 'john.doe@example.com'),
        ('Jane Smith', 'jane.smith@example.com'),
        ('Mike Johnson', 'mike.j@example.com')");
    echo "Added students\n";
}

// Insert sample courses
$cols_courses = $pdo->query("DESCRIBE courses")->fetchAll();
$course_cols = array_column($cols_courses, 'Field');
echo "Courses columns: " . implode(', ', $course_cols) . "\n";

if (in_array('course_name', $course_cols)) {
    $pdo->exec("INSERT IGNORE INTO courses (course_name) VALUES 
        ('CS 101 - Introduction to Programming'),
        ('MATH 150 - Calculus I'),
        ('ENG 101 - English Composition')");
    echo "Added courses\n";
} elseif (in_array('name', $course_cols)) {
    $pdo->exec("INSERT IGNORE INTO courses (name) VALUES 
        ('CS 101 - Introduction to Programming'),
        ('MATH 150 - Calculus I'),
        ('ENG 101 - English Composition')");
    echo "Added courses\n";
}

// Insert sample policies
$pdo->exec("INSERT IGNORE INTO policies (name, information) VALUES 
    ('Academic Integrity', 'Students must maintain academic honesty in all coursework.'),
    ('Attendance Policy', 'Regular attendance is required for successful completion.')");

// Insert sample FAQ
$pdo->exec("INSERT IGNORE INTO faq (question, answer) VALUES 
    ('How to register?', 'Contact the registrar office at registrar@pnw.edu'),
    ('When is tuition due?', 'Tuition is due on the first day of classes.')");

// Insert sample campus safety
$pdo->exec("INSERT IGNORE INTO campus_safety (name, information) VALUES 
    ('Emergency Procedures', 'Call 911 for emergencies. Campus police: 219-989-2220'),
    ('Campus Police', '24/7 police services available on both campuses.')");

// Insert sample building hours
$pdo->exec("INSERT IGNORE INTO building_hours (name, campus) VALUES 
    ('Library - Hammond', 1),
    ('Library - Westville', 2)");

// Insert sample academic resources
$pdo->exec("INSERT IGNORE INTO academic_resources (name, information) VALUES 
    ('Tutoring Center', 'Free tutoring available in Math, Science, and Writing.'),
    ('Writing Lab', 'Help with essays, research papers, and presentations.')");

// Insert sample CEP info
$pdo->exec("INSERT IGNORE INTO cep_info (name, information) VALUES 
    ('Program Benefits', 'Earn college credit while still in high school.'),
    ('Eligibility', 'Juniors and seniors with minimum 3.0 GPA.')");

// Insert sample course descriptions
$pdo->exec("INSERT IGNORE INTO course_descriptions (course_code, title, description) VALUES 
    ('CS 101', 'Intro to Programming', 'Learn basic programming concepts using Java.'),
    ('MATH 150', 'Calculus I', 'Limits, derivatives, and integrals.')");

// Insert sample device tokens
$pdo->exec("INSERT IGNORE INTO device_tokens (device_token, platform) VALUES 
    ('sample_token_1', 'android'),
    ('sample_token_2', 'ios')");

echo "\n✅ Sample data insertion completed!\n";

// Show counts
$tables = ['students','courses','enrollments','policies','faq','campus_safety','building_hours','academic_resources','cep_info','course_descriptions','device_tokens'];
foreach ($tables as $table) {
    $count = $pdo->query("SELECT COUNT(*) FROM $table")->fetchColumn();
    echo "$table: $count records\n";
}
?>
