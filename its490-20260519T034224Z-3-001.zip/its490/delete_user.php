<?php
require_once 'config.php';

$data = json_decode(file_get_contents('php://input'), true);

$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $data['id']);

$response = ['success' => $stmt->execute()];
echo json_encode($response);
?>
