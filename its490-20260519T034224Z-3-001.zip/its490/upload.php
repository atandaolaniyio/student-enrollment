<?php
session_start();

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: login.php");
    exit();
}

require_once __DIR__ . '/db_connect.php';
$conn = db_connect();

$username = $_SESSION['username'];

// Find user id
$stmt = $conn->prepare('SELECT id FROM users WHERE username = ? LIMIT 1');
$stmt->bind_param('s', $username);
$stmt->execute();
$stmt->bind_result($user_id);
$stmt->fetch();
$stmt->close();

if (!$user_id) {
    $conn->close();
    die('User not found in database.');
}

// Directory where uploaded files will be stored (inside the project)
$uploadDirectory = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR;
if (!is_dir($uploadDirectory)) {
    mkdir($uploadDirectory, 0755, true);
}

// Check if the file was uploaded without errors
if (isset($_FILES["file"]) && $_FILES["file"]["error"] === UPLOAD_ERR_OK) {
    $fileName = basename($_FILES["file"]["name"]);

    // Avoid overwriting files with the same name
    $targetPath = $uploadDirectory . $fileName;
    if (file_exists($targetPath)) {
        $pathInfo = pathinfo($fileName);
        $base = $pathInfo['filename'];
        $ext = isset($pathInfo['extension']) ? '.' . $pathInfo['extension'] : '';
        $i = 1;
        while (file_exists($uploadDirectory . $base . "_" . $i . $ext)) {
            $i++;
        }
        $fileName = $base . "_" . $i . $ext;
        $targetPath = $uploadDirectory . $fileName;
    }

    if (move_uploaded_file($_FILES["file"]["tmp_name"], $targetPath)) {
        $relativePath = 'uploads/' . $fileName;

        // Save upload record
        $stmt = $conn->prepare('INSERT INTO uploads (user_id, file_name, file_path) VALUES (?, ?, ?)');
        $stmt->bind_param('iss', $user_id, $fileName, $relativePath);
        $stmt->execute();
        $stmt->close();

        // Create a "push-style" notification
        $message = "File uploaded: $fileName";
        $stmt = $conn->prepare('INSERT INTO notifications (username, message) VALUES (?, ?)');
        $stmt->bind_param('ss', $username, $message);
        $stmt->execute();
        $stmt->close();

        $conn->close();
        header('Location: userpage.php?upload=success');
        exit();
    }

    $conn->close();
    die("Sorry, there was an error uploading your file.");
}

$conn->close();
die("Upload error: " . (isset($_FILES['file']['error']) ? $_FILES['file']['error'] : 'No file uploaded'));
?>
